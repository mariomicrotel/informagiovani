/* global React, IGIcons, IG_UI, IG_DATA */
(function(){
var I = IGIcons;
var { useRoute, navigate, Link, ToastProvider, ModalProvider, StoreProvider } = IG_UI;

function NavMap({ onClose }) {
  // Persona switcher / sitemap overlay
  const flows = [
    {
      persona: 'Giovane · cittadino', color: 'var(--ig-blue-700)', bg: 'var(--ig-blue-50)',
      routes: [
        ['Homepage', '/'],
        ['Elenco opportunità', '/opportunita'],
        ['Dettaglio scheda', '/scheda/ERA-2026-117'],
        ['Prenotazione colloquio', '/prenota'],
        ['Invia richiesta · ticket', '/ticket'],
        ['Eventi', '/eventi'],
        ['Area personale · panoramica', '/area'],
        ['Profilo', '/area/profilo'],
        ['Opportunità salvate', '/area/salvate'],
        ['Appuntamenti', '/area/appuntamenti'],
        ['Le mie richieste', '/area/richieste'],
        ['I miei eventi', '/area/eventi'],
        ['Percorso impresa', '/area/percorso'],
        ['CV e documenti', '/area/cv'],
        ['Preferenze notifiche', '/area/notifiche'],
        ['Privacy e consensi', '/area/privacy'],
      ],
    },
    {
      persona: 'Operatore · responsabile', color: 'var(--ig-amber-700)', bg: 'var(--ig-amber-50)',
      routes: [
        ['Dashboard backend', '/backend'],
        ['Schede informative · lista', '/backend/schede'],
        ['Schede · solo da verificare', '/backend/schede?status=state-review'],
        ['Editor scheda', '/backend/schede/IMP-2026-091'],
        ['Ticket · kanban', '/backend/ticket'],
        ['Dettaglio ticket', '/backend/ticket/R-2841'],
        ['Nuovo colloquio', '/backend/colloqui/nuovo'],
        ['Lista colloqui', '/backend/colloqui'],
        ['Utenti giovani', '/backend/utenti'],
        ['Dettaglio utente', '/backend/utenti/USR-001284'],
      ],
    },
  ];
  return (
    <div onClick={onClose} style={{ position: 'fixed', inset: 0, zIndex: 8000, background: 'rgba(12,26,44,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 32, animation: 'modalBgIn .2s ease-out' }}>
      <div onClick={(e) => e.stopPropagation()} className="ig" style={{ background: 'white', borderRadius: 16, padding: 32, maxWidth: 920, width: '90%', maxHeight: '85vh', overflowY: 'auto', boxShadow: '0 32px 64px rgba(0,0,0,0.3)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 22 }}>
          <div>
            <div style={{ fontSize: 11, fontWeight: 800, color: 'var(--ig-teal-700)', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 6 }}>Mappa di navigazione</div>
            <h2 style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.01em' }}>Esplora il prototipo</h2>
            <p style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginTop: 4 }}>Salta a qualunque flusso. Clicca un link per aprirlo, o usa <kbd style={{ background: 'var(--ig-ink-100)', padding: '2px 6px', borderRadius: 4, fontFamily: 'var(--ig-font-mono)', fontSize: 11 }}>Esc</kbd> per chiudere.</p>
          </div>
          <button onClick={onClose} className="ig-btn ig-btn--ghost ig-btn--icon" style={{ width: 38, height: 38 }}><I.X size={18}/></button>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
          {flows.map((f) => (
            <div key={f.persona} style={{ border: '1px solid var(--ig-border-soft)', borderRadius: 12, overflow: 'hidden' }}>
              <div style={{ padding: '14px 18px', background: f.bg, borderBottom: '1px solid var(--ig-border-soft)' }}>
                <div style={{ fontSize: 12, fontWeight: 800, color: f.color, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{f.persona}</div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                {f.routes.map(([label, to], i) => (
                  <Link key={to} to={to} onClick={onClose} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 18px', borderBottom: i < f.routes.length - 1 ? '1px solid var(--ig-border-soft)' : 'none', fontSize: 13, fontWeight: 500, color: 'var(--ig-ink-700)', textDecoration: 'none' }}>
                    <span>{label}</span>
                    <span style={{ fontFamily: 'var(--ig-font-mono)', fontSize: 11, color: 'var(--ig-ink-400)' }}>{to}</span>
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div style={{ marginTop: 20, padding: '14px 18px', background: 'var(--ig-blue-50)', borderRadius: 10, fontSize: 12, color: 'var(--ig-ink-700)', display: 'flex', gap: 10 }}>
          <I.Info size={16} color="var(--ig-blue-700)"/>
          <div>Le modifiche (salvataggi, stati ticket, candidature, profilo) restano in memoria durante la sessione. Ricarica la pagina per ripartire da zero.</div>
        </div>
      </div>
    </div>
  );
}

function NavTrigger({ onClick }) {
  return (
    <button onClick={onClick} style={{
      position: 'fixed', bottom: 20, right: 20, zIndex: 100,
      background: 'var(--ig-ink-900)', color: 'white',
      border: 'none', borderRadius: 999,
      padding: '12px 18px', fontSize: 13, fontWeight: 700,
      display: 'flex', alignItems: 'center', gap: 8,
      cursor: 'pointer', fontFamily: 'inherit',
      boxShadow: '0 12px 28px rgba(12,26,44,0.25)',
    }}>
      <I.Grid size={14}/> Naviga il prototipo
    </button>
  );
}

function Router() {
  const route = useRoute();
  const [navOpen, setNavOpen] = React.useState(false);

  React.useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') setNavOpen(false); if (e.key === '?' || (e.shiftKey && e.key === '/')) setNavOpen(true); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const p = route.parts;
  const isBackend = p[0] === 'backend';

  // Local capitalized refs — JSX cannot resolve member expressions starting with lowercase.
  const W = window;
  const Dashboard = W.PROTO_BACKEND_DASHBOARD;
  const SchedeList = W.PROTO_BACKEND_SCHEDE;
  const SchedaEdit = W.PROTO_BACKEND_SCHEDA_EDIT;
  const Tickets = W.PROTO_BACKEND_TICKETS;
  const TicketDetail = W.PROTO_BACKEND_TICKET_DETAIL;
  const Colloquio = W.PROTO_BACKEND_COLLOQUIO;
  const ColloquiList = W.PROTO_BACKEND_COLLOQUI_LIST;
  const Utenti = W.PROTO_BACKEND_UTENTI;
  const Header = W.PROTO_HEADER;
  const Footer = W.PROTO_FOOTER;
  const Home = W.PROTO_HOME;
  const ListPage = W.PROTO_LIST;
  const Detail = W.PROTO_DETAIL;
  const Booking = W.PROTO_BOOKING;
  const Ticket = W.PROTO_TICKET;
  const Eventi = W.PROTO_EVENTI;
  const Area = W.PROTO_AREA;

  let content;
  if (isBackend) {
    if (!p[1]) content = <Dashboard route={route}/>;
    else if (p[1] === 'schede' && p[2]) content = <SchedaEdit route={route}/>;
    else if (p[1] === 'schede') content = <SchedeList route={route}/>;
    else if (p[1] === 'ticket' && p[2]) content = <TicketDetail route={route}/>;
    else if (p[1] === 'ticket') content = <Tickets route={route}/>;
    else if (p[1] === 'colloqui' && p[2] === 'nuovo') content = <Colloquio route={route}/>;
    else if (p[1] === 'colloqui') content = <ColloquiList route={route}/>;
    else if (p[1] === 'utenti') content = <Utenti route={route}/>;
    else content = <Dashboard route={route}/>;
  } else {
    let pageContent;
    if (!p[0]) pageContent = <Home/>;
    else if (p[0] === 'opportunita') pageContent = <ListPage route={route}/>;
    else if (p[0] === 'scheda') pageContent = <Detail route={route}/>;
    else if (p[0] === 'prenota') pageContent = <Booking route={route}/>;
    else if (p[0] === 'ticket') pageContent = <Ticket route={route}/>;
    else if (p[0] === 'eventi') pageContent = <Eventi route={route}/>;
    else if (p[0] === 'area') pageContent = <Area route={route}/>;
    else pageContent = <Home/>;
    content = <><Header route={route}/>{pageContent}<Footer/></>;
  }

  return (
    <>
      <div id="proto-scroll" style={{ height: '100vh', overflowY: 'auto' }}>{content}</div>
      <NavTrigger onClick={() => setNavOpen(true)}/>
      {navOpen && <NavMap onClose={() => setNavOpen(false)}/>}
    </>
  );
}

function App() {
  return (
    <StoreProvider>
      <ToastProvider>
        <ModalProvider>
          <Router/>
        </ModalProvider>
      </ToastProvider>
    </StoreProvider>
  );
}

window.PROTO_APP = App;

})();
