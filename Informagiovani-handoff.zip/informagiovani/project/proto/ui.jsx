/* global React, IGIcons */
(function(){
var { useState, useEffect, useReducer, createContext, useContext, useCallback, useRef } = React;
var I = IGIcons;

// ============================================================
// HASH ROUTER
// ============================================================
// Routes follow #/persona/page/param style.
// Examples:
//   #/                          → public home
//   #/opportunita?area=lavoro   → public list
//   #/scheda/ERA-2026-117       → public detail
//   #/prenota                   → booking form
//   #/area                      → personal area panoramica
//   #/area/salvate              → personal area saved
//   #/backend                   → backend dashboard
//   #/backend/schede            → schede list
//   #/backend/ticket            → ticket kanban
//   #/backend/ticket/R-2841     → ticket detail
//   #/backend/colloqui/nuovo    → new colloquio

function parseHash() {
  const raw = window.location.hash.slice(1) || '/';
  const [pathPart, queryPart] = raw.split('?');
  const parts = pathPart.split('/').filter(Boolean);
  const query = {};
  if (queryPart) {
    queryPart.split('&').forEach(p => {
      const [k, v] = p.split('=');
      query[decodeURIComponent(k)] = v !== undefined ? decodeURIComponent(v) : true;
    });
  }
  return { parts, query, path: pathPart };
}

function useRoute() {
  const [route, setRoute] = useState(parseHash());
  useEffect(() => {
    const onHash = () => {
      setRoute(parseHash());
      // scroll the app container to top on route change
      const el = document.getElementById('proto-scroll');
      if (el) el.scrollTop = 0;
    };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);
  return route;
}

function navigate(path) {
  window.location.hash = path.startsWith('/') ? path : '/' + path;
}

function Link({ to, children, className, style, onClick }) {
  return (
    <a
      href={'#' + (to.startsWith('/') ? to : '/' + to)}
      className={className}
      style={style}
      onClick={(e) => { if (onClick) onClick(e); }}
    >
      {children}
    </a>
  );
}

// ============================================================
// TOAST SYSTEM
// ============================================================
const ToastContext = createContext(null);

function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const push = useCallback((kind, title, msg) => {
    const id = Math.random().toString(36).slice(2);
    setToasts(t => [...t, { id, kind, title, msg }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 4500);
  }, []);
  const remove = useCallback((id) => setToasts(t => t.filter(x => x.id !== id)), []);

  const api = {
    success: (title, msg) => push('success', title, msg),
    error:   (title, msg) => push('error', title, msg),
    info:    (title, msg) => push('info', title, msg),
    warning: (title, msg) => push('warning', title, msg),
  };

  return (
    <ToastContext.Provider value={api}>
      {children}
      {/* Stack */}
      <div style={{
        position: 'fixed', bottom: 24, right: 24, zIndex: 9999,
        display: 'flex', flexDirection: 'column', gap: 10, alignItems: 'flex-end',
        pointerEvents: 'none',
      }}>
        {toasts.map(t => <ToastItem key={t.id} t={t} onClose={() => remove(t.id)}/>)}
      </div>
    </ToastContext.Provider>
  );
}

function ToastItem({ t, onClose }) {
  const map = {
    success: { bg: 'var(--ig-green-100)', border: 'var(--ig-green-600)', fg: 'var(--ig-green-700)', icon: <I.Check size={20}/> },
    error:   { bg: 'var(--ig-red-100)',   border: 'var(--ig-red-600)',   fg: 'var(--ig-red-700)',   icon: <I.Alert size={20}/> },
    warning: { bg: 'var(--ig-amber-100)', border: 'var(--ig-amber-600)', fg: 'var(--ig-amber-800)', icon: <I.Alert size={20}/> },
    info:    { bg: 'var(--ig-blue-100)',  border: 'var(--ig-blue-700)',  fg: 'var(--ig-blue-800)',  icon: <I.Info size={20}/> },
  };
  const c = map[t.kind];
  return (
    <div style={{
      pointerEvents: 'auto', minWidth: 320, maxWidth: 420,
      background: 'white', borderRadius: 10, padding: '14px 16px',
      display: 'flex', gap: 12, alignItems: 'flex-start',
      border: `1px solid ${c.bg}`, borderLeft: `4px solid ${c.border}`,
      boxShadow: '0 12px 28px rgba(12,26,44,0.18)',
      animation: 'toastIn .25s ease-out',
    }}>
      <div style={{ color: c.fg, flex: '0 0 auto', marginTop: 1 }}>{c.icon}</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ig-ink-900)' }}>{t.title}</div>
        {t.msg && <div style={{ fontSize: 12, color: 'var(--ig-ink-700)', marginTop: 2, lineHeight: 1.5 }}>{t.msg}</div>}
      </div>
      <button onClick={onClose} style={{ background: 'none', border: 'none', padding: 2, color: 'var(--ig-ink-400)', cursor: 'pointer' }}><I.X size={14}/></button>
    </div>
  );
}

function useToast() {
  return useContext(ToastContext);
}

// ============================================================
// MODAL SYSTEM
// ============================================================
const ModalContext = createContext(null);

function ModalProvider({ children }) {
  const [modal, setModal] = useState(null);
  const open = useCallback((m) => setModal(m), []);
  const close = useCallback(() => setModal(null), []);

  return (
    <ModalContext.Provider value={{ open, close }}>
      {children}
      {modal && (
        <div
          onClick={close}
          style={{
            position: 'fixed', inset: 0, zIndex: 9000,
            background: 'rgba(12,26,44,0.50)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            padding: 32, animation: 'modalBgIn .2s ease-out',
          }}>
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              background: 'white', borderRadius: 14,
              width: modal.width || 480, maxWidth: '90vw', maxHeight: '85vh',
              overflow: 'auto', boxShadow: '0 32px 64px rgba(12,26,44,0.30)',
              animation: 'modalIn .2s ease-out',
            }}>
            {modal.title && (
              <div style={{ padding: '20px 24px 14px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', alignItems: 'center', gap: 14 }}>
                {modal.icon && <div style={{
                  width: 38, height: 38, borderRadius: 10,
                  background: modal.danger ? 'var(--ig-red-100)' : 'var(--ig-blue-50)',
                  color: modal.danger ? 'var(--ig-red-700)' : 'var(--ig-blue-700)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>{modal.icon}</div>}
                <div style={{ flex: 1 }}>
                  <h3 style={{ fontSize: 17, fontWeight: 700, color: 'var(--ig-ink-900)' }}>{modal.title}</h3>
                  {modal.subtitle && <div style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginTop: 2 }}>{modal.subtitle}</div>}
                </div>
                <button onClick={close} style={{ background: 'none', border: 'none', padding: 6, cursor: 'pointer', color: 'var(--ig-ink-400)' }}><I.X size={18}/></button>
              </div>
            )}
            <div style={{ padding: 24 }}>{modal.content}</div>
            {modal.actions && (
              <div style={{ padding: '14px 24px 22px', display: 'flex', gap: 8, justifyContent: 'flex-end', borderTop: '1px solid var(--ig-border-soft)' }}>
                {modal.actions}
              </div>
            )}
          </div>
        </div>
      )}
    </ModalContext.Provider>
  );
}

function useModal() {
  return useContext(ModalContext);
}

// Confirm helper (returns promise)
function useConfirm() {
  const { open, close } = useModal();
  return useCallback((opts) => {
    return new Promise((resolve) => {
      open({
        title: opts.title || 'Confermi l\u2019operazione?',
        subtitle: opts.subtitle,
        icon: opts.icon || <I.Alert size={20}/>,
        danger: opts.danger,
        content: <p style={{ fontSize: 14, color: 'var(--ig-ink-700)', lineHeight: 1.6 }}>{opts.message}</p>,
        actions: <>
          <button className="ig-btn ig-btn--ghost" onClick={() => { close(); resolve(false); }}>{opts.cancelLabel || 'Annulla'}</button>
          <button className={opts.danger ? 'ig-btn ig-btn--danger' : 'ig-btn ig-btn--primary'} onClick={() => { close(); resolve(true); }}>
            {opts.confirmLabel || 'Conferma'}
          </button>
        </>,
      });
    });
  }, [open, close]);
}

// ============================================================
// GLOBAL STORE — saved opps, ticket states, profile, schede statuses
// ============================================================
const StoreContext = createContext(null);

const INITIAL_STORE = {
  saved: new Set(['ERA-2026-117', 'IMP-2026-085', 'SCN-2026-022', 'CON-2026-046', 'FOR-2026-152', 'IMP-2026-091', 'CUL-2025-198', 'DIR-2026-014', 'LAV-2026-302', 'FOR-2026-148']),
  candidate: { 'IMP-2026-085': 'inviata', 'SCN-2026-022': 'colloquio' }, // schede.id → stato candidatura
  savedNotes: {
    'ERA-2026-117': 'Ricorda di completare il Learning Agreement entro la settimana.',
    'IMP-2026-085': 'Pratica in valutazione · esito previsto in 60 giorni.',
    'SCN-2026-022': 'Colloquio con il referente progetto il 21 marzo.',
  },
  ticketStates: {}, // ticket.id → new status (overrides)
  ticketOperator: {},
  ticketReplies: {}, // ticket.id → array of msgs added
  schedeStatus: {}, // scheda.id → new status (overrides)
  appointments: [
    { id: 'AP-001', user: 'Salvatore Catanzaro', userId: 'USR-001284', when: 'oggi 09:30', date: '14 mar 2026 · 09:30', topic: 'Resto al Sud · documentazione', op: 'M. Greco', channel: 'in presenza' },
    { id: 'AP-002', user: 'Salvatore Catanzaro', userId: 'USR-001284', when: '18 mar 10:00', date: '18 mar 2026 · 10:00', topic: 'BMC · idea food truck', op: 'F. Bellomo', channel: 'in presenza' },
  ],
  myEvents: new Set(['EV-2026-024', 'EV-2026-025', 'EV-2026-028']),
  myTickets: ['R-2841', 'R-2837'],
  profile: { ...window.IG_DATA.ME },
  newTickets: [], // user-created tickets pending
  cv: { uploaded: true, filename: 'CV_Catanzaro_2026.pdf', size: '234 KB' },
};

function storeReducer(state, action) {
  switch (action.type) {
    case 'TOGGLE_SAVED': {
      const next = new Set(state.saved);
      if (next.has(action.id)) next.delete(action.id); else next.add(action.id);
      return { ...state, saved: next };
    }
    case 'SET_CANDIDATE_STATE': {
      return { ...state, candidate: { ...state.candidate, [action.id]: action.value } };
    }
    case 'SAVE_NOTE': {
      return { ...state, savedNotes: { ...state.savedNotes, [action.id]: action.note } };
    }
    case 'SET_TICKET_STATUS': {
      return { ...state, ticketStates: { ...state.ticketStates, [action.id]: action.status } };
    }
    case 'SET_TICKET_OPERATOR': {
      return { ...state, ticketOperator: { ...state.ticketOperator, [action.id]: action.operator } };
    }
    case 'ADD_TICKET_REPLY': {
      const prev = state.ticketReplies[action.id] || [];
      return { ...state, ticketReplies: { ...state.ticketReplies, [action.id]: [...prev, action.reply] } };
    }
    case 'SET_SCHEDA_STATUS': {
      return { ...state, schedeStatus: { ...state.schedeStatus, [action.id]: action.status } };
    }
    case 'ADD_APPOINTMENT': {
      return { ...state, appointments: [...state.appointments, action.appointment] };
    }
    case 'REMOVE_APPOINTMENT': {
      return { ...state, appointments: state.appointments.filter(a => a.id !== action.id) };
    }
    case 'TOGGLE_EVENT': {
      const next = new Set(state.myEvents);
      if (next.has(action.id)) next.delete(action.id); else next.add(action.id);
      return { ...state, myEvents: next };
    }
    case 'UPDATE_PROFILE': {
      return { ...state, profile: { ...state.profile, ...action.profile } };
    }
    case 'ADD_TICKET': {
      return { ...state, newTickets: [...state.newTickets, action.ticket], myTickets: [...state.myTickets, action.ticket.id] };
    }
    case 'SET_CV': {
      return { ...state, cv: action.cv };
    }
    default:
      return state;
  }
}

function StoreProvider({ children }) {
  const [state, dispatch] = useReducer(storeReducer, INITIAL_STORE);
  return (
    <StoreContext.Provider value={[state, dispatch]}>{children}</StoreContext.Provider>
  );
}

function useStore() {
  return useContext(StoreContext);
}

// Helper: get scheda with applied store overrides
function getScheda(id, state) {
  const base = window.IG_DATA.SCHEDE.find(s => s.id === id);
  if (!base) return null;
  const status = state.schedeStatus[id];
  if (!status) return base;
  const labels = { 'state-draft': 'Bozza', 'state-review': 'Da verificare', 'state-valid': 'Validata', 'state-pub': 'Pubblicata', 'state-archive': 'Archiviata', 'state-update': 'Da aggiornare', 'state-exp': 'Scaduta' };
  return { ...base, status, statusLabel: labels[status] || base.statusLabel };
}

// Helper: get ticket with applied store overrides
function getTicket(id, state) {
  const base = [...window.IG_DATA.TICKET, ...state.newTickets].find(t => t.id === id);
  if (!base) return null;
  return {
    ...base,
    status: state.ticketStates[id] || base.status,
    operator: state.ticketOperator[id] || base.operator,
    replies: state.ticketReplies[id] || [],
  };
}

// ============================================================
// EXPORT
// ============================================================
window.IG_UI = {
  useRoute, navigate, Link, parseHash,
  ToastProvider, useToast,
  ModalProvider, useModal, useConfirm,
  StoreProvider, useStore, getScheda, getTicket,
};

})();
