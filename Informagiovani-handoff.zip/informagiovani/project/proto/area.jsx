/* global React, IGIcons, IG_UI, IG_DATA */
(function(){
var { useState } = React;
var I = IGIcons;
var { Link, navigate, useToast, useModal, useConfirm, useStore, getScheda } = IG_UI;
var { SCHEDE, EVENTI } = IG_DATA;

// ============================================================
// AREA PERSONALE — with subroute switching
// ============================================================
function AreaPersonale({ route }) {
  const [storeState] = useStore();
  const profile = storeState.profile;
  const sub = route.parts[1] || '';

  const navItems = [
    ['', 'Panoramica', <I.Home size={18}/>, null],
    ['profilo', 'Il mio profilo', <I.User size={18}/>, null],
    ['salvate', 'Opportunità salvate', <I.Bookmark size={18}/>, storeState.saved.size],
    ['appuntamenti', 'Appuntamenti', <I.Calendar size={18}/>, storeState.appointments.length],
    ['richieste', 'Richieste', <I.Chat size={18}/>, storeState.myTickets.length],
    ['eventi', 'Eventi', <I.Calendar size={18}/>, storeState.myEvents.size],
    ['percorso', 'Percorso impresa', <I.Bulb size={18}/>, '●'],
    ['cv', 'Curriculum e documenti', <I.Doc size={18}/>, null],
    ['notifiche', 'Preferenze notifiche', <I.Bell size={18}/>, null],
    ['privacy', 'Privacy e consensi', <I.Shield size={18}/>, null],
  ];

  return (
    <div className="ig" style={{ background: 'var(--ig-bg)', minHeight: 'calc(100vh - 80px)' }}>
      {/* Welcome strip */}
      <div style={{ background: 'linear-gradient(120deg, var(--ig-blue-700), var(--ig-blue-800))', color: 'white' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '32px 32px 60px', display: 'flex', alignItems: 'center', gap: 22 }}>
          <div style={{ width: 72, height: 72, borderRadius: '50%', background: 'var(--ig-amber-500)', color: 'var(--ig-blue-900)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 26, border: '4px solid white' }}>{profile.avatar}</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.14em', color: 'var(--ig-amber-500)', textTransform: 'uppercase', marginBottom: 6 }}>Area personale</div>
            <h1 style={{ fontSize: 28, fontWeight: 800, color: 'white', letterSpacing: '-0.02em' }}>Bentornato, {profile.name.split(' ')[0]} 👋</h1>
            <div style={{ fontSize: 14, color: 'rgba(255,255,255,0.78)', marginTop: 4 }}>{profile.email} · {profile.status}</div>
          </div>
          <Link to="/"><button className="ig-btn ig-btn--lg" style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.25)', color: 'white' }}>Esci</button></Link>
        </div>
      </div>

      <div style={{ maxWidth: 1280, margin: '-32px auto 0', padding: '0 32px 60px', display: 'grid', gridTemplateColumns: '260px 1fr', gap: 24 }}>
        {/* Sidebar */}
        <aside>
          <div className="ig-card" style={{ padding: 12 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              {navItems.map(([k, label, icon, badge]) => {
                const active = sub === k;
                return (
                  <Link key={k} to={`/area${k ? '/' + k : ''}`} style={{
                    display: 'flex', alignItems: 'center', gap: 12,
                    padding: '10px 12px', borderRadius: 8,
                    fontSize: 14, fontWeight: 600,
                    color: active ? 'var(--ig-blue-700)' : 'var(--ig-ink-700)',
                    background: active ? 'var(--ig-blue-50)' : 'transparent',
                    borderLeft: active ? '3px solid var(--ig-blue-700)' : '3px solid transparent', marginLeft: -3,
                    textDecoration: 'none',
                  }}>
                    <span style={{ color: active ? 'var(--ig-blue-700)' : 'var(--ig-ink-400)' }}>{icon}</span>
                    <span style={{ flex: 1 }}>{label}</span>
                    {badge !== null && badge !== undefined && badge !== 0 && (
                      <span style={{ fontSize: 11, fontWeight: 700, background: 'var(--ig-ink-100)', color: 'var(--ig-ink-700)', padding: '2px 8px', borderRadius: 999 }}>{badge}</span>
                    )}
                  </Link>
                );
              })}
            </div>
          </div>
        </aside>

        {/* Content */}
        <div>
          {sub === '' && <Panoramica/>}
          {sub === 'profilo' && <Profilo/>}
          {sub === 'salvate' && <Salvate/>}
          {sub === 'appuntamenti' && <Appuntamenti/>}
          {sub === 'richieste' && <Richieste/>}
          {sub === 'eventi' && <EventiMiei/>}
          {sub === 'percorso' && <Percorso/>}
          {sub === 'cv' && <CVDocs/>}
          {sub === 'notifiche' && <Notifiche/>}
          {sub === 'privacy' && <Privacy/>}
        </div>
      </div>
    </div>
  );
}

// ============================================================
// PANORAMICA
// ============================================================
function Panoramica() {
  const [storeState] = useStore();
  const savedSchede = [...storeState.saved].map(id => SCHEDE.find(s => s.id === id)).filter(Boolean);
  const inScadenza = savedSchede.filter(s => s.daysLeft && s.daysLeft <= 21);
  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 24 }}>
        {[
          ['Opportunità salvate', storeState.saved.size, `${inScadenza.length} in scadenza`, 'var(--ig-blue-700)', '/area/salvate'],
          ['Candidature inviate', Object.values(storeState.candidate).filter(v => v === 'inviata').length, '1 in valutazione', 'var(--ig-teal-700)', '/area/salvate'],
          ['Appuntamenti', storeState.appointments.length, 'prossimo: oggi 09:30', 'var(--ig-amber-700)', '/area/appuntamenti'],
          ['Richieste aperte', storeState.myTickets.length, 'ultima risposta: 12 min', 'var(--ig-violet-700)', '/area/richieste'],
        ].map(([l, v, h, c, to]) => (
          <Link key={l} to={to} className="ig-card" style={{ padding: 16, textDecoration: 'none', color: 'inherit', cursor: 'pointer' }}>
            <div className="ig-num" style={{ fontSize: 28, fontWeight: 800, color: c, letterSpacing: '-0.02em', lineHeight: 1 }}>{v}</div>
            <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-900)', marginTop: 6 }}>{l}</div>
            <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', marginTop: 2 }}>{h}</div>
          </Link>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 24 }}>
        <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h3 style={{ fontSize: 15, fontWeight: 700 }}>Prossimi appuntamenti</h3>
            <Link to="/area/appuntamenti" style={{ fontSize: 12, fontWeight: 600 }}>Tutti →</Link>
          </div>
          {storeState.appointments.slice(0, 3).map((a, i) => (
            <div key={a.id} style={{ display: 'flex', gap: 14, padding: '14px 20px', borderBottom: i < 2 ? '1px solid var(--ig-border-soft)' : 'none' }}>
              <div style={{ width: 60, padding: '6px 0', textAlign: 'center', borderRadius: 8, background: a.when.startsWith('oggi') ? 'var(--ig-blue-700)' : 'var(--ig-ink-50)', color: a.when.startsWith('oggi') ? 'white' : 'var(--ig-ink-900)', flex: '0 0 auto' }}>
                <div style={{ fontSize: 9, fontWeight: 800, letterSpacing: '0.08em' }}>{a.when.split(' ')[0].toUpperCase()}</div>
                <div className="ig-num" style={{ fontSize: 14, fontWeight: 800, marginTop: 2 }}>{a.when.split(' ').pop()}</div>
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 700 }}>{a.topic}</div>
                <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', marginTop: 2 }}>{a.channel} · con {a.op}</div>
              </div>
            </div>
          ))}
        </div>

        <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--ig-border-soft)' }}>
            <h3 style={{ fontSize: 15, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 8 }}><I.Sparkle size={16} color="var(--ig-amber-700)"/> Consigliate per te</h3>
          </div>
          {SCHEDE.slice(0, 3).map((s, i) => (
            <Link key={s.id} to={`/scheda/${s.id}`} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '14px 20px', borderBottom: i < 2 ? '1px solid var(--ig-border-soft)' : 'none', textDecoration: 'none' }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-900)' }}>{s.title}</div>
                <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
                  <span className={`ig-badge ig-badge--${s.area}`} style={{ height: 20, fontSize: 11 }}>{s.areaLabel}</span>
                  {s.daysLeft && <span className={`ig-badge ig-badge--scad-${s.urg}`} style={{ height: 20, fontSize: 11 }}><I.Clock size={10}/>{s.daysLeft}g</span>}
                </div>
              </div>
              <I.ChevR size={16} color="var(--ig-ink-400)"/>
            </Link>
          ))}
        </div>
      </div>

      <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h3 style={{ fontSize: 15, fontWeight: 700 }}>Le mie opportunità salvate</h3>
          <Link to="/area/salvate" style={{ fontSize: 12, fontWeight: 600 }}>Vedi tutte →</Link>
        </div>
        {savedSchede.slice(0, 4).map((s, i) => (
          <div key={s.id} style={{ display: 'grid', gridTemplateColumns: '1fr 100px 110px 30px', gap: 12, padding: '14px 20px', borderBottom: i < 3 ? '1px solid var(--ig-border-soft)' : 'none', alignItems: 'center' }}>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <I.BookmarkF size={14} color="var(--ig-amber-700)"/>
              <Link to={`/scheda/${s.id}`} style={{ fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-900)' }}>{s.title}</Link>
            </div>
            <span className={`ig-badge ig-badge--${s.area}`} style={{ height: 20, fontSize: 11 }}>{s.areaLabel}</span>
            {s.daysLeft ? (
              <span className={`ig-badge ig-badge--scad-${s.urg}`} style={{ height: 20, fontSize: 11 }}><I.Clock size={10}/>{s.daysLeft} giorni</span>
            ) : <span style={{ fontSize: 11, color: 'var(--ig-green-700)', fontWeight: 600 }}>Sempre aperta</span>}
            <Link to={`/scheda/${s.id}`}><I.ChevR size={14} color="var(--ig-ink-400)"/></Link>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================
// PROFILO (editable)
// ============================================================
function Profilo() {
  const [storeState, dispatch] = useStore();
  const [editing, setEditing] = useState(false);
  const toast = useToast();
  const [data, setData] = useState(storeState.profile);

  const save = () => {
    dispatch({ type: 'UPDATE_PROFILE', profile: data });
    toast.success('Profilo aggiornato', 'Le tue informazioni sono state salvate.');
    setEditing(false);
  };

  return (
    <div className="ig-card" style={{ padding: 28 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24, paddingBottom: 16, borderBottom: '1px solid var(--ig-border-soft)' }}>
        <h2 style={{ fontSize: 22, fontWeight: 700 }}>Il mio profilo</h2>
        {!editing ? (
          <button className="ig-btn ig-btn--secondary ig-btn--sm" onClick={() => setEditing(true)}><I.Edit size={14}/> Modifica</button>
        ) : (
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="ig-btn ig-btn--ghost ig-btn--sm" onClick={() => { setData(storeState.profile); setEditing(false); }}>Annulla</button>
            <button className="ig-btn ig-btn--primary ig-btn--sm" onClick={save}><I.Check size={14}/> Salva</button>
          </div>
        )}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 18 }}>
        <Edit label="Nome completo" value={data.name} editing={editing} onChange={v => setData(d => ({...d, name: v}))}/>
        <Edit label="Email" value={data.email} editing={editing} onChange={v => setData(d => ({...d, email: v}))}/>
        <Edit label="Telefono" value={data.phone} editing={editing} onChange={v => setData(d => ({...d, phone: v}))}/>
        <Edit label="Città" value={data.city} editing={editing} onChange={v => setData(d => ({...d, city: v}))}/>
        <Edit label="Età" value={String(data.age)} editing={editing} onChange={v => setData(d => ({...d, age: v}))}/>
        <Edit label="Stato occupazionale" value={data.status} editing={editing} onChange={v => setData(d => ({...d, status: v}))}/>
      </div>

      <div style={{ marginTop: 28, paddingTop: 22, borderTop: '1px solid var(--ig-border-soft)' }}>
        <h3 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)', marginBottom: 14 }}>Interessi</h3>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          {data.interests.map(i => <span key={i} style={{ background: 'var(--ig-blue-100)', color: 'var(--ig-blue-800)', padding: '6px 12px', borderRadius: 999, fontSize: 13, fontWeight: 600 }}>{i}</span>)}
          {editing && <button onClick={() => toast.info('Selezione interessi', 'In una versione reale aprirebbe un selettore.')} className="ig-btn ig-btn--ghost ig-btn--sm" style={{ color: 'var(--ig-blue-700)' }}>+ Aggiungi</button>}
        </div>
      </div>
    </div>
  );
}

function Edit({ label, value, editing, onChange }) {
  return (
    <div>
      <label className="ig-label">{label}</label>
      {editing ? (
        <input className="ig-input" value={value} onChange={e => onChange(e.target.value)}/>
      ) : (
        <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--ig-ink-900)' }}>{value}</div>
      )}
    </div>
  );
}

// ============================================================
// SALVATE
// ============================================================
function Salvate() {
  const [storeState, dispatch] = useStore();
  const confirm = useConfirm();
  const toast = useToast();
  const savedSchede = [...storeState.saved].map(id => SCHEDE.find(s => s.id === id)).filter(Boolean);
  const [filter, setFilter] = useState('all');

  const stati = {
    all: 'Tutte',
    valutare: 'Da valutare',
    inviata: 'Candidatura inviata',
    colloquio: 'Colloquio fissato',
    non_interessato: 'Non interessato',
  };

  const filtered = savedSchede.filter(s => {
    if (filter === 'all') return true;
    return (storeState.candidate[s.id] || 'valutare') === filter;
  });

  const remove = async (s) => {
    const ok = await confirm({
      title: 'Rimuovere dai preferiti?',
      message: `Stai per rimuovere "${s.title}" dalle tue opportunità salvate.`,
      confirmLabel: 'Rimuovi',
      danger: true,
    });
    if (ok) {
      dispatch({ type: 'TOGGLE_SAVED', id: s.id });
      toast.info('Rimossa dai preferiti', s.title);
    }
  };

  const setState = (s, value) => {
    dispatch({ type: 'SET_CANDIDATE_STATE', id: s.id, value });
    toast.success('Stato aggiornato', `${s.title} · ${stati[value]}`);
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
        <h2 style={{ fontSize: 24, fontWeight: 700, letterSpacing: '-0.02em' }}>Opportunità salvate <span style={{ fontWeight: 400, color: 'var(--ig-ink-500)' }}>· {savedSchede.length}</span></h2>
      </div>
      <div style={{ display: 'flex', gap: 6, marginBottom: 14, flexWrap: 'wrap' }}>
        {Object.entries(stati).map(([k, label]) => (
          <button key={k} onClick={() => setFilter(k)} style={{
            height: 32, padding: '0 12px', borderRadius: 6,
            background: filter === k ? 'var(--ig-ink-900)' : 'white',
            color: filter === k ? 'white' : 'var(--ig-ink-700)',
            border: '1px solid', borderColor: filter === k ? 'var(--ig-ink-900)' : 'var(--ig-border)',
            fontSize: 12, fontWeight: 600, cursor: 'pointer',
          }}>{label}</button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="ig-card" style={{ padding: '52px 40px', textAlign: 'center' }}>
          <div style={{ width: 56, height: 56, borderRadius: 14, background: 'var(--ig-blue-50)', color: 'var(--ig-blue-700)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 14px' }}>
            <I.Bookmark size={24}/>
          </div>
          <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 6 }}>Nessuna opportunità in questa categoria</h3>
          <p style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>Esplora le opportunità disponibili per iniziare a salvarne.</p>
          <Link to="/opportunita"><button className="ig-btn ig-btn--primary ig-btn--sm" style={{ marginTop: 14 }}>Esplora opportunità</button></Link>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {filtered.map(s => {
            const candidateState = storeState.candidate[s.id] || 'valutare';
            const note = storeState.savedNotes[s.id];
            const stateClass = { valutare: 'state-draft', inviata: 'state-pub', colloquio: 'state-valid', non_interessato: 'state-archive' }[candidateState];
            return (
              <div key={s.id} className="ig-card" style={{ padding: 18 }}>
                <div style={{ display: 'flex', gap: 12, marginBottom: 10, alignItems: 'flex-start' }}>
                  <Link to={`/scheda/${s.id}`} style={{ flex: 1, fontSize: 15, fontWeight: 700, color: 'var(--ig-ink-900)', textDecoration: 'none' }}>{s.title}</Link>
                  <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ color: 'var(--ig-red-700)' }} onClick={() => remove(s)}><I.X size={14}/></button>
                </div>
                <div style={{ display: 'flex', gap: 8, marginBottom: note ? 10 : 0, alignItems: 'center' }}>
                  <span className={`ig-badge ig-badge--${s.area}`} style={{ height: 22, fontSize: 11 }}>{s.areaLabel}</span>
                  {s.daysLeft && <span className={`ig-badge ig-badge--scad-${s.urg}`} style={{ height: 22, fontSize: 11 }}><I.Clock size={11}/>{s.daysLeft} giorni</span>}
                  <span className={`ig-badge ig-badge--${stateClass}`} style={{ height: 22, fontSize: 11, marginLeft: 8 }}>{stati[candidateState]}</span>
                  <div style={{ marginLeft: 'auto', display: 'flex', gap: 4 }}>
                    {Object.entries(stati).filter(([k]) => k !== 'all' && k !== candidateState).map(([k, label]) => (
                      <button key={k} onClick={() => setState(s, k)} style={{ height: 26, padding: '0 8px', background: 'white', border: '1px solid var(--ig-border)', borderRadius: 4, fontSize: 11, color: 'var(--ig-ink-500)', cursor: 'pointer', fontFamily: 'inherit' }} title={`Imposta come "${label}"`}>{label}</button>
                    ))}
                  </div>
                </div>
                {note && <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', fontStyle: 'italic' }}>📝 {note}</div>}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ============================================================
// APPUNTAMENTI
// ============================================================
function Appuntamenti() {
  const [storeState, dispatch] = useStore();
  const confirm = useConfirm();
  const toast = useToast();
  const handleCancel = async (id) => {
    const ok = await confirm({
      title: 'Annullare l\u2019appuntamento?',
      message: 'L\u2019operatore verrà notificato. Potrai sempre prenotarne uno nuovo.',
      confirmLabel: 'Annulla appuntamento',
      cancelLabel: 'Mantieni',
      danger: true,
    });
    if (ok) {
      dispatch({ type: 'REMOVE_APPOINTMENT', id });
      toast.info('Appuntamento annullato', 'L\u2019operatore è stato notificato.');
    }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
        <h2 style={{ fontSize: 24, fontWeight: 700, letterSpacing: '-0.02em' }}>Appuntamenti</h2>
        <Link to="/prenota"><button className="ig-btn ig-btn--primary ig-btn--sm"><I.Plus size={14}/> Prenota nuovo</button></Link>
      </div>
      {storeState.appointments.length === 0 ? (
        <div className="ig-card" style={{ padding: '52px 40px', textAlign: 'center' }}>
          <div style={{ width: 56, height: 56, borderRadius: 14, background: 'var(--ig-blue-50)', color: 'var(--ig-blue-700)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 14px' }}>
            <I.Calendar size={24}/>
          </div>
          <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 6 }}>Nessun appuntamento</h3>
          <p style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginBottom: 12 }}>Prenota un colloquio con uno dei nostri operatori.</p>
          <Link to="/prenota"><button className="ig-btn ig-btn--primary ig-btn--sm">Prenota colloquio</button></Link>
        </div>
      ) : (
        <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
          {storeState.appointments.map((a, i) => (
            <div key={a.id} style={{ display: 'flex', gap: 18, padding: 20, borderBottom: i < storeState.appointments.length - 1 ? '1px solid var(--ig-border-soft)' : 'none' }}>
              <div style={{ width: 80, padding: '12px 0', textAlign: 'center', borderRadius: 10, background: a.when.startsWith('oggi') ? 'var(--ig-blue-700)' : 'var(--ig-ink-50)', color: a.when.startsWith('oggi') ? 'white' : 'var(--ig-ink-900)', flex: '0 0 auto' }}>
                <div style={{ fontSize: 10, fontWeight: 800, letterSpacing: '0.08em' }}>{a.when.split(' ')[0].toUpperCase()}</div>
                <div className="ig-num" style={{ fontSize: 18, fontWeight: 800, marginTop: 4 }}>{a.when.split(' ').pop()}</div>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 4 }}>
                  <span style={{ fontSize: 11, fontFamily: 'var(--ig-font-mono)', color: 'var(--ig-ink-500)' }}>{a.id}</span>
                  <span className="ig-badge ig-badge--state-pub">Confermato</span>
                </div>
                <div style={{ fontSize: 15, fontWeight: 700, marginBottom: 4 }}>{a.topic}</div>
                <div style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginBottom: 12 }}>{a.channel} · con <strong style={{ color: 'var(--ig-ink-700)' }}>{a.op}</strong> · {a.date}</div>
                <div style={{ display: 'flex', gap: 6 }}>
                  <button className="ig-btn ig-btn--secondary ig-btn--sm" onClick={() => toast.success('Aggiunto al calendario', 'Promemoria attivo')}><I.Calendar size={14}/> Aggiungi al calendario</button>
                  <button className="ig-btn ig-btn--ghost ig-btn--sm" onClick={() => toast.info('Riprogrammazione', 'In una versione reale aprirebbe il selettore data.')}>Riprogramma</button>
                  <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ color: 'var(--ig-red-700)' }} onClick={() => handleCancel(a.id)}>Annulla</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ============================================================
// RICHIESTE
// ============================================================
function Richieste() {
  const [storeState] = useStore();
  const tickets = [...window.IG_DATA.TICKET.filter(t => storeState.myTickets.includes(t.id)), ...storeState.newTickets];
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
        <h2 style={{ fontSize: 24, fontWeight: 700, letterSpacing: '-0.02em' }}>Le mie richieste</h2>
        <Link to="/ticket"><button className="ig-btn ig-btn--primary ig-btn--sm"><I.Plus size={14}/> Nuova richiesta</button></Link>
      </div>
      <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
        {tickets.map((t, i) => {
          const status = storeState.ticketStates[t.id] || t.status;
          const statusInfo = IG_DATA.TICKET_STATUSES.find(s => s.id === status);
          return (
            <div key={t.id} style={{ padding: '18px 22px', borderBottom: i < tickets.length - 1 ? '1px solid var(--ig-border-soft)' : 'none' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
                <span style={{ fontFamily: 'var(--ig-font-mono)', fontSize: 11, color: 'var(--ig-ink-500)', fontWeight: 600 }}>#{t.id}</span>
                <span style={{ height: 22, padding: '0 10px', background: 'color-mix(in srgb,' + statusInfo.color + ' 18%, white)', color: statusInfo.color, borderRadius: 999, fontSize: 11, fontWeight: 700 }}>● {statusInfo.label}</span>
                <span style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--ig-ink-400)' }}>{t.opened}</span>
              </div>
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ig-ink-900)', marginBottom: 4 }}>{t.subject}</div>
              {t.operator && <div style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}>Assegnato a {t.operator}</div>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ============================================================
// EVENTI MIEI
// ============================================================
function EventiMiei() {
  const [storeState, dispatch] = useStore();
  const toast = useToast();
  const subscribed = EVENTI.filter(e => storeState.myEvents.has(e.id));

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 18 }}>I miei eventi</h2>
      {subscribed.length === 0 ? (
        <div className="ig-card" style={{ padding: '52px 40px', textAlign: 'center' }}>
          <I.Calendar size={28} color="var(--ig-ink-400)" style={{ margin: '0 auto 14px' }}/>
          <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 6 }}>Nessun evento</h3>
          <Link to="/eventi"><button className="ig-btn ig-btn--primary ig-btn--sm" style={{ marginTop: 12 }}>Esplora eventi</button></Link>
        </div>
      ) : (
        <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
          {subscribed.map((e, i) => (
            <div key={e.id} style={{ padding: '18px 22px', borderBottom: i < subscribed.length - 1 ? '1px solid var(--ig-border-soft)' : 'none', display: 'flex', alignItems: 'center', gap: 14 }}>
              <div style={{ width: 56, padding: '6px 0', textAlign: 'center', borderRadius: 8, background: 'var(--ig-blue-50)', color: 'var(--ig-blue-700)', flex: '0 0 auto' }}>
                <div className="ig-num" style={{ fontSize: 18, fontWeight: 800 }}>{e.day}</div>
                <div style={{ fontSize: 10, fontWeight: 700 }}>{e.month}</div>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 700 }}>{e.title}</div>
                <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginTop: 2 }}>{e.mode} · {e.place} · {e.time}</div>
              </div>
              <button className="ig-btn ig-btn--secondary ig-btn--sm" onClick={() => toast.success('Promemoria scaricato', 'event.ics')}><I.Download size={14}/></button>
              <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ color: 'var(--ig-red-700)' }} onClick={() => { dispatch({ type: 'TOGGLE_EVENT', id: e.id }); toast.info('Iscrizione annullata'); }}>Annulla</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ============================================================
// PERCORSO IMPRESA
// ============================================================
function Percorso() {
  const [tab, setTab] = useState('overview');
  const toast = useToast();
  return (
    <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
      <div style={{ padding: '20px 24px 0', background: 'linear-gradient(120deg, var(--ig-teal-700), var(--ig-teal-600))', color: 'white' }}>
        <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.14em', color: 'rgba(255,255,255,0.7)', textTransform: 'uppercase', marginBottom: 6 }}>Percorso impresa</div>
        <h2 style={{ fontSize: 22, fontWeight: 700, color: 'white' }}>Catering siciliano per eventi</h2>
        <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.75)', marginTop: 4 }}>Tutor: F. Bellomo · Avviato 5 marzo 2026 · Step 3 di 7</div>
        <div style={{ display: 'flex', gap: 4, marginTop: 18 }}>
          {[['overview','Panoramica'],['canvas','Business Model'],['swot','SWOT'],['plan','Business Plan'],['tutor','Tutoraggio']].map(([k, l]) => (
            <button key={k} onClick={() => setTab(k)} style={{
              background: tab === k ? 'white' : 'rgba(255,255,255,0.1)',
              color: tab === k ? 'var(--ig-teal-800)' : 'rgba(255,255,255,0.8)',
              border: 'none', padding: '10px 14px', borderRadius: '8px 8px 0 0',
              fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit',
            }}>{l}</button>
          ))}
        </div>
      </div>
      <div style={{ padding: 24 }}>
        {tab === 'overview' && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 18 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700 }}>Avanzamento percorso</h3>
              <span style={{ fontSize: 13, color: 'var(--ig-teal-800)', fontWeight: 700 }}>42% completato</span>
            </div>
            <div style={{ height: 8, background: 'var(--ig-ink-150)', borderRadius: 999, overflow: 'hidden', marginBottom: 24 }}>
              <div style={{ width: '42%', height: '100%', background: 'var(--ig-teal-700)' }}/>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                ['Candidatura', 'done'],
                ['Colloquio orientamento', 'done'],
                ['Analisi idea', 'done'],
                ['Business Model Canvas', 'active'],
                ['Business Plan', 'pending'],
                ['Ricerca incentivi', 'pending'],
                ['Accompagnamento al bando', 'pending'],
              ].map(([l, s], i) => (
                <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 12, background: s === 'active' ? 'var(--ig-teal-50)' : 'transparent', borderRadius: 8 }}>
                  <div style={{ width: 28, height: 28, borderRadius: '50%', background: s === 'done' ? 'var(--ig-green-600)' : s === 'active' ? 'var(--ig-teal-700)' : 'var(--ig-ink-100)', color: s === 'pending' ? 'var(--ig-ink-400)' : 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 11 }}>
                    {s === 'done' ? <I.Check size={14} strokeWidth={3}/> : i+1}
                  </div>
                  <span style={{ flex: 1, fontSize: 14, fontWeight: s === 'active' ? 700 : 500, color: 'var(--ig-ink-900)' }}>{l}</span>
                  {s === 'active' && <span className="ig-badge ig-badge--state-valid">In corso</span>}
                </div>
              ))}
            </div>
          </div>
        )}
        {tab === 'canvas' && (
          <div>
            <p style={{ fontSize: 14, color: 'var(--ig-ink-700)', marginBottom: 16 }}>Compila i 9 blocchi del tuo modello di business insieme al tutor.</p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
              {[
                ['Partner chiave', 'Produttori locali, wedding planner, CCIAA'],
                ['Attività chiave', 'Preparazione menu, logistica, servizio evento'],
                ['Proposta di valore', 'Catering 100% siciliano · materie prime km 0'],
                ['Risorse chiave', 'Food truck, cucina, brigata freelance'],
                ['Relazioni clienti', 'Consulenza pre · followup post evento'],
                ['Canali', 'Sito + booking · social · wedding planner'],
                ['Segmenti', 'Coppie 25-40 · PMI · enti pubblici'],
                ['Struttura costi', 'Investimento 38k€ · operativi 4-8k€/mese'],
                ['Ricavi', '2.5–8k€ per evento · target 30-40 eventi/anno'],
              ].map(([t, d]) => (
                <div key={t} style={{ padding: 12, border: '1px solid var(--ig-border-soft)', borderRadius: 8 }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-teal-700)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 4 }}>{t}</div>
                  <div style={{ fontSize: 12, color: 'var(--ig-ink-700)', lineHeight: 1.4 }}>{d}</div>
                </div>
              ))}
            </div>
            <button className="ig-btn ig-btn--primary ig-btn--sm" style={{ marginTop: 14 }} onClick={() => toast.success('Modifiche salvate', 'BMC aggiornato')}><I.Check size={14}/> Salva modifiche</button>
          </div>
        )}
        {tab === 'swot' && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            {[
              ['Punti di forza', 'var(--ig-green-700)', ['Materie prime di qualità a km 0', 'Tradizione gastronomica siciliana', 'Costi operativi flessibili (food truck)']],
              ['Debolezze', 'var(--ig-amber-800)', ['Competenze contabili limitate', 'Capitale iniziale da reperire', 'Brand riconoscibilità zero']],
              ['Opportunità', 'var(--ig-blue-700)', ['Turismo enogastronomico in crescita', 'Bandi giovani imprese', 'Domanda wedding ennese']],
              ['Minacce', 'var(--ig-red-700)', ['Concorrenza grandi catering', 'Stagionalità eventi', 'Inflazione materie prime']],
            ].map(([t, c, items]) => (
              <div key={t} style={{ padding: 16, border: `1px solid ${c}`, borderRadius: 8, background: `color-mix(in srgb, ${c} 6%, white)` }}>
                <div style={{ fontSize: 13, fontWeight: 800, color: c, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 10 }}>{t}</div>
                <ul style={{ paddingLeft: 18, margin: 0, fontSize: 12, color: 'var(--ig-ink-700)', lineHeight: 1.6 }}>
                  {items.map((it, i) => <li key={i}>{it}</li>)}
                </ul>
              </div>
            ))}
          </div>
        )}
        {tab === 'plan' && (
          <div>
            <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 14 }}>Business Plan</h3>
            <div style={{ padding: 20, background: 'var(--ig-ink-50)', borderRadius: 10, border: '2px dashed var(--ig-border)', textAlign: 'center', marginBottom: 16 }}>
              <I.Doc size={32} color="var(--ig-ink-400)" style={{ margin: '0 auto 10px' }}/>
              <div style={{ fontSize: 13, color: 'var(--ig-ink-700)', marginBottom: 12 }}>Carica la prima bozza del tuo business plan (PDF, max 10 MB)</div>
              <button onClick={() => toast.success('Business plan caricato', 'businessplan_v1.pdf · 2.3 MB')} className="ig-btn ig-btn--primary ig-btn--sm"><I.Plus size={14}/> Carica file</button>
            </div>
            <label className="ig-label">Fabbisogno finanziario stimato</label>
            <input className="ig-input" defaultValue="65.000€"/>
          </div>
        )}
        {tab === 'tutor' && (
          <div>
            <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 14 }}>Tutoraggio</h3>
            <div style={{ padding: 18, background: 'var(--ig-teal-50)', borderRadius: 10, marginBottom: 14, display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 44, height: 44, borderRadius: '50%', background: 'var(--ig-teal-600)', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 14 }}>FB</div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 700 }}>Francesco Bellomo</div>
                <div style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}>Tutor Fare Impresa · impresa@informagiovani.enna.it</div>
              </div>
              <Link to="/prenota?ref=tutor" style={{ marginLeft: 'auto' }}><button className="ig-btn ig-btn--primary ig-btn--sm"><I.Calendar size={14}/> Prenota incontro</button></Link>
            </div>
            <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
              {[
                ['18 mar 10:00', 'Incontro tutor', 'Revisione BMC'],
                ['5 mar', 'Completato', 'Idea food truck · BMC iniziale'],
                ['18 feb', 'Completato', 'Orientamento autoimpiego'],
              ].map(([d, t, desc], i) => (
                <div key={i} style={{ padding: 14, borderBottom: i < 2 ? '1px solid var(--ig-border-soft)' : 'none', display: 'flex', gap: 14 }}>
                  <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', fontFamily: 'var(--ig-font-mono)', minWidth: 100 }}>{d}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-900)' }}>{t}</div>
                    <div style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}>{desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================
// CV / DOCS
// ============================================================
function CVDocs() {
  const [storeState, dispatch] = useStore();
  const toast = useToast();
  const cv = storeState.cv;
  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, marginBottom: 18, letterSpacing: '-0.02em' }}>Curriculum e documenti</h2>
      <div className="ig-card" style={{ padding: 24, marginBottom: 16 }}>
        <h3 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)', marginBottom: 14 }}>Il tuo CV</h3>
        {cv.uploaded ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 16, background: 'var(--ig-blue-50)', borderRadius: 10 }}>
            <I.Doc size={28} color="var(--ig-blue-700)"/>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 700 }}>{cv.filename}</div>
              <div style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}>{cv.size} · caricato 8 giorni fa</div>
            </div>
            <button className="ig-btn ig-btn--secondary ig-btn--sm" onClick={() => toast.success('Download avviato', cv.filename)}><I.Download size={14}/> Scarica</button>
            <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ color: 'var(--ig-red-700)' }} onClick={() => { dispatch({ type: 'SET_CV', cv: { uploaded: false } }); toast.info('CV rimosso'); }}>Rimuovi</button>
          </div>
        ) : (
          <div style={{ padding: 24, border: '2px dashed var(--ig-border)', background: 'var(--ig-ink-50)', borderRadius: 10, textAlign: 'center' }}>
            <I.Doc size={36} color="var(--ig-ink-400)" style={{ margin: '0 auto 10px' }}/>
            <div style={{ fontSize: 13, color: 'var(--ig-ink-700)', marginBottom: 12 }}>Nessun CV caricato</div>
            <button className="ig-btn ig-btn--primary ig-btn--sm" onClick={() => { dispatch({ type: 'SET_CV', cv: { uploaded: true, filename: 'CV_2026.pdf', size: '198 KB' } }); toast.success('CV caricato', 'CV_2026.pdf · 198 KB'); }}><I.Plus size={14}/> Carica CV</button>
          </div>
        )}
      </div>
      <div className="ig-card" style={{ padding: 24 }}>
        <h3 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)', marginBottom: 14 }}>Altri documenti</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {[['Diploma tecnico.pdf', '1.2 MB'], ['Carta identità.pdf', '312 KB'], ['Lettera motivazionale.pdf', '145 KB · bozza']].map(([n, m]) => (
            <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 12, border: '1px solid var(--ig-border-soft)', borderRadius: 8 }}>
              <I.Doc size={18} color="var(--ig-blue-700)"/>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{n}</div>
                <div style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>{m}</div>
              </div>
              <button className="ig-btn ig-btn--ghost ig-btn--sm"><I.Download size={14}/></button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Notifiche() {
  const toast = useToast();
  return (
    <div className="ig-card" style={{ padding: 28 }}>
      <h2 style={{ fontSize: 22, fontWeight: 700, marginBottom: 18 }}>Preferenze notifiche</h2>
      {[
        ['Promemoria scadenze · email', true],
        ['Promemoria appuntamenti · email + SMS', true],
        ['Newsletter settimanale Informagiovani', true],
        ['Nuove opportunità in linea col mio profilo', true],
        ['Comunicazioni partner territoriali', false],
        ['Risposte ai miei ticket · email', true],
      ].map(([l, on]) => (
        <ToggleRow key={l} label={l} initial={on} onChange={(v) => toast.success(v ? 'Notifica attivata' : 'Notifica disattivata', l)}/>
      ))}
    </div>
  );
}

function ToggleRow({ label, initial, onChange }) {
  const [on, setOn] = useState(initial);
  const toggle = () => { setOn(!on); onChange(!on); };
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 0', borderBottom: '1px solid var(--ig-border-soft)' }}>
      <button onClick={toggle} style={{
        display: 'inline-flex', width: 38, height: 22, borderRadius: 999,
        background: on ? 'var(--ig-blue-700)' : 'var(--ig-ink-300)',
        padding: 2, transition: 'background .15s', border: 'none', cursor: 'pointer',
      }}>
        <span style={{ width: 18, height: 18, borderRadius: '50%', background: 'white', transform: on ? 'translateX(16px)' : 'translateX(0)', transition: 'transform .15s' }}/>
      </button>
      <span style={{ fontSize: 14, color: 'var(--ig-ink-700)', flex: 1 }}>{label}</span>
    </div>
  );
}

function Privacy() {
  const confirm = useConfirm();
  const toast = useToast();
  return (
    <div className="ig-card" style={{ padding: 28 }}>
      <h2 style={{ fontSize: 22, fontWeight: 700, marginBottom: 6 }}>Privacy e consensi</h2>
      <p style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginBottom: 22 }}>Gestisci i tuoi consensi e le richieste GDPR sui tuoi dati personali.</p>
      <h3 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)', marginBottom: 14 }}>Consensi attivi</h3>
      {[
        ['Trattamento dati per il servizio Informagiovani', true, 'obbligatorio'],
        ['Profilazione per opportunità consigliate', true, 'opzionale'],
        ['Comunicazioni partner territoriali', false, 'opzionale'],
        ['Anonimizzazione dati per statistiche', true, 'opzionale'],
      ].map(([l, on, type]) => (
        <ToggleRow key={l} label={`${l} · ${type}`} initial={on} onChange={(v) => toast.info(v ? 'Consenso confermato' : 'Consenso revocato', l)}/>
      ))}
      <div style={{ marginTop: 28, paddingTop: 22, borderTop: '1px solid var(--ig-border-soft)' }}>
        <h3 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)', marginBottom: 14 }}>Diritti GDPR</h3>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
          <button className="ig-btn ig-btn--secondary" onClick={() => toast.success('Richiesta inviata', 'Riceverai l\u2019export via email entro 30 giorni.')}><I.Download size={14}/> Richiedi export dati</button>
          <button className="ig-btn ig-btn--danger" onClick={async () => {
            const ok = await confirm({
              title: 'Cancellare definitivamente il tuo account?',
              message: 'Tutti i tuoi dati, opportunità salvate, richieste e percorsi saranno eliminati in modo irreversibile entro 30 giorni. Riceverai conferma via email.',
              danger: true, confirmLabel: 'Procedi con la richiesta', icon: <I.Alert size={20}/>,
            });
            if (ok) toast.warning('Richiesta di cancellazione registrata', 'Operatori e DPO ti contatteranno entro 7 giorni.');
          }}><I.Alert size={14}/> Richiedi cancellazione</button>
        </div>
      </div>
    </div>
  );
}

window.PROTO_AREA = AreaPersonale;

})();
