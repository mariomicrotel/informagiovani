/* global React, IGIcons, IG_UI, IG_DATA */
(function(){
var { useState } = React;
var I = IGIcons;
var { Link, navigate, useToast, useStore } = IG_UI;
var { SCHEDE, EVENTI } = IG_DATA;

// ============================================================
// MULTI-STEP BOOKING FORM
// ============================================================
function PublicBooking({ route }) {
  const refId = route.query.ref;
  const refScheda = refId ? SCHEDE.find(s => s.id === refId) : null;
  const [step, setStep] = useState(1);
  const [, dispatch] = useStore();
  const toast = useToast();

  const [data, setData] = useState({
    nome: 'Salvatore',
    cognome: 'Catanzaro',
    email: 's.catanzaro@email.it',
    telefono: '+39 320 412 8745',
    eta: '22',
    argomento: refScheda?.area || '',
    note: refScheda ? `Riferimento: ${refScheda.title}` : '',
    canale: 'In presenza',
    giorno: '',
    fascia: 'Mattina · 9:00 – 13:00',
    privacy: false,
  });
  const [errors, setErrors] = useState({});

  const update = (k, v) => setData(d => ({ ...d, [k]: v }));

  const validate = (s) => {
    const e = {};
    if (s === 1) {
      if (!data.nome.trim()) e.nome = 'Campo obbligatorio';
      if (!data.cognome.trim()) e.cognome = 'Campo obbligatorio';
      if (!data.email.includes('@')) e.email = 'Email non valida';
      if (!data.telefono.trim()) e.telefono = 'Campo obbligatorio';
    }
    if (s === 2) {
      if (!data.argomento) e.argomento = 'Seleziona un argomento';
    }
    if (s === 3) {
      if (!data.giorno) e.giorno = 'Seleziona un giorno disponibile';
    }
    if (s === 4) {
      if (!data.privacy) e.privacy = 'Devi accettare l\u2019informativa privacy';
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const next = () => { if (validate(step)) setStep(step + 1); };
  const prev = () => setStep(step - 1);

  const submit = () => {
    if (!validate(4)) return;
    const id = `AP-${Math.floor(1000 + Math.random() * 9000)}`;
    dispatch({
      type: 'ADD_APPOINTMENT',
      appointment: {
        id, user: `${data.nome} ${data.cognome}`, userId: 'USR-001284',
        when: data.giorno + ' ' + data.fascia.split('·')[1].trim(),
        date: `${data.giorno} · ${data.fascia.split('·')[1].trim()}`,
        topic: refScheda ? refScheda.title : data.note || 'Orientamento generale',
        op: 'M. Greco', channel: data.canale,
      }
    });
    setStep(5);
  };

  return (
    <div className="ig" style={{ background: 'var(--ig-bg)' }}>
      <div style={{ background: 'white', borderBottom: '1px solid var(--ig-border-soft)' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '18px 32px' }}>
          <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', display: 'flex', alignItems: 'center', gap: 6 }}>
            <Link to="/" style={{ color: 'var(--ig-ink-500)' }}>Home</Link>
            <I.ChevR size={12}/>
            <span style={{ color: 'var(--ig-ink-900)', fontWeight: 600 }}>Prenota un colloquio</span>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 760, margin: '40px auto', padding: '0 32px 60px' }}>
        <h1 style={{ fontSize: 32, fontWeight: 700, letterSpacing: '-0.025em', marginBottom: 8 }}>Prenota un colloquio</h1>
        <p style={{ fontSize: 15, color: 'var(--ig-ink-500)', marginBottom: 28 }}>Indica il tema del colloquio e la fascia oraria preferita. Sarai ricontattato per la conferma entro 24 ore lavorative.</p>

        {/* Stepper */}
        {step < 5 && (
          <div className="ig-card" style={{ padding: '20px 28px', marginBottom: 18, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8, position: 'relative' }}>
            {[['Dati personali', 1], ['Argomento', 2], ['Disponibilità', 3], ['Conferma', 4]].map(([label, n], i) => {
              const active = step === n;
              const done = step > n;
              return (
                <div key={n} style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 10, position: 'relative' }}>
                  <div style={{
                    width: 32, height: 32, borderRadius: '50%',
                    background: done ? 'var(--ig-green-600)' : active ? 'var(--ig-blue-700)' : 'var(--ig-ink-100)',
                    color: done || active ? 'white' : 'var(--ig-ink-500)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 13, fontWeight: 800, flex: '0 0 auto',
                  }}>
                    {done ? <I.Check size={14} strokeWidth={3}/> : n}
                  </div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: active ? 'var(--ig-ink-900)' : 'var(--ig-ink-500)', flex: 1 }}>{label}</div>
                  {i < 3 && <div style={{ position: 'absolute', right: -20, top: 16, width: 40, height: 2, background: done ? 'var(--ig-green-600)' : 'var(--ig-ink-150)' }}/>}
                </div>
              );
            })}
          </div>
        )}

        {step === 1 && (
          <div className="ig-card" style={{ padding: 28 }}>
            <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 18 }}>I tuoi dati personali</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
              <Field label="Nome" value={data.nome} onChange={v => update('nome', v)} error={errors.nome}/>
              <Field label="Cognome" value={data.cognome} onChange={v => update('cognome', v)} error={errors.cognome}/>
              <Field label="Email" value={data.email} onChange={v => update('email', v)} error={errors.email}/>
              <Field label="Telefono" value={data.telefono} onChange={v => update('telefono', v)} error={errors.telefono}/>
            </div>
            <div style={{ marginTop: 14 }}>
              <FieldSelect label="Fascia di età" value={data.eta} options={['14-17', '18-25', '26-35', '36+']} onChange={v => update('eta', v)}/>
            </div>
            <FormNav step={step} next={next}/>
          </div>
        )}

        {step === 2 && (
          <div className="ig-card" style={{ padding: 28 }}>
            <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 8 }}>Argomento del colloquio</h3>
            <p style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginBottom: 18 }}>Aiutaci ad assegnarti l\u2019operatore giusto.</p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10, marginBottom: 16 }}>
              {[
                ['lavoro', 'Lavoro', <I.Briefcase size={18}/>],
                ['formazione', 'Formazione', <I.GradCap size={18}/>],
                ['impresa', 'Fare Impresa', <I.Bulb size={18}/>],
                ['estero', 'Estero', <I.Globe size={18}/>],
                ['concorso', 'Concorsi', <I.Award size={18}/>],
                ['diritti', 'Diritti / Servizi', <I.Heart size={18}/>],
              ].map(([k, label, ico]) => {
                const sel = data.argomento === k;
                return (
                  <button key={k} type="button" onClick={() => update('argomento', k)} style={{
                    padding: 16, border: `1px solid ${sel ? 'var(--ig-blue-700)' : 'var(--ig-border)'}`,
                    background: sel ? 'var(--ig-blue-50)' : 'white', borderRadius: 10,
                    display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer', fontFamily: 'inherit',
                    fontSize: 14, fontWeight: 600, color: sel ? 'var(--ig-blue-700)' : 'var(--ig-ink-700)', textAlign: 'left',
                  }}>
                    <span style={{ color: sel ? 'var(--ig-blue-700)' : 'var(--ig-ink-500)' }}>{ico}</span>
                    {label}
                    {sel && <I.Check size={16} style={{ marginLeft: 'auto' }}/>}
                  </button>
                );
              })}
            </div>
            {errors.argomento && <ErrLine msg={errors.argomento}/>}
            <div style={{ marginTop: 14 }}>
              <label className="ig-label">Aggiungi note (opzionale)</label>
              <textarea className="ig-textarea" value={data.note} onChange={e => update('note', e.target.value)} placeholder="Descrivi brevemente cosa vorresti chiedere…" style={{ minHeight: 90 }}/>
            </div>
            <FormNav step={step} next={next} prev={prev}/>
          </div>
        )}

        {step === 3 && (
          <div className="ig-card" style={{ padding: 28 }}>
            <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 18 }}>Canale e disponibilità</h3>
            <label className="ig-label">Canale preferito</label>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10, marginBottom: 18 }}>
              {[
                ['In presenza', <I.User size={18}/>, 'Sportello principale · Piazza Garibaldi'],
                ['Videochiamata', <I.Video size={18}/>, 'Google Meet · link generato automaticamente'],
                ['Telefono', <I.Phone size={18}/>, 'Risponde l\u2019operatore al numero indicato'],
                ['Email', <I.Mail size={18}/>, 'Risposta entro 48 ore lavorative'],
              ].map(([ch, ico, hint]) => {
                const sel = data.canale === ch;
                return (
                  <button key={ch} type="button" onClick={() => update('canale', ch)} style={{
                    padding: 14, border: `1px solid ${sel ? 'var(--ig-blue-700)' : 'var(--ig-border)'}`,
                    background: sel ? 'var(--ig-blue-50)' : 'white', borderRadius: 10,
                    cursor: 'pointer', fontFamily: 'inherit', textAlign: 'left',
                  }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
                      <span style={{ color: sel ? 'var(--ig-blue-700)' : 'var(--ig-ink-500)' }}>{ico}</span>
                      <span style={{ fontSize: 14, fontWeight: 700, color: sel ? 'var(--ig-blue-700)' : 'var(--ig-ink-900)' }}>{ch}</span>
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}>{hint}</div>
                  </button>
                );
              })}
            </div>

            <label className="ig-label">Giorno preferito</label>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 6 }}>
              {[
                ['Lun 17 mar', 1], ['Mar 18 mar', 1], ['Mer 19 mar', 1], ['Gio 20 mar', 1],
                ['Ven 21 mar', 1], ['Sab 22 mar · ridotto', 0],
              ].map(([g, av]) => {
                const sel = data.giorno === g;
                return (
                  <button key={g} type="button" onClick={() => update('giorno', g)} style={{
                    height: 42, padding: '0 14px', borderRadius: 8,
                    background: sel ? 'var(--ig-blue-700)' : av ? 'white' : 'var(--ig-ink-50)',
                    border: `1px solid ${sel ? 'var(--ig-blue-700)' : 'var(--ig-border)'}`,
                    color: sel ? 'white' : av ? 'var(--ig-ink-900)' : 'var(--ig-ink-400)',
                    fontSize: 13, fontWeight: 600, cursor: av ? 'pointer' : 'not-allowed',
                    opacity: av ? 1 : 0.5, fontFamily: 'inherit',
                  }}>{g}</button>
                );
              })}
            </div>
            {errors.giorno && <ErrLine msg={errors.giorno}/>}

            <label className="ig-label" style={{ marginTop: 16 }}>Fascia oraria</label>
            <div style={{ display: 'flex', gap: 8 }}>
              {['Mattina · 9:00 – 13:00', 'Pomeriggio · 15:00 – 17:30'].map(f => {
                const sel = data.fascia === f;
                return (
                  <button key={f} type="button" onClick={() => update('fascia', f)} style={{
                    flex: 1, height: 44, borderRadius: 8,
                    background: sel ? 'var(--ig-blue-700)' : 'white',
                    border: `1px solid ${sel ? 'var(--ig-blue-700)' : 'var(--ig-border)'}`,
                    color: sel ? 'white' : 'var(--ig-ink-700)',
                    fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit',
                  }}>{f}</button>
                );
              })}
            </div>

            <FormNav step={step} next={next} prev={prev}/>
          </div>
        )}

        {step === 4 && (
          <div className="ig-card" style={{ padding: 28 }}>
            <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 18 }}>Conferma e invia</h3>

            <div style={{ background: 'var(--ig-ink-50)', borderRadius: 10, padding: 18, marginBottom: 20 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>Riepilogo della tua richiesta</div>
              <Recap label="Nome" value={`${data.nome} ${data.cognome}`}/>
              <Recap label="Contatti" value={`${data.email} · ${data.telefono}`}/>
              <Recap label="Argomento" value={data.argomento ? data.argomento.charAt(0).toUpperCase() + data.argomento.slice(1) : '—'}/>
              <Recap label="Canale" value={data.canale}/>
              <Recap label="Quando" value={`${data.giorno} · ${data.fascia.split('·')[1].trim()}`}/>
              {refScheda && <Recap label="Riferimento scheda" value={refScheda.title} mono/>}
              {data.note && <Recap label="Note" value={data.note}/>}
            </div>

            <label style={{ display: 'flex', alignItems: 'flex-start', gap: 10, padding: 14, border: `1px solid ${errors.privacy ? 'var(--ig-red-600)' : 'var(--ig-border-soft)'}`, borderRadius: 8, cursor: 'pointer' }}>
              <input type="checkbox" checked={data.privacy} onChange={e => update('privacy', e.target.checked)} style={{ display: 'none' }}/>
              <span style={{
                width: 20, height: 20, borderRadius: 4,
                border: data.privacy ? 'none' : '1.5px solid var(--ig-ink-300)',
                background: data.privacy ? 'var(--ig-primary)' : 'white',
                display: 'flex', alignItems: 'center', justifyContent: 'center', flex: '0 0 auto', marginTop: 1,
              }}>{data.privacy && <I.Check size={14} color="white" strokeWidth={3}/>}</span>
              <div style={{ fontSize: 13, color: 'var(--ig-ink-700)' }}>
                Ho letto e accetto l&apos;<a href="#" onClick={(e) => e.preventDefault()}>informativa sulla privacy</a> del Comune di Enna. I dati saranno utilizzati solo per la gestione del servizio Informagiovani.
              </div>
            </label>
            {errors.privacy && <ErrLine msg={errors.privacy}/>}

            <FormNav step={step} prev={prev} submit={submit}/>
          </div>
        )}

        {step === 5 && (
          <div className="ig-card" style={{ padding: '52px 36px', textAlign: 'center' }}>
            <div style={{ width: 78, height: 78, borderRadius: '50%', background: 'var(--ig-green-100)', color: 'var(--ig-green-600)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px', border: '6px solid var(--ig-green-50)' }}>
              <I.Check size={38} strokeWidth={2.5}/>
            </div>
            <h3 style={{ fontSize: 26, fontWeight: 700, letterSpacing: '-0.01em', marginBottom: 10 }}>Richiesta di colloquio inviata correttamente</h3>
            <p style={{ fontSize: 15, color: 'var(--ig-ink-500)', lineHeight: 1.55, marginBottom: 24, maxWidth: 460, margin: '0 auto 24px' }}>
              Riceverai una conferma dagli operatori entro 24 ore lavorative all\u2019indirizzo <strong style={{ color: 'var(--ig-ink-700)' }}>{data.email}</strong>. Puoi seguire lo stato della tua richiesta dalla tua area personale.
            </p>
            <div style={{ background: 'var(--ig-blue-50)', border: '1px solid var(--ig-blue-100)', borderRadius: 10, padding: 18, marginBottom: 24, display: 'inline-flex', flexDirection: 'column', gap: 6, fontSize: 14 }}>
              <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-blue-700)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Riferimento appuntamento</span>
              <span className="ig-mono" style={{ fontWeight: 700, color: 'var(--ig-blue-800)', fontSize: 16 }}>#AP-2026-{Math.floor(1000 + Math.random()*9000)}</span>
              <span style={{ color: 'var(--ig-ink-500)', fontSize: 12 }}>{data.giorno} · {data.fascia} · {data.canale}</span>
            </div>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'center' }}>
              <Link to="/area/appuntamenti"><button className="ig-btn ig-btn--primary">Vai all\u2019area personale <I.ArrowR size={14}/></button></Link>
              <Link to="/"><button className="ig-btn ig-btn--secondary">Torna alla home</button></Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function Field({ label, value, onChange, error, type = 'text' }) {
  return (
    <div>
      <label className="ig-label">{label}</label>
      <input
        className="ig-input"
        type={type} value={value}
        onChange={e => onChange(e.target.value)}
        style={{ borderColor: error ? 'var(--ig-red-600)' : 'var(--ig-border)', background: error ? 'var(--ig-red-50)' : 'white' }}
      />
      {error && <ErrLine msg={error}/>}
    </div>
  );
}
function FieldSelect({ label, value, options, onChange }) {
  return (
    <div>
      <label className="ig-label">{label}</label>
      <select className="ig-input" value={value} onChange={e => onChange(e.target.value)}>
        {options.map(o => <option key={o} value={o}>{o}</option>)}
      </select>
    </div>
  );
}
function ErrLine({ msg }) {
  return <div style={{ fontSize: 12, color: 'var(--ig-red-700)', marginTop: 6, display: 'flex', alignItems: 'center', gap: 4 }}><I.Alert size={12}/> {msg}</div>;
}
function Recap({ label, value, mono }) {
  return (
    <div style={{ display: 'flex', padding: '6px 0', borderBottom: '1px dashed var(--ig-border-soft)', fontSize: 13 }}>
      <span style={{ color: 'var(--ig-ink-500)', width: 160, flex: '0 0 auto' }}>{label}</span>
      <span style={{ color: 'var(--ig-ink-900)', fontWeight: 600, flex: 1, fontFamily: mono ? 'var(--ig-font-mono)' : 'inherit', fontSize: mono ? 12 : 13 }}>{value}</span>
    </div>
  );
}
function FormNav({ step, next, prev, submit }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 28, paddingTop: 20, borderTop: '1px solid var(--ig-border-soft)' }}>
      {prev ? <button className="ig-btn ig-btn--ghost" onClick={prev}><I.ArrowL size={14}/> Indietro</button> : <div/>}
      <div style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}>Passo <strong style={{ color: 'var(--ig-ink-900)' }}>{step}</strong> di 4</div>
      {submit ? (
        <button className="ig-btn ig-btn--primary" onClick={submit}><I.Send size={14}/> Invia richiesta</button>
      ) : (
        <button className="ig-btn ig-btn--primary" onClick={next}>Continua <I.ArrowR size={14}/></button>
      )}
    </div>
  );
}

// ============================================================
// TICKET FORM
// ============================================================
function PublicTicket({ route }) {
  const refId = route.query.ref;
  const refScheda = refId ? SCHEDE.find(s => s.id === refId) : null;
  const [, dispatch] = useStore();
  const toast = useToast();
  const [data, setData] = useState({
    nome: 'Salvatore',
    cognome: 'Catanzaro',
    email: 's.catanzaro@email.it',
    telefono: '+39 320 412 8745',
    categoria: refScheda?.area || '',
    oggetto: refScheda ? `Informazioni · ${refScheda.title}` : '',
    messaggio: refScheda ? `Vorrei ricevere chiarimenti sulla scheda "${refScheda.title}"…` : '',
    allegato: false,
    privacy: false,
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(null);

  const update = (k, v) => setData(d => ({ ...d, [k]: v }));

  const submit = () => {
    const e = {};
    if (!data.email.includes('@')) e.email = 'Email non valida';
    if (!data.categoria) e.categoria = 'Seleziona una categoria';
    if (!data.oggetto.trim()) e.oggetto = 'Aggiungi un oggetto';
    if (!data.messaggio.trim()) e.messaggio = 'Aggiungi il tuo messaggio';
    if (!data.privacy) e.privacy = 'Devi accettare l\u2019informativa';
    setErrors(e);
    if (Object.keys(e).length) return;
    const num = `IG-2026-${Math.floor(10000 + Math.random() * 90000)}`;
    dispatch({
      type: 'ADD_TICKET',
      ticket: {
        id: num, subject: data.oggetto, user: `${data.nome} ${data.cognome}`, userId: 'USR-001284',
        avatar: 'SC', avatarBg: '#e8a93a',
        area: data.categoria, areaLabel: data.categoria,
        priority: 'media', status: 'new', operator: null,
        opened: 'adesso', message: data.messaggio, notes: 0,
      }
    });
    setSubmitted(num);
  };

  if (submitted) {
    return (
      <div className="ig" style={{ background: 'var(--ig-bg)', padding: '60px 32px', minHeight: 600 }}>
        <div className="ig-card" style={{ maxWidth: 640, margin: '0 auto', padding: '48px 36px', textAlign: 'center' }}>
          <div style={{ width: 78, height: 78, borderRadius: '50%', background: 'var(--ig-green-100)', color: 'var(--ig-green-600)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 18px', border: '6px solid var(--ig-green-50)' }}>
            <I.Check size={36} strokeWidth={2.5}/>
          </div>
          <h2 style={{ fontSize: 24, fontWeight: 700, marginBottom: 8 }}>Richiesta ricevuta</h2>
          <p style={{ fontSize: 15, color: 'var(--ig-ink-500)', lineHeight: 1.55, marginBottom: 20 }}>
            La tua richiesta è stata registrata. Riceverai una risposta entro 48 ore lavorative.
          </p>
          <div style={{ background: 'var(--ig-blue-50)', border: '1px solid var(--ig-blue-100)', borderRadius: 10, padding: 16, marginBottom: 24, display: 'inline-flex', gap: 12, alignItems: 'center' }}>
            <span style={{ fontSize: 11, color: 'var(--ig-ink-500)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Numero richiesta</span>
            <span className="ig-mono" style={{ fontWeight: 800, color: 'var(--ig-blue-800)', fontSize: 18 }}>#{submitted}</span>
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
            <Link to="/area/richieste"><button className="ig-btn ig-btn--primary">Segui la richiesta <I.ArrowR size={14}/></button></Link>
            <Link to="/"><button className="ig-btn ig-btn--secondary">Torna alla home</button></Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="ig" style={{ background: 'var(--ig-bg)' }}>
      <div style={{ background: 'white', borderBottom: '1px solid var(--ig-border-soft)' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '18px 32px' }}>
          <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', display: 'flex', alignItems: 'center', gap: 6 }}>
            <Link to="/" style={{ color: 'var(--ig-ink-500)' }}>Home</Link><I.ChevR size={12}/>
            <span style={{ color: 'var(--ig-ink-900)', fontWeight: 600 }}>Invia una richiesta</span>
          </div>
        </div>
      </div>
      <div style={{ maxWidth: 720, margin: '40px auto', padding: '0 32px 60px' }}>
        <h1 style={{ fontSize: 32, fontWeight: 700, letterSpacing: '-0.025em', marginBottom: 8 }}>Invia una richiesta</h1>
        <p style={{ fontSize: 15, color: 'var(--ig-ink-500)', marginBottom: 24 }}>La tua richiesta è registrata come ticket. Potrai seguirne lo stato dalla tua area personale.</p>
        <div className="ig-card" style={{ padding: 28 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <Field label="Nome" value={data.nome} onChange={v => update('nome', v)}/>
            <Field label="Cognome" value={data.cognome} onChange={v => update('cognome', v)}/>
            <Field label="Email" value={data.email} onChange={v => update('email', v)} error={errors.email}/>
            <Field label="Telefono" value={data.telefono} onChange={v => update('telefono', v)}/>
          </div>
          <div style={{ marginTop: 14 }}>
            <label className="ig-label">Categoria richiesta</label>
            <select className="ig-input" value={data.categoria} onChange={e => update('categoria', e.target.value)} style={{ borderColor: errors.categoria ? 'var(--ig-red-600)' : undefined }}>
              <option value="">Scegli una categoria…</option>
              <option value="lavoro">Lavoro</option>
              <option value="formazione">Formazione</option>
              <option value="impresa">Fare Impresa</option>
              <option value="estero">Estero</option>
              <option value="concorso">Concorsi</option>
              <option value="diritti">Diritti</option>
            </select>
            {errors.categoria && <ErrLine msg={errors.categoria}/>}
          </div>
          <div style={{ marginTop: 14 }}>
            <Field label="Oggetto" value={data.oggetto} onChange={v => update('oggetto', v)} error={errors.oggetto}/>
          </div>
          <div style={{ marginTop: 14 }}>
            <label className="ig-label">Messaggio</label>
            <textarea
              className="ig-textarea"
              value={data.messaggio}
              onChange={e => update('messaggio', e.target.value)}
              placeholder="Descrivi la tua richiesta con il maggior dettaglio possibile…"
              style={{ minHeight: 130, borderColor: errors.messaggio ? 'var(--ig-red-600)' : undefined }}
            />
            {errors.messaggio && <ErrLine msg={errors.messaggio}/>}
          </div>
          <div style={{ marginTop: 14 }}>
            <label className="ig-label">Allegato (opzionale)</label>
            <button onClick={() => { update('allegato', true); toast.info('File allegato', 'CV.pdf · 234 KB · simulato'); }} style={{
              padding: '20px', border: '2px dashed var(--ig-border)', background: 'var(--ig-ink-50)',
              borderRadius: 10, width: '100%', cursor: 'pointer', fontFamily: 'inherit',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, color: 'var(--ig-ink-500)',
            }}>
              {data.allegato ? (
                <>
                  <I.Doc size={20} color="var(--ig-blue-700)"/>
                  <span style={{ color: 'var(--ig-blue-700)', fontWeight: 600 }}>CV.pdf · 234 KB</span>
                  <I.Check size={16} color="var(--ig-green-600)"/>
                </>
              ) : (
                <>
                  <I.Plus size={18}/>
                  <span>Carica un documento (PDF, max 10 MB)</span>
                </>
              )}
            </button>
          </div>
          <label style={{ marginTop: 18, display: 'flex', alignItems: 'flex-start', gap: 10, padding: 14, border: `1px solid ${errors.privacy ? 'var(--ig-red-600)' : 'var(--ig-border-soft)'}`, borderRadius: 8, cursor: 'pointer' }}>
            <input type="checkbox" checked={data.privacy} onChange={e => update('privacy', e.target.checked)} style={{ display: 'none' }}/>
            <span style={{ width: 20, height: 20, borderRadius: 4, border: data.privacy ? 'none' : '1.5px solid var(--ig-ink-300)', background: data.privacy ? 'var(--ig-primary)' : 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', flex: '0 0 auto', marginTop: 1 }}>
              {data.privacy && <I.Check size={14} color="white" strokeWidth={3}/>}
            </span>
            <div style={{ fontSize: 13, color: 'var(--ig-ink-700)' }}>
              Ho letto e accetto l&apos;<a href="#" onClick={(e) => e.preventDefault()}>informativa sulla privacy</a>.
            </div>
          </label>
          {errors.privacy && <ErrLine msg={errors.privacy}/>}

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 24, paddingTop: 20, borderTop: '1px solid var(--ig-border-soft)' }}>
            <Link to="/"><button className="ig-btn ig-btn--ghost">Annulla</button></Link>
            <button className="ig-btn ig-btn--primary" onClick={submit}><I.Send size={14}/> Invia richiesta</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// EVENTI LIST
// ============================================================
function PublicEventi() {
  const PROTO_EVENT_ROW = window.PROTO_EVENT_ROW;
  return (
    <div className="ig" style={{ background: 'var(--ig-bg)' }}>
      <div style={{ background: 'white', borderBottom: '1px solid var(--ig-border-soft)' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '18px 32px 22px' }}>
          <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginBottom: 12 }}>
            <Link to="/" style={{ color: 'var(--ig-ink-500)' }}>Home</Link>
            <span style={{ margin: '0 8px' }}><I.ChevR size={12} style={{ verticalAlign: 'middle' }}/></span>
            <span style={{ color: 'var(--ig-ink-900)', fontWeight: 600 }}>Eventi</span>
          </div>
          <h1 style={{ fontSize: 32, fontWeight: 700, letterSpacing: '-0.025em', marginBottom: 6 }}>Eventi e workshop</h1>
          <p style={{ fontSize: 15, color: 'var(--ig-ink-500)' }}>{EVENTI.length} eventi prossimi · iscriviti in un click dalla tua area personale</p>
        </div>
      </div>
      <div style={{ maxWidth: 920, margin: '24px auto', padding: '0 32px 60px' }}>
        <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
          {EVENTI.map((e, i) => <PROTO_EVENT_ROW key={e.id} ev={e} last={i === EVENTI.length - 1}/>)}
        </div>
      </div>
    </div>
  );
}

window.PROTO_BOOKING = PublicBooking;
window.PROTO_TICKET = PublicTicket;
window.PROTO_EVENTI = PublicEventi;

})();
