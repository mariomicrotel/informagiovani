/* global React, IGIcons, IG_UI, IG_DATA */
(function(){
var { useState, useMemo, useRef } = React;
var I = IGIcons;
var { Link, navigate, useToast, useModal, useConfirm, useStore, getScheda, getTicket } = IG_UI;
var { SCHEDE, TICKET, UTENTI, OPERATORI, TICKET_STATUSES } = IG_DATA;

// ============================================================
// TICKET KANBAN — drag-and-drop between columns
// ============================================================
function BackendTickets({ route }) {
  const BackendShell = window.PROTO_BACKEND_SHELL;
  const [storeState, dispatch] = useStore();
  const toast = useToast();
  const [view, setView] = useState('kanban');
  const [dragged, setDragged] = useState(null);
  const [dragOver, setDragOver] = useState(null);

  // Build columns
  const allTickets = [...storeState.newTickets, ...TICKET];
  const cols = TICKET_STATUSES.map(s => ({
    ...s,
    tickets: allTickets.filter(t => (storeState.ticketStates[t.id] || t.status) === s.id),
  }));

  const onDragStart = (id) => setDragged(id);
  const onDragEnd = () => { setDragged(null); setDragOver(null); };
  const onDrop = (targetStatus) => {
    if (!dragged) return;
    const ticket = allTickets.find(t => t.id === dragged);
    const fromStatus = storeState.ticketStates[dragged] || ticket.status;
    if (fromStatus !== targetStatus) {
      dispatch({ type: 'SET_TICKET_STATUS', id: dragged, status: targetStatus });
      const newCol = TICKET_STATUSES.find(s => s.id === targetStatus);
      toast.success(`Ticket #${dragged} spostato`, `→ ${newCol.label}`);
    }
    onDragEnd();
  };

  return (
    <BackendShell route={route} active="Ticket" breadcrumb={[{ label: 'Console', to: '/backend' }, { label: 'Sportello' }, { label: 'Ticket' }]}>
      <div style={{ padding: '20px 28px 0', background: 'white', borderBottom: '1px solid var(--ig-border-soft)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 18 }}>
          <div>
            <h1 style={{ fontSize: 24, fontWeight: 700, letterSpacing: '-0.02em' }}>Ticket e richieste</h1>
            <p style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginTop: 4 }}>{allTickets.length} ticket totali · tempo medio risposta 18h · trascina le card tra le colonne per cambiare stato</p>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            <div style={{ display: 'flex', border: '1px solid var(--ig-border)', borderRadius: 6, overflow: 'hidden' }}>
              <button onClick={() => setView('kanban')} style={{ background: view === 'kanban' ? 'var(--ig-ink-900)' : 'white', color: view === 'kanban' ? 'white' : 'var(--ig-ink-700)', border: 'none', padding: '8px 12px', cursor: 'pointer', fontSize: 12, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 5 }}><I.Kanban size={13}/> Kanban</button>
              <button onClick={() => setView('list')} style={{ background: view === 'list' ? 'var(--ig-ink-900)' : 'white', color: view === 'list' ? 'white' : 'var(--ig-ink-700)', border: 'none', padding: '8px 12px', cursor: 'pointer', fontSize: 12, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 5 }}><I.List size={13}/> Lista</button>
            </div>
          </div>
        </div>
      </div>

      {view === 'kanban' ? (
        <div style={{ padding: '20px 28px 32px', overflowX: 'auto' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, minmax(220px, 1fr))', gap: 12, alignItems: 'flex-start' }}>
            {cols.map(col => (
              <div key={col.id}
                onDragOver={(e) => { e.preventDefault(); setDragOver(col.id); }}
                onDragLeave={() => setDragOver(o => o === col.id ? null : o)}
                onDrop={() => onDrop(col.id)}
                style={{
                  background: dragOver === col.id ? 'color-mix(in srgb, ' + col.color + ' 8%, var(--ig-ink-50))' : 'var(--ig-ink-50)',
                  border: dragOver === col.id ? `2px dashed ${col.color}` : '1px solid var(--ig-border-soft)',
                  borderRadius: 10, padding: 10,
                  transition: 'background .15s, border-color .15s',
                  minHeight: 240,
                }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12, padding: '4px 6px' }}>
                  <span style={{ width: 8, height: 8, borderRadius: '50%', background: col.color }}/>
                  <h3 style={{ fontSize: 12, fontWeight: 800, color: 'var(--ig-ink-900)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{col.label}</h3>
                  <span style={{ marginLeft: 'auto', fontSize: 11, fontWeight: 700, padding: '2px 7px', background: 'white', border: '1px solid var(--ig-border)', borderRadius: 999, color: 'var(--ig-ink-700)', fontFamily: 'var(--ig-font-mono)' }}>{col.tickets.length}</span>
                </div>
                {col.tickets.map(t => (
                  <TicketCard key={t.id} t={t} status={col.id} accent={col.color}
                    draggable
                    onDragStart={() => onDragStart(t.id)}
                    onDragEnd={onDragEnd}
                    isDragging={dragged === t.id}
                  />
                ))}
                {col.tickets.length === 0 && (
                  <div style={{ padding: 24, textAlign: 'center', color: 'var(--ig-ink-400)', fontSize: 12, fontStyle: 'italic' }}>
                    {dragOver === col.id ? 'Rilascia qui →' : 'Nessun ticket'}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div style={{ padding: '20px 28px 32px' }}>
          <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '70px 1fr 130px 100px 110px 110px 60px', gap: 12, padding: '12px 18px', background: 'var(--ig-ink-50)', borderBottom: '1px solid var(--ig-border-soft)', fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              <span>ID</span><span>Oggetto · utente</span><span>Area</span><span>Priorità</span><span>Stato</span><span>Operatore</span><span></span>
            </div>
            {allTickets.map((t, i) => {
              const status = storeState.ticketStates[t.id] || t.status;
              const sInfo = TICKET_STATUSES.find(s => s.id === status);
              const op = storeState.ticketOperator[t.id] || t.operator;
              return (
                <Link key={t.id} to={`/backend/ticket/${t.id}`} style={{ display: 'grid', gridTemplateColumns: '70px 1fr 130px 100px 110px 110px 60px', gap: 12, padding: '14px 18px', borderBottom: i < allTickets.length - 1 ? '1px solid var(--ig-border-soft)' : 'none', alignItems: 'center', textDecoration: 'none' }}>
                  <span style={{ fontFamily: 'var(--ig-font-mono)', fontSize: 11, color: 'var(--ig-ink-500)' }}>#{t.id}</span>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ig-ink-900)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t.subject}</div>
                    <div style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>{t.user} · {t.opened}</div>
                  </div>
                  <span className={`ig-badge ig-badge--${t.area}`} style={{ height: 20, fontSize: 10 }}>{t.areaLabel}</span>
                  <span style={{ fontSize: 12, color: t.priority === 'alta' ? 'var(--ig-red-700)' : t.priority === 'media' ? 'var(--ig-amber-800)' : 'var(--ig-ink-500)', fontWeight: 600 }}>● {t.priority}</span>
                  <span style={{ fontSize: 11, fontWeight: 700, color: sInfo.color }}>● {sInfo.label}</span>
                  <span style={{ fontSize: 12, color: 'var(--ig-ink-700)' }}>{op || '—'}</span>
                  <I.ChevR size={14} color="var(--ig-ink-400)"/>
                </Link>
              );
            })}
          </div>
        </div>
      )}
    </BackendShell>
  );
}

function TicketCard({ t, status, accent, draggable, onDragStart, onDragEnd, isDragging }) {
  const [storeState] = useStore();
  const op = storeState.ticketOperator[t.id] || t.operator;
  return (
    <div draggable={draggable} onDragStart={onDragStart} onDragEnd={onDragEnd} onClick={() => navigate(`/backend/ticket/${t.id}`)}
      className="ig-card"
      style={{
        padding: 12, marginBottom: 8,
        borderTop: `3px solid ${accent}`,
        cursor: draggable ? 'grab' : 'pointer',
        opacity: isDragging ? 0.4 : 1,
        boxShadow: isDragging ? 'none' : '0 1px 2px rgba(12,26,44,0.06)',
      }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
        <span style={{ fontFamily: 'var(--ig-font-mono)', fontSize: 10, color: 'var(--ig-ink-500)', fontWeight: 600 }}>#{t.id}</span>
        <span style={{ fontSize: 10, color: 'var(--ig-ink-400)' }}>{t.opened}</span>
      </div>
      <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-ink-900)', lineHeight: 1.35, marginBottom: 8 }}>{t.subject}</div>
      <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginBottom: 8 }}>
        <span className={`ig-badge ig-badge--${t.area}`} style={{ height: 18, fontSize: 9, padding: '0 6px' }}>{t.areaLabel}</span>
        <span style={{ height: 18, padding: '0 6px', borderRadius: 999, background: t.priority === 'alta' ? 'var(--ig-red-100)' : t.priority === 'media' ? 'var(--ig-amber-100)' : 'var(--ig-ink-100)', color: t.priority === 'alta' ? 'var(--ig-red-700)' : t.priority === 'media' ? 'var(--ig-amber-800)' : 'var(--ig-ink-700)', fontSize: 9, fontWeight: 700, display: 'inline-flex', alignItems: 'center' }}>{t.priority}</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, paddingTop: 6, borderTop: '1px solid var(--ig-border-soft)' }}>
        <div style={{ width: 22, height: 22, borderRadius: '50%', background: t.avatarBg, color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 9 }}>{t.avatar}</div>
        <span style={{ fontSize: 11, fontWeight: 600, color: 'var(--ig-ink-900)', flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t.user}</span>
        {op && <span style={{ fontSize: 10, color: 'var(--ig-ink-500)' }}>→ {op}</span>}
      </div>
    </div>
  );
}

// ============================================================
// TICKET DETAIL
// ============================================================
function BackendTicketDetail({ route }) {
  const BackendShell = window.PROTO_BACKEND_SHELL;
  const id = route.parts[2];
  const [storeState, dispatch] = useStore();
  const toast = useToast();
  const confirm = useConfirm();
  const { open, close } = useModal();
  const ticket = getTicket(id, storeState);
  const [reply, setReply] = useState('');

  if (!ticket) {
    return <BackendShell route={route} active="Ticket" breadcrumb={[{ label: 'Ticket', to: '/backend/ticket' }]}>
      <div style={{ padding: 60, textAlign: 'center' }}>Ticket non trovato. <Link to="/backend/ticket">Torna al kanban</Link></div>
    </BackendShell>;
  }

  const status = ticket.status;
  const statusInfo = TICKET_STATUSES.find(s => s.id === status);

  const setStatus = (newStatus) => {
    dispatch({ type: 'SET_TICKET_STATUS', id, status: newStatus });
    const info = TICKET_STATUSES.find(s => s.id === newStatus);
    toast.success(`Ticket #${id} → ${info.label}`);
  };

  const assignOperator = (op) => {
    dispatch({ type: 'SET_TICKET_OPERATOR', id, operator: op });
    if (status === 'new') dispatch({ type: 'SET_TICKET_STATUS', id, status: 'assigned' });
    toast.success(`Ticket assegnato a ${op}`);
  };

  const sendReply = () => {
    if (!reply.trim()) return;
    dispatch({ type: 'ADD_TICKET_REPLY', id, reply: { from: 'G. Fontana', text: reply, when: 'adesso' } });
    if (status === 'new' || status === 'assigned') dispatch({ type: 'SET_TICKET_STATUS', id, status: 'work' });
    setReply('');
    toast.success('Risposta inviata', `Email recapitata a ${ticket.user}`);
  };

  return (
    <BackendShell route={route} active="Ticket" breadcrumb={[{ label: 'Console', to: '/backend' }, { label: 'Ticket', to: '/backend/ticket' }, { label: '#' + id }]}>
      <div style={{ padding: '24px 28px 32px', display: 'grid', gridTemplateColumns: '1fr 320px', gap: 24 }}>
        <div>
          {/* Header */}
          <div className="ig-card" style={{ padding: 24, marginBottom: 14 }}>
            <div style={{ display: 'flex', gap: 8, marginBottom: 10, alignItems: 'center' }}>
              <span style={{ fontFamily: 'var(--ig-font-mono)', fontSize: 12, color: 'var(--ig-ink-500)', fontWeight: 600 }}>#{ticket.id}</span>
              <span className={`ig-badge ig-badge--${ticket.area}`} style={{ height: 22 }}>{ticket.areaLabel}</span>
              <span style={{ padding: '4px 12px', borderRadius: 999, background: 'color-mix(in srgb,' + statusInfo.color + ' 18%, white)', color: statusInfo.color, fontSize: 12, fontWeight: 700 }}>● {statusInfo.label}</span>
              <span style={{ padding: '4px 12px', borderRadius: 999, background: ticket.priority === 'alta' ? 'var(--ig-red-100)' : ticket.priority === 'media' ? 'var(--ig-amber-100)' : 'var(--ig-ink-100)', color: ticket.priority === 'alta' ? 'var(--ig-red-700)' : ticket.priority === 'media' ? 'var(--ig-amber-800)' : 'var(--ig-ink-700)', fontSize: 12, fontWeight: 700 }}>● Priorità {ticket.priority}</span>
            </div>
            <h1 style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.01em', marginBottom: 14 }}>{ticket.subject}</h1>

            {/* Original message */}
            <div style={{ display: 'flex', gap: 12, padding: 16, background: 'var(--ig-ink-50)', borderRadius: 10 }}>
              <div style={{ width: 38, height: 38, borderRadius: '50%', background: ticket.avatarBg, color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 13, flex: '0 0 auto' }}>{ticket.avatar}</div>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                  <span style={{ fontSize: 13, fontWeight: 700 }}>{ticket.user}</span>
                  <span style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>{ticket.opened}</span>
                </div>
                <p style={{ fontSize: 14, color: 'var(--ig-ink-700)', lineHeight: 1.55 }}>{ticket.message}</p>
              </div>
            </div>

            {/* Replies */}
            {ticket.replies.map((r, i) => (
              <div key={i} style={{ display: 'flex', gap: 12, padding: 16, background: 'var(--ig-blue-50)', borderRadius: 10, marginTop: 10 }}>
                <div style={{ width: 38, height: 38, borderRadius: '50%', background: 'var(--ig-teal-600)', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 13, flex: '0 0 auto' }}>GF</div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                    <span style={{ fontSize: 13, fontWeight: 700 }}>{r.from} <span style={{ fontSize: 11, color: 'var(--ig-blue-700)', fontWeight: 700, marginLeft: 6 }}>OPERATORE</span></span>
                    <span style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>{r.when}</span>
                  </div>
                  <p style={{ fontSize: 14, color: 'var(--ig-ink-700)', lineHeight: 1.55, whiteSpace: 'pre-wrap' }}>{r.text}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Reply form */}
          <div className="ig-card" style={{ padding: 20 }}>
            <h3 style={{ fontSize: 14, fontWeight: 700, marginBottom: 10 }}>Rispondi all'utente</h3>
            <textarea className="ig-textarea" value={reply} onChange={e => setReply(e.target.value)} placeholder="Scrivi qui la tua risposta..." style={{ minHeight: 120 }}/>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 12 }}>
              <button className="ig-btn ig-btn--ghost ig-btn--sm" onClick={() => toast.info('Allegato', 'In una versione reale apre il file picker.')}><I.Plus size={14}/> Allega</button>
              <div style={{ display: 'flex', gap: 6 }}>
                <button className="ig-btn ig-btn--ghost ig-btn--sm" onClick={() => { setReply(''); toast.info('Bozza scartata'); }}>Annulla</button>
                <button className="ig-btn ig-btn--primary ig-btn--sm" disabled={!reply.trim()} onClick={sendReply}><I.Send size={14}/> Invia risposta</button>
              </div>
            </div>
          </div>
        </div>

        {/* Right sidebar */}
        <aside>
          <div className="ig-card" style={{ padding: 20, marginBottom: 14 }}>
            <h3 style={{ fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)', marginBottom: 12 }}>Azioni rapide</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ justifyContent: 'flex-start' }} onClick={() => navigate(`/backend/colloqui/nuovo?from=${id}`)}>
                <I.Chat size={14}/> Trasforma in colloquio
              </button>
              <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ justifyContent: 'flex-start' }} onClick={() => navigate(`/backend/appuntamenti?for=${ticket.userId}`)}>
                <I.Calendar size={14}/> Crea appuntamento
              </button>
              <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ justifyContent: 'flex-start' }} onClick={() => open({
                title: 'Collega scheda informativa', icon: <I.Link size={20}/>, width: 520,
                content: (
                  <div>
                    <p style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginBottom: 12 }}>Seleziona una scheda da inviare all\u2019utente come risposta automatica.</p>
                    <input className="ig-input" placeholder="Cerca scheda…" autoFocus/>
                    <div style={{ marginTop: 14, maxHeight: 300, overflowY: 'auto' }}>
                      {SCHEDE.filter(s => s.area === ticket.area).slice(0, 4).map(s => (
                        <button key={s.id} onClick={() => { close(); toast.success('Scheda collegata', `${s.id} → ticket #${id}`); }} style={{ display: 'block', width: '100%', textAlign: 'left', padding: 12, border: '1px solid var(--ig-border-soft)', borderRadius: 8, marginBottom: 6, background: 'white', cursor: 'pointer', fontFamily: 'inherit' }}>
                          <div style={{ fontSize: 11, fontFamily: 'var(--ig-font-mono)', color: 'var(--ig-ink-500)' }}>{s.id}</div>
                          <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-900)' }}>{s.title}</div>
                        </button>
                      ))}
                    </div>
                  </div>
                ),
                actions: <><button className="ig-btn ig-btn--ghost" onClick={close}>Annulla</button></>,
              })}>
                <I.Link size={14}/> Collega scheda
              </button>
              {status !== 'closed' && (
                <button className="ig-btn ig-btn--danger ig-btn--sm" style={{ justifyContent: 'flex-start' }} onClick={async () => {
                  const ok = await confirm({ title: 'Chiudere questo ticket?', message: 'Il ticket non potrà più essere riaperto. L\u2019utente riceverà un\u2019email di conferma.', confirmLabel: 'Chiudi ticket', danger: true });
                  if (ok) setStatus('closed');
                }}><I.X size={14}/> Chiudi ticket</button>
              )}
            </div>
          </div>

          <div className="ig-card" style={{ padding: 20, marginBottom: 14 }}>
            <h3 style={{ fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)', marginBottom: 12 }}>Stato e assegnazione</h3>
            <label className="ig-label">Stato</label>
            <select className="ig-input" value={status} onChange={e => setStatus(e.target.value)}>
              {TICKET_STATUSES.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
            </select>
            <label className="ig-label" style={{ marginTop: 10 }}>Operatore</label>
            <select className="ig-input" value={ticket.operator || ''} onChange={e => assignOperator(e.target.value || null)}>
              <option value="">Non assegnato</option>
              {OPERATORI.map(op => <option key={op.sigla}>{op.name.split(' ')[0][0]}. {op.name.split(' ')[1]}</option>)}
            </select>
            <label className="ig-label" style={{ marginTop: 10 }}>Priorità</label>
            <select className="ig-input" defaultValue={ticket.priority} onChange={e => toast.info(`Priorità aggiornata: ${e.target.value}`)}>
              <option>alta</option><option>media</option><option>bassa</option>
            </select>
          </div>

          <div className="ig-card" style={{ padding: 20 }}>
            <h3 style={{ fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)', marginBottom: 12 }}>Utente</h3>
            <Link to={`/backend/utenti/${ticket.userId}`} style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none' }}>
              <div style={{ width: 38, height: 38, borderRadius: '50%', background: ticket.avatarBg, color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 13 }}>{ticket.avatar}</div>
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ig-ink-900)' }}>{ticket.user}</div>
                <div style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>{ticket.userId}</div>
              </div>
            </Link>
          </div>
        </aside>
      </div>
    </BackendShell>
  );
}

// ============================================================
// COLLOQUIO FORM (new) — interactive
// ============================================================
function BackendColloquio({ route }) {
  const BackendShell = window.PROTO_BACKEND_SHELL;
  const toast = useToast();
  const { open, close } = useModal();
  const fromTicket = route.query.from;
  const fromTicketObj = fromTicket ? TICKET.find(t => t.id === fromTicket) : null;
  const [user, setUser] = useState(fromTicketObj?.user || 'Salvatore Catanzaro');
  const [bisogno, setBisogno] = useState(fromTicketObj?.message || '');
  const [sintesi, setSintesi] = useState('');
  const [categoria, setCategoria] = useState(fromTicketObj?.area || 'impresa');
  const [schedeSelected, setSchedeSelected] = useState(new Set());
  const [actions, setActions] = useState(new Set(['Avvio percorso impresa', 'Caricamento documenti']));
  const [esito, setEsito] = useState('in_carico');

  const suggested = SCHEDE.filter(s => s.area === categoria).slice(0, 5);
  const toggle = (set, setter, v) => { const n = new Set(set); n.has(v) ? n.delete(v) : n.add(v); setter(n); };

  const save = () => {
    toast.success('Colloquio salvato', `Riepilogo inviato a ${user} · ${schedeSelected.size} schede consegnate`);
    setTimeout(() => navigate('/backend/colloqui'), 800);
  };

  return (
    <BackendShell route={route} active="Colloqui" breadcrumb={[{ label: 'Console', to: '/backend' }, { label: 'Colloqui', to: '/backend/colloqui' }, { label: 'Nuovo colloquio' }]}>
      <div style={{ padding: '24px 28px 0', background: 'white', borderBottom: '1px solid var(--ig-border-soft)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 18 }}>
          <div>
            <h1 style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.01em' }}>Nuovo colloquio · {user}</h1>
            {fromTicketObj && <div style={{ fontSize: 13, color: 'var(--ig-blue-700)', fontWeight: 600, marginTop: 4 }}>📌 Da ticket #{fromTicket} · {fromTicketObj.subject}</div>}
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="ig-btn ig-btn--ghost ig-btn--sm" onClick={() => toast.success('Bozza salvata')}>Salva bozza</button>
            <button className="ig-btn ig-btn--secondary ig-btn--sm" onClick={() => open({ title: 'Anteprima report colloquio', icon: <I.Doc size={20}/>, width: 540, content: <div style={{ padding: 20, background: 'var(--ig-ink-50)', borderRadius: 8, fontSize: 13, lineHeight: 1.6 }}><strong>{user}</strong><br/>Bisogno: {bisogno || '—'}<br/>Sintesi: {sintesi || '—'}<br/>Schede consegnate: {schedeSelected.size}<br/>Esito: {esito}</div>, actions: <><button className="ig-btn ig-btn--ghost" onClick={close}>Chiudi</button><button className="ig-btn ig-btn--primary" onClick={() => { toast.success('PDF generato'); close(); }}><I.Download size={14}/> Scarica</button></> })}><I.Doc size={14}/> Anteprima report</button>
            <button className="ig-btn ig-btn--primary ig-btn--sm" onClick={save}><I.Check size={14}/> Chiudi colloquio</button>
          </div>
        </div>
      </div>

      <div style={{ padding: '24px 28px 32px' }}>
        <ColloquioSection num="01" title="Dati colloquio">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
            <div>
              <label className="ig-label">Utente</label>
              <select className="ig-input" value={user} onChange={e => setUser(e.target.value)}>
                {UTENTI.map(u => <option key={u.id}>{u.name}</option>)}
              </select>
            </div>
            <div>
              <label className="ig-label">Operatore</label>
              <select className="ig-input" defaultValue="G. Fontana">
                {OPERATORI.map(op => <option key={op.sigla}>{op.name.split(' ')[0][0]}. {op.name.split(' ')[1]}</option>)}
              </select>
            </div>
            <div>
              <label className="ig-label">Argomento prevalente</label>
              <select className="ig-input" value={categoria} onChange={e => setCategoria(e.target.value)}>
                {window.IG_DATA.AREAS.map(a => <option key={a.id} value={a.id}>{a.label}</option>)}
              </select>
            </div>
          </div>
        </ColloquioSection>

        <ColloquioSection num="02" title="Bisogno espresso · in parole dell'utente">
          <textarea className="ig-textarea" value={bisogno} onChange={e => setBisogno(e.target.value)} placeholder="Cosa ha chiesto l'utente…" style={{ minHeight: 100 }}/>
        </ColloquioSection>

        <ColloquioSection num="03" title="Sintesi colloquio · note interne">
          <textarea className="ig-textarea" value={sintesi} onChange={e => setSintesi(e.target.value)} placeholder="Sintesi strutturata dell'operatore, problemi emersi, obiettivi…" style={{ minHeight: 120 }}/>
        </ColloquioSection>

        <ColloquioSection num="04" title="Schede consigliate" subtitle="Suggerimenti basati su argomento e profilo">
          <div style={{ background: 'var(--ig-amber-50)', border: '1px solid var(--ig-amber-100)', borderRadius: 8, padding: 10, marginBottom: 12, display: 'flex', alignItems: 'center', gap: 8 }}>
            <I.Sparkle size={14} color="var(--ig-amber-700)"/>
            <span style={{ fontSize: 12, color: 'var(--ig-amber-800)' }}>{schedeSelected.size} schede selezionate · verranno inviate via email al termine</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {suggested.map(s => {
              const sel = schedeSelected.has(s.id);
              return (
                <button key={s.id} onClick={() => toggle(schedeSelected, setSchedeSelected, s.id)} style={{
                  display: 'flex', alignItems: 'center', gap: 12, padding: 12,
                  border: `1px solid ${sel ? 'var(--ig-blue-300)' : 'var(--ig-border-soft)'}`,
                  background: sel ? 'var(--ig-blue-50)' : 'white', borderRadius: 8,
                  cursor: 'pointer', fontFamily: 'inherit', textAlign: 'left',
                }}>
                  <span style={{ width: 18, height: 18, borderRadius: 4, border: sel ? 'none' : '1.5px solid var(--ig-ink-300)', background: sel ? 'var(--ig-blue-700)' : 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', flex: '0 0 auto' }}>
                    {sel && <I.Check size={12} color="white" strokeWidth={3}/>}
                  </span>
                  <span style={{ fontFamily: 'var(--ig-font-mono)', fontSize: 10, color: 'var(--ig-ink-500)' }}>{s.id}</span>
                  <span style={{ flex: 1, fontSize: 13, fontWeight: 600 }}>{s.title}</span>
                  <span className={`ig-badge ig-badge--${s.area}`} style={{ height: 20, fontSize: 10 }}>{s.areaLabel}</span>
                </button>
              );
            })}
          </div>
        </ColloquioSection>

        <ColloquioSection num="05" title="Azioni suggerite all'utente">
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            {['Iscrizione CPI', 'Candidatura offerta', 'Iscrizione corso', 'Prenotazione evento', 'Avvio percorso impresa', 'Invio a partner', 'Caricamento documenti', 'Altro'].map(a => {
              const sel = actions.has(a);
              return (
                <button key={a} onClick={() => toggle(actions, setActions, a)} style={{
                  height: 34, padding: '0 12px', borderRadius: 6,
                  background: sel ? 'var(--ig-blue-50)' : 'white',
                  border: `1px solid ${sel ? 'var(--ig-blue-700)' : 'var(--ig-border)'}`,
                  color: sel ? 'var(--ig-blue-700)' : 'var(--ig-ink-700)',
                  fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit',
                  display: 'inline-flex', alignItems: 'center', gap: 6,
                }}>{sel && <I.Check size={12}/>}{a}</button>
              );
            })}
          </div>
        </ColloquioSection>

        <ColloquioSection num="06" title="Esito del colloquio">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
            {[['risolto','Risolto','var(--ig-green-700)'],['in_carico','In carico','var(--ig-blue-700)'],['rinviato','Rinviato','var(--ig-amber-700)'],['percorso','Percorso avviato','var(--ig-teal-700)']].map(([k, l, c]) => {
              const sel = esito === k;
              return (
                <button key={k} onClick={() => setEsito(k)} style={{
                  padding: '12px 16px', border: `1px solid ${sel ? c : 'var(--ig-border-soft)'}`,
                  background: sel ? `color-mix(in srgb, ${c} 6%, white)` : 'white',
                  borderRadius: 8, cursor: 'pointer', fontFamily: 'inherit',
                  display: 'flex', alignItems: 'center', gap: 10,
                }}>
                  <span style={{ width: 18, height: 18, borderRadius: '50%', border: `1.5px solid ${sel ? c : 'var(--ig-ink-300)'}`, background: sel ? c : 'white', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flex: '0 0 auto' }}>
                    {sel && <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'white' }}/>}
                  </span>
                  <span style={{ fontSize: 13, fontWeight: 600, color: sel ? c : 'var(--ig-ink-700)' }}>{l}</span>
                </button>
              );
            })}
          </div>
        </ColloquioSection>

        <div style={{ background: 'var(--ig-ink-50)', border: '1px solid var(--ig-border-soft)', borderRadius: 12, padding: 18, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 18 }}>
          <div style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>
            <I.Info size={14} style={{ display: 'inline', verticalAlign: '-2px', marginRight: 4 }}/>
            Alla chiusura verrà inviato il riepilogo all'utente, creato l'appuntamento di follow-up e notificato il partner.
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <Link to="/backend/colloqui"><button className="ig-btn ig-btn--ghost">Annulla</button></Link>
            <button className="ig-btn ig-btn--primary" onClick={save}><I.Check size={14}/> Chiudi colloquio</button>
          </div>
        </div>
      </div>
    </BackendShell>
  );
}

function ColloquioSection({ num, title, subtitle, children }) {
  return (
    <div className="ig-card" style={{ padding: 22, marginBottom: 14 }}>
      <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start', marginBottom: 14 }}>
        <span style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--ig-blue-700)', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 800, fontFamily: 'var(--ig-font-mono)', flex: '0 0 auto' }}>{num}</span>
        <div>
          <h3 style={{ fontSize: 15, fontWeight: 700 }}>{title}</h3>
          {subtitle && <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginTop: 2 }}>{subtitle}</div>}
        </div>
      </div>
      {children}
    </div>
  );
}

// ============================================================
// COLLOQUI LIST (simple)
// ============================================================
function BackendColloquiList({ route }) {
  const BackendShell = window.PROTO_BACKEND_SHELL;
  return (
    <BackendShell route={route} active="Colloqui" breadcrumb={[{ label: 'Console', to: '/backend' }, { label: 'Colloqui' }]}>
      <div style={{ padding: '24px 28px 0', background: 'white', borderBottom: '1px solid var(--ig-border-soft)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <h1 style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.01em' }}>Colloqui</h1>
            <p style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginTop: 4 }}>142 colloqui questo mese · 12 operatori attivi</p>
          </div>
          <Link to="/backend/colloqui/nuovo"><button className="ig-btn ig-btn--primary ig-btn--sm"><I.Plus size={14}/> Nuovo colloquio</button></Link>
        </div>
      </div>
      <div style={{ padding: '20px 28px 32px' }}>
        <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
          {[
            ['COL-1209', '14 mar 09:30', 'S. Catanzaro', 'M. Greco', 'In presenza', 'impresa', 'Impresa', 'Resto al Sud · documentazione', 'In carico'],
            ['COL-1208', '14 mar 10:30', 'L. Bonfiglio', 'L. Marino', 'Video', 'concorso', 'Concorsi', 'Orientamento concorsi pubblici', 'Risolto'],
            ['COL-1207', '13 mar 15:00', 'M. Lo Curto', 'M. Greco', 'In presenza', 'estero', 'Estero', 'Erasmus+ Olanda', 'Risolto'],
            ['COL-1206', '13 mar 11:30', 'A. Mineo', 'P. Rizzo', 'In presenza', 'lavoro', 'Lavoro', 'Revisione CV', 'Risolto'],
            ['COL-1205', '12 mar 16:00', 'C. La Rosa', 'F. Bellomo', 'In presenza', 'impresa', 'Impresa', 'Microcredito · primo colloquio', 'In carico'],
          ].map((r, i, arr) => (
            <div key={r[0]} style={{ display: 'grid', gridTemplateColumns: '90px 110px 1fr 100px 100px 110px 110px', gap: 12, padding: '14px 22px', borderBottom: i < arr.length - 1 ? '1px solid var(--ig-border-soft)' : 'none', alignItems: 'center' }}>
              <span style={{ fontFamily: 'var(--ig-font-mono)', fontSize: 11, color: 'var(--ig-ink-500)' }}>{r[0]}</span>
              <span style={{ fontSize: 12, color: 'var(--ig-ink-700)' }}>{r[1]}</span>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{r[7]}</div>
                <div style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>{r[2]} · {r[3]}</div>
              </div>
              <span style={{ fontSize: 12, color: 'var(--ig-ink-700)' }}>{r[4]}</span>
              <span className={`ig-badge ig-badge--${r[5]}`} style={{ height: 20, fontSize: 10 }}>{r[6]}</span>
              <span className={`ig-badge ${r[8] === 'Risolto' ? 'ig-badge--state-pub' : 'ig-badge--state-valid'}`} style={{ height: 20, fontSize: 10 }}>{r[8]}</span>
              <button className="ig-btn ig-btn--ghost ig-btn--icon" style={{ width: 28, height: 28 }}><I.ChevR size={14}/></button>
            </div>
          ))}
        </div>
      </div>
    </BackendShell>
  );
}

// ============================================================
// UTENTI LIST
// ============================================================
function BackendUtenti({ route }) {
  const BackendShell = window.PROTO_BACKEND_SHELL;
  const userId = route.parts[2];
  if (userId) return <BackendUtenteDetail route={route} userId={userId}/>;
  const [q, setQ] = useState('');
  const filtered = UTENTI.filter(u => !q.trim() || (u.name + u.email + u.city).toLowerCase().includes(q.toLowerCase()));
  return (
    <BackendShell route={route} active="Utenti" breadcrumb={[{ label: 'Console', to: '/backend' }, { label: 'Utenti giovani' }]}>
      <div style={{ padding: '24px 28px 0', background: 'white', borderBottom: '1px solid var(--ig-border-soft)' }}>
        <h1 style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.01em' }}>Utenti giovani</h1>
        <p style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginTop: 4, marginBottom: 14 }}>{UTENTI.length} utenti iscritti</p>
        <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
          <div style={{ flex: 1, maxWidth: 360, position: 'relative' }}>
            <input className="ig-input" placeholder="Cerca per nome, email, comune…" value={q} onChange={e => setQ(e.target.value)} style={{ paddingLeft: 36, height: 38, fontSize: 14 }}/>
            <div style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)' }}><I.Search size={15} color="var(--ig-ink-400)"/></div>
          </div>
        </div>
      </div>
      <div style={{ padding: '20px 28px 32px' }}>
        <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
          {filtered.map((u, i) => (
            <Link key={u.id} to={`/backend/utenti/${u.id}`} style={{ display: 'grid', gridTemplateColumns: '46px 1fr 140px 110px 80px 80px 30px', gap: 12, padding: '14px 22px', borderBottom: i < filtered.length - 1 ? '1px solid var(--ig-border-soft)' : 'none', alignItems: 'center', textDecoration: 'none' }}>
              <div style={{ width: 38, height: 38, borderRadius: '50%', background: u.avatarBg, color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 13 }}>{u.avatar}</div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ig-ink-900)' }}>{u.name}</div>
                <div style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>{u.email} · {u.phone}</div>
              </div>
              <span style={{ fontSize: 12, color: 'var(--ig-ink-700)' }}>{u.age} anni · {u.city}</span>
              <span className="ig-badge" style={{ background: u.status === 'NEET' ? 'var(--ig-amber-100)' : 'var(--ig-ink-100)', color: u.status === 'NEET' ? 'var(--ig-amber-800)' : 'var(--ig-ink-700)', height: 20, fontSize: 11 }}>{u.status}</span>
              <span style={{ fontSize: 11, color: 'var(--ig-ink-500)', textAlign: 'center' }}><strong style={{ color: 'var(--ig-ink-900)' }}>{u.colloqui}</strong> coll.</span>
              <span style={{ fontSize: 11, color: 'var(--ig-ink-500)', textAlign: 'center' }}><strong style={{ color: 'var(--ig-ink-900)' }}>{u.ticket}</strong> ticket</span>
              <I.ChevR size={14} color="var(--ig-ink-400)"/>
            </Link>
          ))}
        </div>
      </div>
    </BackendShell>
  );
}

function BackendUtenteDetail({ route, userId }) {
  const BackendShell = window.PROTO_BACKEND_SHELL;
  const u = UTENTI.find(x => x.id === userId);
  const toast = useToast();
  const confirm = useConfirm();
  const [tab, setTab] = useState('profilo');
  if (!u) return <div>Non trovato</div>;
  return (
    <BackendShell route={route} active="Utenti" breadcrumb={[{ label: 'Console', to: '/backend' }, { label: 'Utenti', to: '/backend/utenti' }, { label: u.name }]}>
      <div style={{ padding: '24px 28px 0', background: 'white', borderBottom: '1px solid var(--ig-border-soft)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 14 }}>
          <div style={{ width: 56, height: 56, borderRadius: '50%', background: u.avatarBg, color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 18 }}>{u.avatar}</div>
          <div style={{ flex: 1 }}>
            <h1 style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.01em' }}>{u.name}</h1>
            <div style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginTop: 2 }}>{u.id} · {u.age} anni · {u.city} · iscritto da 14 mesi</div>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            <button className="ig-btn ig-btn--secondary ig-btn--sm" onClick={() => toast.info('Apertura email…', `Destinatario: ${u.email}`)}><I.Mail size={14}/> Email</button>
            <Link to="/backend/colloqui/nuovo"><button className="ig-btn ig-btn--primary ig-btn--sm"><I.Chat size={14}/> Nuovo colloquio</button></Link>
            <Link to="/prenota"><button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Calendar size={14}/> Appuntamento</button></Link>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 4 }}>
          {[['profilo', 'Profilo'], ['colloqui', `Colloqui · ${u.colloqui}`], ['ticket', `Ticket · ${u.ticket}`], ['salvate', `Salvate · ${u.saved}`], ['privacy', 'Privacy']].map(([k, l]) => (
            <button key={k} onClick={() => setTab(k)} style={{ padding: '10px 14px', fontSize: 13, fontWeight: 600, color: tab === k ? 'var(--ig-blue-700)' : 'var(--ig-ink-700)', borderBottom: tab === k ? '2px solid var(--ig-blue-700)' : '2px solid transparent', marginBottom: -1, background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'inherit' }}>{l}</button>
          ))}
        </div>
      </div>
      <div style={{ padding: '24px 28px 32px' }}>
        {tab === 'profilo' && (
          <div className="ig-card" style={{ padding: 24 }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 18 }}>
              <UDet label="Email" value={u.email}/>
              <UDet label="Telefono" value={u.phone}/>
              <UDet label="Comune" value={u.city}/>
              <UDet label="Età" value={`${u.age} anni`}/>
              <UDet label="Stato occupazionale" value={u.status}/>
              <UDet label="Interessi" value={u.interests.join(', ')}/>
            </div>
            <div style={{ marginTop: 20, paddingTop: 18, borderTop: '1px solid var(--ig-border-soft)' }}>
              <button className="ig-btn ig-btn--danger ig-btn--sm" onClick={async () => {
                const ok = await confirm({ title: 'Anonimizzare questo utente?', message: 'Tutti i dati identificativi saranno rimossi mantenendo le statistiche aggregate. Operazione irreversibile.', danger: true });
                if (ok) toast.warning('Utente anonimizzato', `${u.id} → USR-ANON-${Math.floor(Math.random()*9999)}`);
              }}><I.Alert size={14}/> Anonimizza utente</button>
            </div>
          </div>
        )}
        {tab !== 'profilo' && (
          <div className="ig-card" style={{ padding: 40, textAlign: 'center', color: 'var(--ig-ink-500)' }}>
            <I.Folder size={32} color="var(--ig-ink-300)" style={{ margin: '0 auto 10px' }}/>
            Sezione "{tab}" · vista mock · dati realistici in altre schermate.
          </div>
        )}
      </div>
    </BackendShell>
  );
}

function UDet({ label, value }) {
  return (
    <div>
      <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ig-ink-900)' }}>{value}</div>
    </div>
  );
}

window.PROTO_BACKEND_TICKETS = BackendTickets;
window.PROTO_BACKEND_TICKET_DETAIL = BackendTicketDetail;
window.PROTO_BACKEND_COLLOQUIO = BackendColloquio;
window.PROTO_BACKEND_COLLOQUI_LIST = BackendColloquiList;
window.PROTO_BACKEND_UTENTI = BackendUtenti;

})();
