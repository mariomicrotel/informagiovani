/* global React, IGIcons, IG_UI, IG_DATA */
(function(){
var { useState, useEffect, useMemo } = React;
var I = IGIcons;
var { Link, navigate, useToast, useModal, useConfirm, useStore, getScheda } = IG_UI;
var { SCHEDE, EVENTI, AREAS } = IG_DATA;

// ============================================================
// PUBLIC HEADER
// ============================================================
function PublicHeader({ route }) {
  const [, dispatch] = useStore();
  const items = [
    ['Opportunità', '/opportunita'],
    ['Lavoro', '/opportunita?area=lavoro'],
    ['Formazione', '/opportunita?area=formazione'],
    ['Fare Impresa', '/opportunita?area=impresa'],
    ['Estero', '/opportunita?area=estero'],
    ['Eventi', '/eventi'],
    ['Prenota colloquio', '/prenota'],
  ];
  const currentArea = route.query.area;
  const matchActive = (path) => {
    if (path === '/opportunita' && route.parts[0] === 'opportunita' && !currentArea) return true;
    if (path.includes('?area=') && path.includes(currentArea)) return true;
    if (path === '/prenota' && route.parts[0] === 'prenota') return true;
    if (path === '/eventi' && route.parts[0] === 'eventi') return true;
    return false;
  };
  return (
    <header style={{ background: 'white', borderBottom: '1px solid var(--ig-border-soft)', position: 'sticky', top: 0, zIndex: 50 }}>
      <div style={{ background: 'var(--ig-blue-800)', color: 'rgba(255,255,255,0.78)', fontSize: 12 }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '8px 32px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', gap: 18, alignItems: 'center' }}>
            <span style={{ fontWeight: 600, color: 'white' }}>Comune di Enna</span>
            <span style={{ opacity: 0.5 }}>·</span>
            <span>Servizio per i giovani</span>
          </div>
          <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><I.Phone size={12}/> 0935 40 04 00</span>
            <span style={{ opacity: 0.5 }}>·</span>
            <span style={{ color: 'rgba(255,255,255,0.85)' }}>IT</span>
            <span style={{ opacity: 0.4 }}>EN</span>
            <span style={{ opacity: 0.5 }}>·</span>
            <Link to="/" style={{ color: 'rgba(255,255,255,0.85)' }}>Accessibilità</Link>
          </div>
        </div>
      </div>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '18px 32px', display: 'flex', alignItems: 'center', gap: 32 }}>
        <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: 12, textDecoration: 'none' }}>
          <div style={{ width: 42, height: 42, borderRadius: 10, background: 'var(--ig-blue-700)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="24" height="24" viewBox="0 0 28 28" fill="none">
              <path d="M4 22 L14 4 L24 22 Z" stroke="white" strokeWidth="2.4" strokeLinejoin="round"/>
              <circle cx="14" cy="15" r="2.4" fill="var(--ig-amber-500)"/>
            </svg>
          </div>
          <div style={{ lineHeight: 1.1 }}>
            <div style={{ fontSize: 16, fontWeight: 800, color: 'var(--ig-ink-900)', letterSpacing: '-0.01em' }}>Informagiovani</div>
            <div style={{ fontSize: 11, color: 'var(--ig-amber-700)', fontWeight: 700, letterSpacing: '0.06em', marginTop: 2 }}>ENNA</div>
          </div>
        </Link>
        <nav style={{ display: 'flex', gap: 2, flex: 1, justifyContent: 'center' }}>
          {items.map(([label, to]) => {
            const active = matchActive(to);
            return (
              <Link key={label} to={to} style={{
                padding: '9px 13px', fontSize: 14, fontWeight: 600,
                color: active ? 'var(--ig-blue-700)' : 'var(--ig-ink-700)',
                borderRadius: 6,
                background: active ? 'var(--ig-blue-50)' : 'transparent',
                textDecoration: 'none',
              }}>{label}</Link>
            );
          })}
        </nav>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <Link to="/area" style={{ fontSize: 14, fontWeight: 600, color: 'var(--ig-ink-700)' }}>Area personale</Link>
          <Link to="/area">
            <button className="ig-btn ig-btn--primary ig-btn--sm" style={{ height: 36 }}>
              <I.User size={15}/> Accedi
            </button>
          </Link>
        </div>
      </div>
    </header>
  );
}

function PublicFooter() {
  return (
    <footer style={{ background: 'var(--ig-blue-900)', color: 'rgba(255,255,255,0.7)', padding: '48px 0 28px' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 32px', display: 'grid', gridTemplateColumns: '1.5fr 1fr 1fr 1fr', gap: 48 }}>
        <div>
          <div style={{ color: 'white', fontWeight: 800, fontSize: 16, marginBottom: 10 }}>Informagiovani Enna</div>
          <p style={{ fontSize: 13, lineHeight: 1.6, color: 'rgba(255,255,255,0.65)' }}>
            Piazza Garibaldi, 1 · 94100 Enna<br/>
            0935 40 04 00 · informagiovani@comune.enna.it<br/>
            Lun – Ven, 9:00 – 13:00 / 15:00 – 17:30
          </p>
        </div>
        {[
          ['Servizi', [['Opportunità','/opportunita'],['Eventi','/eventi'],['Prenota colloquio','/prenota']]],
          ['Per te', [['Area personale','/area'],['Le mie salvate','/area/salvate'],['Richieste','/area/richieste']]],
          ['Comune', [['Comune di Enna','/'],['Privacy','/'],['Accessibilità','/']]],
        ].map(([title, links]) => (
          <div key={title}>
            <div style={{ color: 'white', fontWeight: 700, fontSize: 13, marginBottom: 12, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{title}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {links.map(([l, to]) => <Link key={l} to={to} style={{ fontSize: 13, color: 'rgba(255,255,255,0.7)' }}>{l}</Link>)}
            </div>
          </div>
        ))}
      </div>
    </footer>
  );
}

// ============================================================
// SCHEDA CARD (interactive)
// ============================================================
function SchedaCard({ scheda, layout = 'grid' }) {
  const [state, dispatch] = useStore();
  const toast = useToast();
  const saved = state.saved.has(scheda.id);

  const handleSave = (e) => {
    e.stopPropagation();
    e.preventDefault();
    dispatch({ type: 'TOGGLE_SAVED', id: scheda.id });
    toast.success(saved ? 'Rimossa dai preferiti' : 'Opportunità salvata', saved ? `${scheda.title}` : 'L\u2019abbiamo aggiunta alla tua area personale.');
  };

  if (layout === 'list') {
    return (
      <article className="ig-card" style={{ padding: 22, display: 'grid', gridTemplateColumns: '1fr 200px', gap: 24, cursor: 'pointer' }} onClick={() => navigate(`/scheda/${scheda.id}`)}>
        <div style={{ minWidth: 0 }}>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 12 }}>
            <span className={`ig-badge ig-badge--${scheda.area}`}>{scheda.areaLabel}</span>
            <span className="ig-badge" style={{ background: 'var(--ig-ink-75)', color: 'var(--ig-ink-700)' }}>{scheda.type}</span>
            <span className={`ig-badge ig-badge--src-${scheda.sourceClass}`}><I.ShieldChk size={12}/>{scheda.sourceClass === 'ufficiale' ? 'Ufficiale' : scheda.sourceClass === 'partner' ? 'Partner' : 'Verificata'}</span>
          </div>
          <h3 style={{ fontSize: 19, fontWeight: 700, lineHeight: 1.25, color: 'var(--ig-ink-900)', marginBottom: 8 }}>{scheda.title}</h3>
          <p style={{ fontSize: 14, color: 'var(--ig-ink-500)', lineHeight: 1.5, marginBottom: 12 }}>{scheda.short}</p>
          <div style={{ display: 'flex', gap: 18, fontSize: 12, color: 'var(--ig-ink-500)', flexWrap: 'wrap' }}>
            <span><I.Users size={12} style={{ display: 'inline', verticalAlign: '-2px', marginRight: 4 }}/>{scheda.target.join(', ')}</span>
            <span><I.MapPin size={12} style={{ display: 'inline', verticalAlign: '-2px', marginRight: 4 }}/>{scheda.territory}</span>
            <span><I.Building size={12} style={{ display: 'inline', verticalAlign: '-2px', marginRight: 4 }}/>{scheda.source}</span>
          </div>
        </div>
        <div style={{ paddingLeft: 22, borderLeft: '1px solid var(--ig-border-soft)', display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>Scadenza</div>
            {scheda.urg === 'ok' ? (
              <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--ig-green-700)' }}>Sempre aperta</div>
            ) : (
              <div className="ig-num" style={{ fontSize: 22, fontWeight: 800, color: scheda.urg === 'urgent' ? 'var(--ig-red-700)' : 'var(--ig-amber-800)' }}>
                {scheda.daysLeft} giorni
              </div>
            )}
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 'auto' }}>
            <button className="ig-btn ig-btn--primary ig-btn--sm" style={{ width: '100%', justifyContent: 'center' }} onClick={(e) => { e.stopPropagation(); navigate(`/scheda/${scheda.id}`); }}>Dettagli <I.ArrowR size={14}/></button>
            <div style={{ display: 'flex', gap: 6 }}>
              <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ flex: 1, justifyContent: 'center', background: saved ? 'var(--ig-amber-50)' : 'white', borderColor: saved ? 'var(--ig-amber-500)' : 'var(--ig-border)' }} onClick={handleSave}>
                {saved ? <I.BookmarkF size={14} color="var(--ig-amber-700)"/> : <I.Bookmark size={14}/>}
                {saved ? 'Salvata' : 'Salva'}
              </button>
              <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ flex: 1, justifyContent: 'center' }} onClick={(e) => { e.stopPropagation(); navigate(`/ticket?ref=${scheda.id}`); }}><I.Chat size={14}/> Info</button>
            </div>
          </div>
        </div>
      </article>
    );
  }

  // Grid card (compact)
  return (
    <article className="ig-card" style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 12, cursor: 'pointer', height: '100%' }} onClick={() => navigate(`/scheda/${scheda.id}`)}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          <span className={`ig-badge ig-badge--${scheda.area}`}>{scheda.areaLabel}</span>
          {scheda.daysLeft !== null && scheda.daysLeft !== undefined && (
            <span className={`ig-badge ig-badge--scad-${scheda.urg}`}><I.Clock size={12}/>{scheda.daysLeft}g</span>
          )}
        </div>
        <button onClick={handleSave} style={{ background: 'transparent', border: 'none', cursor: 'pointer', padding: 4, color: saved ? 'var(--ig-amber-700)' : 'var(--ig-ink-400)' }}>
          {saved ? <I.BookmarkF size={20}/> : <I.Bookmark size={20}/>}
        </button>
      </div>
      <h3 style={{ fontSize: 16, fontWeight: 700, lineHeight: 1.3, color: 'var(--ig-ink-900)', flex: 1 }}>{scheda.title}</h3>
      <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', display: 'flex', alignItems: 'center', gap: 6 }}>
        <I.ShieldChk size={12} color="var(--ig-green-700)"/>{scheda.source}
      </div>
      <button className="ig-btn ig-btn--primary ig-btn--sm" style={{ width: '100%', justifyContent: 'center' }}>Dettagli <I.ArrowR size={14}/></button>
    </article>
  );
}

// ============================================================
// HOMEPAGE
// ============================================================
function PublicHome() {
  const [query, setQuery] = useState('');
  const onSearch = (e) => {
    e.preventDefault();
    navigate(`/opportunita${query ? `?q=${encodeURIComponent(query)}` : ''}`);
  };
  const featured = SCHEDE.slice(0, 4);
  const deadlines = SCHEDE.filter(s => s.daysLeft && s.daysLeft <= 21).sort((a, b) => a.daysLeft - b.daysLeft).slice(0, 5);
  const upcoming = EVENTI.slice(0, 4);
  return (
    <div className="ig" style={{ background: 'var(--ig-bg)' }}>
      <section style={{ background: 'linear-gradient(135deg, var(--ig-blue-700) 0%, var(--ig-blue-800) 70%, #08213f 100%)', color: 'white', overflow: 'hidden', position: 'relative' }}>
        <svg width="600" height="600" viewBox="0 0 600 600" style={{ position: 'absolute', top: -160, right: -120, opacity: 0.08 }}>
          <circle cx="300" cy="300" r="280" stroke="white" strokeWidth="1.2" fill="none"/>
          <circle cx="300" cy="300" r="200" stroke="white" strokeWidth="1.2" fill="none"/>
          <circle cx="300" cy="300" r="120" stroke="white" strokeWidth="1.2" fill="none"/>
        </svg>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '72px 32px 80px', position: 'relative' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 80, alignItems: 'center' }}>
            <div>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: 'rgba(232,169,58,0.18)', color: 'var(--ig-amber-500)', padding: '6px 12px', borderRadius: 999, fontSize: 12, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 22 }}>
                <I.Sparkle size={12}/> Servizio del Comune di Enna
              </div>
              <h1 style={{ fontSize: 48, fontWeight: 800, color: 'white', letterSpacing: '-0.025em', lineHeight: 1.08, marginBottom: 18 }}>
                Il punto di accesso alle <span className="ig-serif" style={{ color: 'var(--ig-amber-500)', fontWeight: 500, fontStyle: 'italic' }}>opportunità</span> per i giovani di Enna
              </h1>
              <p style={{ fontSize: 17, color: 'rgba(255,255,255,0.78)', lineHeight: 1.5, maxWidth: 580, marginBottom: 30 }}>
                Lavoro, formazione, impresa, estero, concorsi, eventi e servizi utili — verificati dagli operatori, in un&apos;unica piattaforma.
              </p>
              <form onSubmit={onSearch} style={{ background: 'white', borderRadius: 14, padding: 6, display: 'flex', gap: 6, alignItems: 'center', boxShadow: '0 24px 64px rgba(6,26,50,0.35)', maxWidth: 600 }}>
                <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 10, padding: '0 16px' }}>
                  <I.Search size={18} color="var(--ig-ink-400)"/>
                  <input
                    value={query} onChange={e => setQuery(e.target.value)}
                    style={{ flex: 1, border: 'none', outline: 'none', fontSize: 15, padding: '12px 0', color: 'var(--ig-ink-900)', background: 'transparent', fontFamily: 'inherit' }}
                    placeholder="Cerca lavoro, corsi, concorsi, bonus, eventi..."
                  />
                </div>
                <button type="submit" className="ig-btn ig-btn--primary">Cerca <I.ArrowR size={16}/></button>
              </form>
              <div style={{ display: 'flex', gap: 10, marginTop: 16, alignItems: 'center', fontSize: 13, color: 'rgba(255,255,255,0.65)' }}>
                <span>Popolari:</span>
                {['Servizio civile', 'Erasmus+', 'Resto al Sud', 'Concorsi Enna'].map(s => (
                  <Link key={s} to={`/opportunita?q=${encodeURIComponent(s)}`} style={{ color: 'rgba(255,255,255,0.85)', padding: '4px 10px', border: '1px solid rgba(255,255,255,0.2)', borderRadius: 999, fontSize: 12 }}>{s}</Link>
                ))}
              </div>
              <div style={{ marginTop: 24 }}>
                <Link to="/prenota">
                  <button className="ig-btn ig-btn--lg" style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.25)', color: 'white' }}>
                    <I.Calendar size={18}/> Prenota un colloquio
                  </button>
                </Link>
              </div>
            </div>
            <div style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 20, padding: 28 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-amber-500)', textTransform: 'uppercase', letterSpacing: '0.14em', marginBottom: 20 }}>Lo sportello in numeri</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 22 }}>
                {[['487','Opportunità'],['2.140','Iscritti'],['12','Operatori'],['98%','Risposta &lt;48h']].map(([n, l]) => (
                  <div key={l}>
                    <div className="ig-num" style={{ fontSize: 32, fontWeight: 800, color: 'white', letterSpacing: '-0.02em', lineHeight: 1 }}>{n}</div>
                    <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.65)', marginTop: 4 }} dangerouslySetInnerHTML={{ __html: l }}/>
                  </div>
                ))}
              </div>
              <div style={{ marginTop: 22, paddingTop: 18, borderTop: '1px solid rgba(255,255,255,0.12)', fontSize: 12, color: 'rgba(255,255,255,0.55)', display: 'flex', alignItems: 'center', gap: 6 }}>
                <I.Dot size={8} color="var(--ig-green-600)"/> Sportello aperto · prossimo slot 11:30
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Percorsi rapidi */}
      <section style={{ maxWidth: 1280, margin: '0 auto', padding: '72px 32px 0' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 24 }}>
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.14em', color: 'var(--ig-teal-700)', textTransform: 'uppercase', marginBottom: 8 }}>Da dove vuoi partire?</div>
            <h2 style={{ fontSize: 32, fontWeight: 700, letterSpacing: '-0.02em' }}>Percorsi rapidi</h2>
          </div>
          <Link to="/opportunita" style={{ fontSize: 14, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 6 }}>Esplora tutto <I.ArrowR size={14}/></Link>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
          {[
            { ico: <I.Briefcase size={24}/>, t: 'Cerco lavoro', d: 'Offerte, tirocini retribuiti, accompagnamento candidatura.', c: 'var(--ig-blue-700)', bg: 'var(--ig-blue-50)', to: '/opportunita?area=lavoro' },
            { ico: <I.GradCap size={24}/>, t: 'Voglio formarmi', d: 'Corsi, borse di studio, ITS Academy, dottorati.', c: 'var(--ig-violet-700)', bg: '#f3eefc', to: '/opportunita?area=formazione' },
            { ico: <I.Bulb size={24}/>, t: 'Voglio aprire un\u2019impresa', d: 'Business plan, microcredito, bandi giovani.', c: 'var(--ig-teal-700)', bg: 'var(--ig-teal-50)', to: '/opportunita?area=impresa' },
            { ico: <I.Globe size={24}/>, t: 'Voglio andare all\u2019estero', d: 'Erasmus+, Corpo Europeo, work&travel.', c: 'var(--ig-amber-700)', bg: 'var(--ig-amber-50)', to: '/opportunita?area=estero' },
            { ico: <I.Award size={24}/>, t: 'Cerco un concorso', d: 'Concorsi Comune, Regione, Stato per under 36.', c: '#1b3a8a', bg: '#e8efff', to: '/opportunita?area=concorso' },
            { ico: <I.Heart size={24}/>, t: 'Ho bisogno di un servizio', d: 'Diritti, casa, salute, bonus, supporto.', c: '#a13564', bg: '#fbe9f0', to: '/opportunita?area=diritti' },
          ].map((p, idx) => (
            <Link key={p.t} to={p.to} className="ig-card" style={{ padding: 24, display: 'flex', flexDirection: 'column', gap: 12, textDecoration: 'none', color: 'inherit', minHeight: 200, transition: 'transform .15s, box-shadow .15s' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div style={{ width: 48, height: 48, borderRadius: 12, background: p.bg, color: p.c, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{p.ico}</div>
                <div style={{ fontSize: 12, fontFamily: 'var(--ig-font-mono)', color: 'var(--ig-ink-400)' }}>0{idx + 1}</div>
              </div>
              <h3 style={{ fontSize: 20, fontWeight: 700, lineHeight: 1.2, color: 'var(--ig-ink-900)' }}>{p.t}</h3>
              <p style={{ fontSize: 13, color: 'var(--ig-ink-500)', lineHeight: 1.5, flex: 1 }}>{p.d}</p>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, fontWeight: 600, color: p.c }}>Esplora <I.ArrowR size={14}/></div>
            </Link>
          ))}
        </div>
      </section>

      {/* In evidenza */}
      <section style={{ maxWidth: 1280, margin: '0 auto', padding: '60px 32px 0' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 24 }}>
          <h2 style={{ fontSize: 28, fontWeight: 700, letterSpacing: '-0.02em' }}>Opportunità in evidenza</h2>
          <Link to="/opportunita" style={{ fontSize: 14, fontWeight: 600 }}>Tutte →</Link>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
          {featured.map(s => <SchedaCard key={s.id} scheda={s} layout="grid"/>)}
        </div>
      </section>

      {/* Scadenze + Eventi */}
      <section style={{ maxWidth: 1280, margin: '0 auto', padding: '60px 32px 0' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
          <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ padding: '18px 22px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 36, height: 36, borderRadius: 8, background: 'var(--ig-amber-100)', color: 'var(--ig-amber-700)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><I.Clock size={18}/></div>
              <div>
                <h3 style={{ fontSize: 16, fontWeight: 700 }}>Scadenze imminenti</h3>
                <div style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}>Non perdere queste opportunità</div>
              </div>
            </div>
            <div>
              {deadlines.map((s, i) => (
                <Link key={s.id} to={`/scheda/${s.id}`} style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '16px 22px', borderBottom: i < deadlines.length - 1 ? '1px solid var(--ig-border-soft)' : 'none', textDecoration: 'none' }}>
                  <div style={{ width: 56, textAlign: 'center', padding: '8px 0', borderRadius: 8, background: s.urg === 'urgent' ? 'var(--ig-red-100)' : 'var(--ig-amber-100)', color: s.urg === 'urgent' ? 'var(--ig-red-700)' : 'var(--ig-amber-800)', flex: '0 0 auto' }}>
                    <div className="ig-num" style={{ fontSize: 18, fontWeight: 800, lineHeight: 1 }}>{s.daysLeft}</div>
                    <div style={{ fontSize: 10, fontWeight: 700 }}>GIORNI</div>
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ig-ink-900)', marginBottom: 3 }}>{s.title}</div>
                    <span className={`ig-badge ig-badge--${s.area}`} style={{ height: 20, fontSize: 11 }}>{s.areaLabel}</span>
                  </div>
                  <I.ChevR size={16} color="var(--ig-ink-400)"/>
                </Link>
              ))}
            </div>
          </div>

          <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ padding: '18px 22px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 36, height: 36, borderRadius: 8, background: 'var(--ig-teal-100)', color: 'var(--ig-teal-700)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><I.Calendar size={18}/></div>
              <div>
                <h3 style={{ fontSize: 16, fontWeight: 700 }}>Eventi prossimi</h3>
                <div style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}>Sportello e partner del territorio</div>
              </div>
              <Link to="/eventi" style={{ marginLeft: 'auto', fontSize: 13, fontWeight: 600 }}>Tutti →</Link>
            </div>
            <div>
              {upcoming.map((e, i) => (
                <EventRow key={e.id} ev={e} last={i === upcoming.length - 1}/>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section style={{ padding: '60px 32px' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', background: 'linear-gradient(120deg, var(--ig-teal-800) 0%, var(--ig-teal-700) 60%, var(--ig-teal-600) 100%)', borderRadius: 24, padding: '52px 48px', color: 'white', display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 48, alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.14em', color: 'rgba(255,255,255,0.7)', textTransform: 'uppercase', marginBottom: 10 }}>Orientamento personalizzato</div>
            <h2 style={{ fontSize: 36, fontWeight: 700, color: 'white', letterSpacing: '-0.02em', lineHeight: 1.1, marginBottom: 14 }}>Hai bisogno di orientamento personalizzato?</h2>
            <p style={{ fontSize: 16, color: 'rgba(255,255,255,0.82)', lineHeight: 1.55, marginBottom: 22 }}>Parla con uno dei 12 operatori dello sportello. Insieme analizziamo la tua situazione e ti accompagniamo.</p>
            <div style={{ display: 'flex', gap: 10 }}>
              <Link to="/prenota"><button className="ig-btn ig-btn--lg" style={{ background: 'white', color: 'var(--ig-teal-800)' }}><I.Calendar size={18}/> Prenota un colloquio</button></Link>
              <Link to="/ticket"><button className="ig-btn ig-btn--lg" style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.3)', color: 'white' }}><I.Chat size={18}/> Invia richiesta</button></Link>
            </div>
          </div>
          <div style={{ background: 'rgba(255,255,255,0.08)', borderRadius: 14, padding: 22, border: '1px solid rgba(255,255,255,0.15)' }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: 'rgba(255,255,255,0.65)', marginBottom: 14, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Modalità</div>
            {[
              [<I.User size={16}/>, 'In presenza', 'Piazza Garibaldi, 1'],
              [<I.Video size={16}/>, 'Videochiamata', 'Google Meet · 30 min'],
              [<I.Phone size={16}/>, 'Telefono', '9:00 - 17:30'],
              [<I.Mail size={16}/>, 'Email', 'Risposta entro 48h'],
            ].map(([ico, t, d]) => (
              <div key={t} style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10 }}>
                <div style={{ width: 36, height: 36, borderRadius: 8, background: 'rgba(255,255,255,0.12)', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{ico}</div>
                <div>
                  <div style={{ color: 'white', fontWeight: 600, fontSize: 14 }}>{t}</div>
                  <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.65)' }}>{d}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

function EventRow({ ev, last }) {
  const [state, dispatch] = useStore();
  const toast = useToast();
  const subscribed = state.myEvents.has(ev.id);
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '16px 22px', borderBottom: last ? 'none' : '1px solid var(--ig-border-soft)' }}>
      <div style={{ width: 56, textAlign: 'center', padding: '6px 0', borderRadius: 8, background: 'var(--ig-blue-50)', color: 'var(--ig-blue-700)', border: '1px solid var(--ig-blue-100)', flex: '0 0 auto' }}>
        <div className="ig-num" style={{ fontSize: 20, fontWeight: 800, lineHeight: 1 }}>{ev.day}</div>
        <div style={{ fontSize: 10, fontWeight: 700, marginTop: 2 }}>{ev.month}</div>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ig-ink-900)', marginBottom: 3 }}>{ev.title}</div>
        <div style={{ display: 'flex', gap: 10, fontSize: 12, color: 'var(--ig-ink-500)' }}>
          <span><I.MapPin size={11} style={{ display: 'inline', verticalAlign: '-1px', marginRight: 3 }}/>{ev.mode}</span>
          <span style={{ color: ev.status === 'full' ? 'var(--ig-red-700)' : 'var(--ig-green-700)' }}>· {ev.status === 'full' ? 'Posti esauriti' : `${ev.capacity - ev.registered} posti`}</span>
        </div>
      </div>
      {ev.status === 'full' ? (
        <button className="ig-btn ig-btn--secondary ig-btn--sm" onClick={() => toast.warning('Posti esauriti', 'Sei stato aggiunto alla lista d\u2019attesa.')}>Lista d\u2019attesa</button>
      ) : (
        <button className={subscribed ? 'ig-btn ig-btn--secondary ig-btn--sm' : 'ig-btn ig-btn--primary ig-btn--sm'} onClick={() => {
          dispatch({ type: 'TOGGLE_EVENT', id: ev.id });
          if (subscribed) toast.info('Iscrizione annullata', ev.title);
          else toast.success('Iscrizione confermata', `${ev.title} · ${ev.date} ${ev.time}`);
        }}>
          {subscribed ? <><I.Check size={14}/> Iscritto</> : 'Iscriviti'}
        </button>
      )}
    </div>
  );
}

window.PROTO_HOME = PublicHome;
window.PROTO_HEADER = PublicHeader;
window.PROTO_FOOTER = PublicFooter;
window.PROTO_SCHEDA_CARD = SchedaCard;
window.PROTO_EVENT_ROW = EventRow;

})();
