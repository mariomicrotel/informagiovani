/* global React, IGIcons, IG_UI, IG_DATA */
(function(){
var { useState, useMemo } = React;
var I = IGIcons;
var { Link, navigate, useToast, useModal, useConfirm, useStore, getScheda, getTicket } = IG_UI;
var { SCHEDE, EVENTI, TICKET, UTENTI, OPERATORI, TICKET_STATUSES, AREAS } = IG_DATA;

// ============================================================
// BACKEND SHELL — sidebar + topbar
// ============================================================
function BackendShell({ route, children, breadcrumb, active }) {
  const [storeState] = useStore();
  const ticketCount = TICKET.length + storeState.newTickets.length;
  const verifyCount = SCHEDE.filter(s => (storeState.schedeStatus[s.id] || s.status) === 'state-review').length;
  return (
    <div className="ig" style={{ background: 'var(--ig-bg)', display: 'flex', minHeight: '100vh' }}>
      <aside style={{ width: 240, background: 'var(--ig-blue-900)', color: 'white', flex: '0 0 auto', display: 'flex', flexDirection: 'column', position: 'sticky', top: 0, height: '100vh' }}>
        <div style={{ padding: '18px 16px', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
          <Link to="/backend" style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none' }}>
            <div style={{ width: 34, height: 34, borderRadius: 8, background: 'var(--ig-amber-500)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <svg width="20" height="20" viewBox="0 0 28 28" fill="none">
                <path d="M4 22 L14 4 L24 22 Z" stroke="var(--ig-blue-900)" strokeWidth="2.4" strokeLinejoin="round"/>
                <circle cx="14" cy="15" r="2.4" fill="var(--ig-blue-900)"/>
              </svg>
            </div>
            <div style={{ lineHeight: 1.1 }}>
              <div style={{ fontSize: 13, fontWeight: 800, color: 'white' }}>Informagiovani</div>
              <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.5)', marginTop: 2 }}>Console operatori</div>
            </div>
          </Link>
        </div>

        <nav style={{ flex: 1, padding: '14px 8px', overflowY: 'auto' }}>
          <SideGroup title="Panoramica">
            <SideItem to="/backend" active={active === 'Dashboard'} icon={<I.Home size={16}/>} label="Dashboard"/>
            <SideItem to="/backend/report" active={active === 'Report'} icon={<I.Chart size={16}/>} label="Report"/>
          </SideGroup>
          <SideGroup title="Contenuti">
            <SideItem to="/backend/schede" active={active === 'Schede'} icon={<I.Doc size={16}/>} label="Schede informative" badge={verifyCount}/>
            <SideItem to="/backend/fonti" active={active === 'Fonti'} icon={<I.Link size={16}/>} label="Fonti"/>
            <SideItem to="/backend/eventi" active={active === 'Eventi'} icon={<I.Calendar size={16}/>} label="Eventi"/>
          </SideGroup>
          <SideGroup title="Sportello">
            <SideItem to="/backend/utenti" active={active === 'Utenti'} icon={<I.Users size={16}/>} label="Utenti giovani"/>
            <SideItem to="/backend/colloqui" active={active === 'Colloqui'} icon={<I.Chat size={16}/>} label="Colloqui"/>
            <SideItem to="/backend/appuntamenti" active={active === 'Appuntamenti'} icon={<I.Calendar size={16}/>} label="Appuntamenti"/>
            <SideItem to="/backend/ticket" active={active === 'Ticket'} icon={<I.Flag size={16}/>} label="Ticket" badge={ticketCount}/>
          </SideGroup>
          <SideGroup title="Sistema">
            <SideItem to="/" active={false} icon={<I.ArrowL size={16}/>} label="Torna al sito"/>
          </SideGroup>
        </nav>
        <div style={{ padding: 12, borderTop: '1px solid rgba(255,255,255,0.08)', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--ig-teal-600)', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 12 }}>GF</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'white' }}>Giulia Fontana</div>
            <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.55)' }}>Responsabile servizio</div>
          </div>
        </div>
      </aside>

      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        <div style={{ background: 'white', borderBottom: '1px solid var(--ig-border-soft)', padding: '12px 28px', display: 'flex', alignItems: 'center', gap: 16, position: 'sticky', top: 0, zIndex: 20 }}>
          <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', display: 'flex', alignItems: 'center', gap: 6 }}>
            {breadcrumb && breadcrumb.map((b, i) => (
              <React.Fragment key={i}>
                {i > 0 && <I.ChevR size={11}/>}
                {b.to ? <Link to={b.to} style={{ color: 'var(--ig-ink-500)' }}>{b.label}</Link>
                      : <span style={{ color: 'var(--ig-ink-900)', fontWeight: 600 }}>{b.label}</span>}
              </React.Fragment>
            ))}
          </div>
          <div style={{ flex: 1, maxWidth: 420, position: 'relative' }}>
            <input className="ig-input" placeholder="Cerca schede, utenti, ticket… (Ctrl K)" style={{ paddingLeft: 38, height: 36, fontSize: 13 }}/>
            <div style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }}>
              <I.Search size={15} color="var(--ig-ink-400)"/>
            </div>
          </div>
          <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 4 }}>
            <button className="ig-btn ig-btn--ghost ig-btn--icon" style={{ width: 34, height: 34, position: 'relative' }}>
              <I.Bell size={16}/>
              <span style={{ position: 'absolute', top: 7, right: 7, width: 7, height: 7, background: 'var(--ig-red-600)', borderRadius: '50%', border: '2px solid white' }}/>
            </button>
          </div>
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>{children}</div>
      </div>
    </div>
  );
}

function SideGroup({ title, children }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <div style={{ fontSize: 10, fontWeight: 800, color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', letterSpacing: '0.1em', padding: '0 10px 8px' }}>{title}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>{children}</div>
    </div>
  );
}
function SideItem({ to, active, icon, label, badge }) {
  return (
    <Link to={to} style={{
      display: 'flex', alignItems: 'center', gap: 10,
      padding: '8px 10px', borderRadius: 5,
      fontSize: 13, fontWeight: 600,
      color: active ? 'white' : 'rgba(255,255,255,0.7)',
      background: active ? 'rgba(255,255,255,0.12)' : 'transparent',
      borderLeft: active ? '3px solid var(--ig-amber-500)' : '3px solid transparent', marginLeft: -3,
      textDecoration: 'none',
    }}>
      <span style={{ color: active ? 'var(--ig-amber-500)' : 'rgba(255,255,255,0.45)' }}>{icon}</span>
      <span style={{ flex: 1 }}>{label}</span>
      {badge ? <span style={{ background: 'var(--ig-amber-500)', color: 'var(--ig-blue-900)', fontSize: 10, fontWeight: 800, padding: '1px 6px', borderRadius: 999, minWidth: 18, textAlign: 'center' }}>{badge}</span> : null}
    </Link>
  );
}

// ============================================================
// DASHBOARD
// ============================================================
function BackendDashboard({ route }) {
  const [storeState] = useStore();
  const verifyCount = SCHEDE.filter(s => (storeState.schedeStatus[s.id] || s.status) === 'state-review').length;
  const ticketCount = TICKET.length + storeState.newTickets.length;
  const newTickets = [...storeState.newTickets].reverse();
  const allTickets = [...newTickets, ...TICKET].slice(0, 6);

  return (
    <BackendShell route={route} active="Dashboard" breadcrumb={[{ label: 'Console', to: '/backend' }, { label: 'Dashboard' }]}>
      <div style={{ padding: '24px 28px 0' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 22 }}>
          <div>
            <h1 style={{ fontSize: 26, fontWeight: 700, letterSpacing: '-0.02em' }}>Buongiorno, Giulia 👋</h1>
            <p style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginTop: 4 }}>Sabato 14 marzo 2026 · sintesi dell'attività</p>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <Link to="/backend/schede"><button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Plus size={14}/> Nuova scheda</button></Link>
            <Link to="/backend/colloqui/nuovo"><button className="ig-btn ig-btn--primary ig-btn--sm"><I.Chat size={14}/> Nuovo colloquio</button></Link>
          </div>
        </div>

        {/* KPI clickable */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 22 }}>
          {[
            ['Schede pubblicate', SCHEDE.filter(s => (storeState.schedeStatus[s.id] || s.status) === 'state-pub').length, '14 negli ultimi 7g', 'var(--ig-blue-700)', <I.Doc size={18}/>, '/backend/schede'],
            ['Schede da verificare', verifyCount, verifyCount > 0 ? 'azione richiesta' : 'tutto a posto', 'var(--ig-amber-700)', <I.Alert size={18}/>, '/backend/schede?status=state-review'],
            ['Ticket aperti', ticketCount, 'tempo medio 18h', 'var(--ig-teal-700)', <I.Chat size={18}/>, '/backend/ticket'],
            ['Appuntamenti oggi', 8, '3 in presenza · 5 remoto', 'var(--ig-violet-700)', <I.Calendar size={18}/>, '/backend/appuntamenti'],
          ].map(([l, v, h, c, ico, to]) => (
            <Link key={l} to={to} className="ig-card" style={{ padding: 18, textDecoration: 'none', color: 'inherit', cursor: 'pointer', transition: 'transform .12s' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
                <div style={{ width: 32, height: 32, borderRadius: 8, background: `color-mix(in srgb, ${c} 12%, white)`, color: c, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{ico}</div>
                <I.ArrowR size={14} color="var(--ig-ink-300)"/>
              </div>
              <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--ig-ink-500)' }}>{l}</div>
              <div className="ig-num" style={{ fontSize: 28, fontWeight: 800, color: 'var(--ig-ink-900)', letterSpacing: '-0.02em', lineHeight: 1.1, margin: '4px 0' }}>{v}</div>
              <div style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>{h}</div>
            </Link>
          ))}
        </div>

        {/* Lists */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h3 style={{ fontSize: 15, fontWeight: 700 }}>Ultime richieste</h3>
              <Link to="/backend/ticket" style={{ fontSize: 12, fontWeight: 600 }}>Tutte →</Link>
            </div>
            {allTickets.map((t, i) => {
              const status = storeState.ticketStates[t.id] || t.status;
              const statusInfo = TICKET_STATUSES.find(s => s.id === status);
              return (
                <Link key={t.id} to={`/backend/ticket/${t.id}`} style={{ display: 'grid', gridTemplateColumns: '64px 1fr 100px 90px', gap: 10, padding: '12px 20px', borderBottom: i < allTickets.length - 1 ? '1px solid var(--ig-border-soft)' : 'none', alignItems: 'center', textDecoration: 'none' }}>
                  <span style={{ fontSize: 11, fontFamily: 'var(--ig-font-mono)', color: 'var(--ig-ink-500)' }}>#{t.id}</span>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-900)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t.subject}</div>
                    <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', marginTop: 2 }}>{t.user}</div>
                  </div>
                  <span className={`ig-badge ig-badge--${t.area}`} style={{ height: 20, fontSize: 10 }}>{t.areaLabel}</span>
                  <span style={{ fontSize: 10, fontWeight: 700, color: statusInfo.color }}>● {statusInfo.label}</span>
                </Link>
              );
            })}
          </div>

          <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h3 style={{ fontSize: 15, fontWeight: 700 }}>Schede da validare</h3>
              <Link to="/backend/schede?status=state-review" style={{ fontSize: 12, fontWeight: 600 }}>Apri coda →</Link>
            </div>
            {SCHEDE.filter(s => (storeState.schedeStatus[s.id] || s.status) === 'state-review').slice(0, 4).map((s, i, arr) => (
              <Link key={s.id} to={`/backend/schede/${s.id}`} style={{ display: 'grid', gridTemplateColumns: '1fr 100px 80px', gap: 10, padding: '14px 20px', borderBottom: i < arr.length - 1 ? '1px solid var(--ig-border-soft)' : 'none', alignItems: 'center', textDecoration: 'none' }}>
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-900)' }}>{s.title}</div>
                  <div style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>Autore: {s.updatedBy}</div>
                </div>
                <span className={`ig-badge ig-badge--${s.area}`} style={{ height: 20, fontSize: 10 }}>{s.areaLabel}</span>
                <span className="ig-badge ig-badge--state-review" style={{ height: 20, fontSize: 10 }}>Da verificare</span>
              </Link>
            ))}
            {verifyCount === 0 && (
              <div style={{ padding: '40px 20px', textAlign: 'center', color: 'var(--ig-green-700)' }}>
                <I.Check size={28} color="var(--ig-green-600)" style={{ margin: '0 auto 8px' }}/>
                <div style={{ fontSize: 13, fontWeight: 700 }}>Tutto sotto controllo</div>
                <div style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}>Nessuna scheda in coda di verifica.</div>
              </div>
            )}
          </div>
        </div>
      </div>
    </BackendShell>
  );
}

// ============================================================
// SCHEDE LIST (interactive)
// ============================================================
function BackendSchede({ route }) {
  const [storeState, dispatch] = useStore();
  const { open, close } = useModal();
  const confirm = useConfirm();
  const toast = useToast();
  const [statusFilter, setStatusFilter] = useState(route.query.status || 'all');
  const [areaFilter, setAreaFilter] = useState('all');
  const [q, setQ] = useState('');
  const [selected, setSelected] = useState(new Set());

  const filtered = useMemo(() => {
    return SCHEDE.filter(s => {
      const status = storeState.schedeStatus[s.id] || s.status;
      if (statusFilter !== 'all' && status !== statusFilter) return false;
      if (areaFilter !== 'all' && s.area !== areaFilter) return false;
      if (q.trim() && !(s.title + ' ' + s.id).toLowerCase().includes(q.toLowerCase())) return false;
      return true;
    });
  }, [statusFilter, areaFilter, q, storeState.schedeStatus]);

  const tabs = [
    ['all', 'Tutte'], ['state-pub', 'Pubblicate'], ['state-review', 'Da verificare'],
    ['state-draft', 'Bozze'], ['state-valid', 'Validate'], ['state-update', 'Da aggiornare'],
  ];

  const toggleSelect = (id) => setSelected(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });

  const bulk = async (action) => {
    if (action === 'publish') {
      selected.forEach(id => dispatch({ type: 'SET_SCHEDA_STATUS', id, status: 'state-pub' }));
      toast.success(`${selected.size} schede pubblicate`);
    } else if (action === 'archive') {
      const ok = await confirm({ title: 'Archiviare le schede selezionate?', message: `Stai per archiviare ${selected.size} schede. Potrai sempre ripristinarle.`, confirmLabel: 'Archivia', danger: true });
      if (ok) { selected.forEach(id => dispatch({ type: 'SET_SCHEDA_STATUS', id, status: 'state-archive' })); toast.info(`${selected.size} schede archiviate`); }
    } else if (action === 'review') {
      selected.forEach(id => dispatch({ type: 'SET_SCHEDA_STATUS', id, status: 'state-update' }));
      toast.success(`${selected.size} schede segnate da aggiornare`);
    } else if (action === 'export') {
      toast.success('CSV in download', `${selected.size} righe esportate`);
    }
    setSelected(new Set());
  };

  return (
    <BackendShell route={route} active="Schede" breadcrumb={[{ label: 'Console', to: '/backend' }, { label: 'Contenuti' }, { label: 'Schede informative' }]}>
      <div style={{ padding: '20px 28px 0', background: 'white', borderBottom: '1px solid var(--ig-border-soft)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 18 }}>
          <div>
            <h1 style={{ fontSize: 24, fontWeight: 700, letterSpacing: '-0.02em' }}>Schede informative</h1>
            <p style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginTop: 4 }}>{SCHEDE.length} schede totali · {filtered.length} mostrate</p>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="ig-btn ig-btn--secondary ig-btn--sm" onClick={() => toast.success('CSV in download', 'schede_export.csv · 487 righe')}><I.Download size={14}/> Esporta CSV</button>
            <button className="ig-btn ig-btn--primary ig-btn--sm" onClick={() => open({
              title: 'Nuova scheda informativa', icon: <I.Plus size={20}/>, width: 540,
              content: (
                <div>
                  <p style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginBottom: 14 }}>Compila i campi base. Potrai completarla nella pagina di modifica.</p>
                  <label className="ig-label">Titolo</label>
                  <input className="ig-input" placeholder="Es. Bando 2026 · contributo per…" autoFocus/>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 12 }}>
                    <div><label className="ig-label">Area</label><select className="ig-input">{AREAS.map(a => <option key={a.id}>{a.label}</option>)}</select></div>
                    <div><label className="ig-label">Tipologia</label><select className="ig-input"><option>Bando</option><option>Concorso</option><option>Corso</option><option>Tirocinio</option></select></div>
                  </div>
                </div>
              ),
              actions: <>
                <button className="ig-btn ig-btn--ghost" onClick={close}>Annulla</button>
                <button className="ig-btn ig-btn--primary" onClick={() => { toast.success('Scheda creata come bozza', 'Aperto l\u2019editor di scheda'); close(); }}>Crea e modifica</button>
              </>,
            })}><I.Plus size={14}/> Nuova scheda</button>
          </div>
        </div>

        <div style={{ display: 'flex', gap: 2, paddingTop: 2 }}>
          {tabs.map(([k, l]) => {
            const count = k === 'all' ? SCHEDE.length : SCHEDE.filter(s => (storeState.schedeStatus[s.id] || s.status) === k).length;
            const active = statusFilter === k;
            return (
              <button key={k} onClick={() => setStatusFilter(k)} style={{
                padding: '10px 12px', fontSize: 13, fontWeight: 600,
                color: active ? 'var(--ig-blue-700)' : 'var(--ig-ink-700)',
                borderBottom: active ? '2px solid var(--ig-blue-700)' : '2px solid transparent',
                marginBottom: -1, background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'inherit',
              }}>{l} · <span style={{ color: 'var(--ig-ink-400)' }}>{count}</span></button>
            );
          })}
        </div>
      </div>

      <div style={{ padding: '14px 28px', background: 'white', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', gap: 8, alignItems: 'center' }}>
        <div style={{ flex: 1, maxWidth: 320, position: 'relative' }}>
          <input className="ig-input" placeholder="Cerca per titolo o ID…" value={q} onChange={e => setQ(e.target.value)} style={{ height: 36, paddingLeft: 36, fontSize: 13 }}/>
          <div style={{ position: 'absolute', left: 11, top: '50%', transform: 'translateY(-50%)' }}><I.Search size={14} color="var(--ig-ink-400)"/></div>
        </div>
        <select className="ig-input" style={{ width: 'auto', height: 36, fontSize: 13 }} value={areaFilter} onChange={e => setAreaFilter(e.target.value)}>
          <option value="all">Area: tutte</option>
          {AREAS.map(a => <option key={a.id} value={a.id}>Area: {a.label}</option>)}
        </select>
      </div>

      {selected.size > 0 && (
        <div style={{ padding: '12px 28px', background: 'var(--ig-blue-700)', color: 'white', display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ width: 18, height: 18, borderRadius: 4, background: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <I.Check size={12} color="var(--ig-blue-700)" strokeWidth={3}/>
          </span>
          <span style={{ fontSize: 13, fontWeight: 600 }}>{selected.size} schede selezionate</span>
          <div style={{ display: 'flex', gap: 6, marginLeft: 14 }}>
            <button onClick={() => bulk('publish')} style={{ height: 28, padding: '0 12px', background: 'rgba(255,255,255,0.15)', color: 'white', border: 'none', borderRadius: 4, fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>Pubblica</button>
            <button onClick={() => bulk('review')} style={{ height: 28, padding: '0 12px', background: 'rgba(255,255,255,0.15)', color: 'white', border: 'none', borderRadius: 4, fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>Segna da aggiornare</button>
            <button onClick={() => bulk('archive')} style={{ height: 28, padding: '0 12px', background: 'rgba(255,255,255,0.15)', color: 'white', border: 'none', borderRadius: 4, fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>Archivia</button>
            <button onClick={() => bulk('export')} style={{ height: 28, padding: '0 12px', background: 'rgba(255,255,255,0.15)', color: 'white', border: 'none', borderRadius: 4, fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>Esporta CSV</button>
          </div>
          <button onClick={() => setSelected(new Set())} style={{ marginLeft: 'auto', background: 'none', border: 'none', color: 'white', cursor: 'pointer', fontSize: 12 }}>Deseleziona tutto ×</button>
        </div>
      )}

      <div style={{ padding: '14px 28px 28px' }}>
        {filtered.length === 0 ? (
          <div className="ig-card" style={{ padding: '60px 40px', textAlign: 'center' }}>
            <I.Search size={28} color="var(--ig-ink-400)" style={{ margin: '0 auto 14px' }}/>
            <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 6 }}>Nessuna scheda</h3>
            <p style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>Modifica i filtri o crea una nuova scheda.</p>
          </div>
        ) : (
          <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '36px 100px 1fr 130px 120px 100px 110px 100px', gap: 12, padding: '10px 18px', background: 'var(--ig-ink-50)', borderBottom: '1px solid var(--ig-border-soft)', fontSize: 10, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              <span></span><span>ID</span><span>Titolo</span><span>Area</span><span>Fonte</span><span>Scadenza</span><span>Stato</span><span style={{ textAlign: 'right' }}>Azioni</span>
            </div>
            {filtered.map((s, i) => {
              const sel = selected.has(s.id);
              const status = storeState.schedeStatus[s.id] || s.status;
              const statusLabels = { 'state-draft': 'Bozza', 'state-review': 'Da verificare', 'state-valid': 'Validata', 'state-pub': 'Pubblicata', 'state-archive': 'Archiviata', 'state-update': 'Da aggiornare', 'state-exp': 'Scaduta' };
              return (
                <div key={s.id} style={{
                  display: 'grid', gridTemplateColumns: '36px 100px 1fr 130px 120px 100px 110px 100px', gap: 12,
                  padding: '12px 18px', borderBottom: i < filtered.length - 1 ? '1px solid var(--ig-border-soft)' : 'none',
                  alignItems: 'center', background: sel ? 'var(--ig-blue-50)' : 'white',
                }}>
                  <button onClick={() => toggleSelect(s.id)} style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}>
                    <span style={{ width: 16, height: 16, borderRadius: 3, border: sel ? 'none' : '1.5px solid var(--ig-ink-300)', background: sel ? 'var(--ig-primary)' : 'white', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
                      {sel && <I.Check size={11} color="white" strokeWidth={3}/>}
                    </span>
                  </button>
                  <span style={{ fontFamily: 'var(--ig-font-mono)', fontSize: 11, color: 'var(--ig-ink-500)' }}>{s.id}</span>
                  <Link to={`/backend/schede/${s.id}`} style={{ fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-900)', textDecoration: 'none', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{s.title}</Link>
                  <span className={`ig-badge ig-badge--${s.area}`} style={{ height: 20, fontSize: 10 }}>{s.areaLabel}</span>
                  <span style={{ fontSize: 12, color: 'var(--ig-ink-700)' }}>{s.source}</span>
                  <span style={{ fontSize: 12, fontWeight: 600, color: s.urg === 'urgent' ? 'var(--ig-red-700)' : 'var(--ig-ink-700)' }}>
                    {s.daysLeft ? `${s.daysLeft} giorni` : 'Sempre aperta'}
                  </span>
                  <span className={`ig-badge ig-badge--${status}`} style={{ height: 20, fontSize: 10 }}>{statusLabels[status]}</span>
                  <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                    <Link to={`/scheda/${s.id}`} title="Anteprima pubblica"><button className="ig-btn ig-btn--ghost ig-btn--icon" style={{ width: 28, height: 28 }}><I.Eye size={13}/></button></Link>
                    <Link to={`/backend/schede/${s.id}`} title="Modifica"><button className="ig-btn ig-btn--ghost ig-btn--icon" style={{ width: 28, height: 28 }}><I.Edit size={13}/></button></Link>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </BackendShell>
  );
}

// ============================================================
// SCHEDA EDITOR (single)
// ============================================================
function BackendSchedaEdit({ route }) {
  const id = route.parts[2];
  const [storeState, dispatch] = useStore();
  const toast = useToast();
  const confirm = useConfirm();
  const { open, close } = useModal();
  const scheda = getScheda(id, storeState);
  const [data, setData] = useState({ title: scheda?.title || '', short: scheda?.short || '' });

  if (!scheda) {
    return <BackendShell active="Schede" route={route} breadcrumb={[{ label: 'Schede', to: '/backend/schede' }, { label: 'Non trovata' }]}>
      <div style={{ padding: 60, textAlign: 'center' }}>Scheda non trovata. <Link to="/backend/schede">Torna all'elenco</Link></div>
    </BackendShell>;
  }

  const changeStatus = (status, label) => {
    dispatch({ type: 'SET_SCHEDA_STATUS', id: scheda.id, status });
    toast.success(`Scheda ${label}`, scheda.title);
  };

  return (
    <BackendShell route={route} active="Schede" breadcrumb={[{ label: 'Console', to: '/backend' }, { label: 'Schede', to: '/backend/schede' }, { label: scheda.id }]}>
      <div style={{ padding: '24px 28px 0', background: 'white', borderBottom: '1px solid var(--ig-border-soft)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 14 }}>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
              <span className={`ig-badge ig-badge--${scheda.area}`}>{scheda.areaLabel}</span>
              <span className={`ig-badge ig-badge--${scheda.status}`}>{scheda.statusLabel}</span>
              <span style={{ fontSize: 11, fontFamily: 'var(--ig-font-mono)', color: 'var(--ig-ink-500)', paddingTop: 4 }}>{scheda.id}</span>
            </div>
            <h1 style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.01em' }}>{scheda.title}</h1>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            <Link to={`/scheda/${scheda.id}`}><button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Eye size={14}/> Anteprima pubblica</button></Link>
            <button className="ig-btn ig-btn--secondary ig-btn--sm" onClick={() => open({ title: 'Anteprima PDF', subtitle: scheda.title, icon: <I.Doc size={20}/>, width: 520, content: <div style={{ padding: 20, background: 'var(--ig-ink-50)', borderRadius: 8, textAlign: 'center' }}><I.Doc size={48} color="var(--ig-ink-400)" style={{ margin: '0 auto 12px' }}/><div style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>Anteprima PDF in generazione…</div></div>, actions: <><button className="ig-btn ig-btn--ghost" onClick={close}>Chiudi</button><button className="ig-btn ig-btn--primary" onClick={() => { toast.success('PDF generato', `${scheda.id}.pdf · 234 KB`); close(); }}><I.Download size={14}/> Scarica PDF</button></> })}><I.Doc size={14}/> Genera PDF</button>
          </div>
        </div>

        {/* Workflow actions */}
        <div style={{ display: 'flex', gap: 6, paddingBottom: 14 }}>
          <button className="ig-btn ig-btn--ghost ig-btn--sm" onClick={() => toast.success('Bozza salvata')}>💾 Salva bozza</button>
          {scheda.status !== 'state-review' && <button className="ig-btn ig-btn--secondary ig-btn--sm" onClick={() => changeStatus('state-review', 'inviata a verifica')}>Invia a verifica</button>}
          {scheda.status === 'state-review' && <button className="ig-btn ig-btn--secondary ig-btn--sm" onClick={() => changeStatus('state-valid', 'validata')}><I.Check size={14}/> Valida</button>}
          {scheda.status !== 'state-pub' && <button className="ig-btn ig-btn--primary ig-btn--sm" onClick={() => changeStatus('state-pub', 'pubblicata')}><I.Send size={14}/> Pubblica</button>}
          <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ color: 'var(--ig-red-700)' }} onClick={async () => {
            const ok = await confirm({ title: 'Archiviare questa scheda?', message: 'Sarà rimossa dal frontend pubblico. Potrai ripristinarla.', confirmLabel: 'Archivia', danger: true });
            if (ok) changeStatus('state-archive', 'archiviata');
          }}>Archivia</button>
        </div>
      </div>

      <div style={{ padding: '24px 28px 32px' }}>
        <div className="ig-card" style={{ padding: 24, marginBottom: 16 }}>
          <h3 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)', marginBottom: 14 }}>01 · Informazioni principali</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <div><label className="ig-label">Titolo</label><input className="ig-input" value={data.title} onChange={e => setData(d => ({...d, title: e.target.value}))}/></div>
            <div><label className="ig-label">Tipologia</label><input className="ig-input" readOnly value={scheda.type}/></div>
          </div>
          <div style={{ marginTop: 14 }}><label className="ig-label">Descrizione breve</label><textarea className="ig-textarea" value={data.short} onChange={e => setData(d => ({...d, short: e.target.value}))} style={{ minHeight: 80 }}/></div>
        </div>
        <div className="ig-card" style={{ padding: 24, marginBottom: 16 }}>
          <h3 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)', marginBottom: 14 }}>02 · Fonte e verifica</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <div><label className="ig-label">Fonte principale</label><input className="ig-input" readOnly value={scheda.source}/></div>
            <div><label className="ig-label">URL fonte</label><input className="ig-input" readOnly value={scheda.sourceUrl}/></div>
            <div><label className="ig-label">Affidabilità</label><div className="ig-input" style={{ display: 'flex', alignItems: 'center' }}><span className={`ig-badge ig-badge--src-${scheda.sourceClass}`}><I.ShieldChk size={11}/> {scheda.sourceClass === 'ufficiale' ? 'Ufficiale' : 'Partner'}</span></div></div>
            <div><label className="ig-label">Responsabile controllo</label><input className="ig-input" readOnly value={scheda.updatedBy}/></div>
          </div>
        </div>
      </div>
    </BackendShell>
  );
}

window.PROTO_BACKEND_DASHBOARD = BackendDashboard;
window.PROTO_BACKEND_SCHEDE = BackendSchede;
window.PROTO_BACKEND_SCHEDA_EDIT = BackendSchedaEdit;
window.PROTO_BACKEND_SHELL = BackendShell;

})();
