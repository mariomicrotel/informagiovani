/* global React, IGIcons, IG_UI, IG_DATA */
(function(){
var { useState, useMemo, useEffect } = React;
var I = IGIcons;
var { Link, navigate, useToast, useModal, useConfirm, useStore, getScheda } = IG_UI;
var { SCHEDE, EVENTI, AREAS } = IG_DATA;

// ============================================================
// OPPORTUNITÀ LIST · interactive filters + search + sort
// ============================================================
function PublicList({ route }) {
  const initialArea = route.query.area || '';
  const initialQ = route.query.q || '';
  const [filters, setFilters] = useState({
    areas: initialArea ? [initialArea] : [],
    targets: [],
    territories: [],
    urgencies: [],
    query: initialQ,
  });
  const [sortBy, setSortBy] = useState('consigliate');
  const [storeState] = useStore();

  // React to route changes (e.g. from header clicks)
  useEffect(() => {
    setFilters(f => ({
      ...f,
      areas: route.query.area ? [route.query.area] : [],
      query: route.query.q || '',
    }));
  }, [route.query.area, route.query.q]);

  const filtered = useMemo(() => {
    let list = SCHEDE.filter(s => s.statusLabel !== 'Scaduta');
    if (filters.areas.length) list = list.filter(s => filters.areas.includes(s.area));
    if (filters.targets.length) list = list.filter(s => s.target.some(t => filters.targets.includes(t)));
    if (filters.territories.length) list = list.filter(s => filters.territories.includes(s.territory));
    if (filters.urgencies.length) list = list.filter(s => filters.urgencies.includes(s.urg));
    if (filters.query.trim()) {
      const q = filters.query.toLowerCase();
      list = list.filter(s => (s.title + ' ' + s.short + ' ' + s.areaLabel + ' ' + s.source).toLowerCase().includes(q));
    }
    if (sortBy === 'scadenza') list = list.sort((a, b) => (a.daysLeft ?? 999) - (b.daysLeft ?? 999));
    if (sortBy === 'recenti') list = list.sort((a, b) => a.updated.localeCompare(b.updated));
    if (sortBy === 'consultate') list = list.sort((a, b) => b.views - a.views);
    return list;
  }, [filters, sortBy]);

  const totalActive = filters.areas.length + filters.targets.length + filters.territories.length + filters.urgencies.length + (filters.query ? 1 : 0);

  const toggle = (key, value) => setFilters(f => {
    const arr = f[key] || [];
    return { ...f, [key]: arr.includes(value) ? arr.filter(x => x !== value) : [...arr, value] };
  });
  const reset = () => setFilters({ areas: [], targets: [], territories: [], urgencies: [], query: '' });

  const SchedaCard = window.PROTO_SCHEDA_CARD;

  return (
    <div className="ig" style={{ background: 'var(--ig-bg)' }}>
      <div style={{ background: 'white', borderBottom: '1px solid var(--ig-border-soft)' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '18px 32px 22px' }}>
          <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', display: 'flex', alignItems: 'center', gap: 6, marginBottom: 14 }}>
            <Link to="/" style={{ color: 'var(--ig-ink-500)' }}>Home</Link>
            <I.ChevR size={12}/>
            <span style={{ color: 'var(--ig-ink-900)', fontWeight: 600 }}>Opportunità e servizi</span>
          </div>
          <h1 style={{ fontSize: 32, fontWeight: 700, letterSpacing: '-0.025em', marginBottom: 6 }}>Opportunità e servizi</h1>
          <p style={{ fontSize: 15, color: 'var(--ig-ink-500)' }}>{filtered.length} schede mostrate · filtra per area, target, territorio o scadenza.</p>
        </div>
      </div>

      {/* Search bar */}
      <div style={{ maxWidth: 1280, margin: '20px auto 0', padding: '0 32px' }}>
        <div className="ig-card" style={{ padding: 10, display: 'flex', gap: 10 }}>
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 10, padding: '0 14px' }}>
            <I.Search size={18} color="var(--ig-ink-400)"/>
            <input
              value={filters.query}
              onChange={e => setFilters(f => ({ ...f, query: e.target.value }))}
              placeholder="Cerca tra opportunità, corsi, concorsi, eventi…"
              style={{ flex: 1, border: 'none', outline: 'none', fontSize: 15, padding: '12px 0', background: 'transparent', fontFamily: 'inherit' }}
            />
            {filters.query && <button onClick={() => setFilters(f => ({ ...f, query: '' }))} style={{ background: 'none', border: 'none', padding: 4, color: 'var(--ig-ink-400)', cursor: 'pointer' }}><I.X size={16}/></button>}
          </div>
        </div>

        {totalActive > 0 && (
          <div style={{ marginTop: 14, display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
            <span style={{ fontSize: 12, color: 'var(--ig-ink-500)', fontWeight: 600 }}>Filtri attivi:</span>
            {filters.areas.map(a => {
              const area = AREAS.find(x => x.id === a);
              return <FilterChip key={a} label={area?.label || a} onRemove={() => toggle('areas', a)}/>;
            })}
            {filters.targets.map(t => <FilterChip key={t} label={t} onRemove={() => toggle('targets', t)}/>)}
            {filters.territories.map(t => <FilterChip key={t} label={t} onRemove={() => toggle('territories', t)}/>)}
            {filters.urgencies.map(u => <FilterChip key={u} label={u === 'urgent' ? '≤ 7 giorni' : u === 'soon' ? '≤ 30 giorni' : 'Sempre aperte'} onRemove={() => toggle('urgencies', u)}/>)}
            {filters.query && <FilterChip label={`"${filters.query}"`} onRemove={() => setFilters(f => ({ ...f, query: '' }))}/>}
            <button onClick={reset} style={{ background: 'none', border: 'none', color: 'var(--ig-blue-700)', fontSize: 12, fontWeight: 600, cursor: 'pointer', textDecoration: 'underline' }}>Azzera tutti</button>
          </div>
        )}
      </div>

      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '22px 32px 60px', display: 'grid', gridTemplateColumns: '270px 1fr', gap: 28 }}>
        {/* SIDEBAR FILTERS */}
        <aside>
          <div className="ig-card" style={{ padding: '4px 22px', position: 'sticky', top: 100 }}>
            <FilterGroup title="Area tematica" options={AREAS.map(a => [a.id, a.label, SCHEDE.filter(s => s.area === a.id).length])} selected={filters.areas} onToggle={v => toggle('areas', v)}/>
            <FilterGroup title="Target" options={[['Universitari','Universitari'],['NEET','NEET'],['Diplomati','Diplomati'],['18–29 anni','18–29 anni'],['Aspiranti imprenditori','Aspiranti imprenditori'],['Disoccupati','Disoccupati']]} selected={filters.targets} onToggle={v => toggle('targets', v)}/>
            <FilterGroup title="Territorio" options={[['Enna città','Enna città'],['Provincia di Enna','Provincia di Enna'],['Sicilia','Sicilia'],['Italia','Italia'],['Europa','Europa']]} selected={filters.territories} onToggle={v => toggle('territories', v)}/>
            <FilterGroup title="Scadenza" options={[['urgent','Entro 7 giorni'],['soon','Entro 30 giorni'],['ok','Sempre aperte']]} selected={filters.urgencies} onToggle={v => toggle('urgencies', v)}/>
          </div>
        </aside>

        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
            <div style={{ fontSize: 15, color: 'var(--ig-ink-700)' }}>
              <strong style={{ color: 'var(--ig-ink-900)', fontWeight: 700 }}>{filtered.length} risultati</strong>{filters.query && ` per "${filters.query}"`}
            </div>
            <div style={{ display: 'flex', gap: 6 }}>
              {[['consigliate','Consigliate'],['scadenza','In scadenza'],['recenti','Più recenti'],['consultate','Più consultate']].map(([k, l]) => (
                <button key={k} onClick={() => setSortBy(k)} style={{
                  height: 32, padding: '0 12px', borderRadius: 6,
                  background: sortBy === k ? 'var(--ig-ink-900)' : 'white',
                  color: sortBy === k ? 'white' : 'var(--ig-ink-700)',
                  border: '1px solid', borderColor: sortBy === k ? 'var(--ig-ink-900)' : 'var(--ig-border)',
                  fontSize: 12, fontWeight: 600, cursor: 'pointer',
                }}>{l}</button>
              ))}
            </div>
          </div>

          {filtered.length === 0 ? (
            <div className="ig-card" style={{ padding: '64px 40px', textAlign: 'center' }}>
              <div style={{ width: 64, height: 64, borderRadius: 16, background: 'var(--ig-blue-50)', color: 'var(--ig-blue-700)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 18px' }}>
                <I.Search size={28}/>
              </div>
              <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 6 }}>Nessuna opportunità trovata</h3>
              <p style={{ fontSize: 14, color: 'var(--ig-ink-500)', marginBottom: 18 }}>Prova a modificare i filtri o invia una richiesta agli operatori dello sportello.</p>
              <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
                <button className="ig-btn ig-btn--primary ig-btn--sm" onClick={reset}>Azzera filtri</button>
                <Link to="/ticket"><button className="ig-btn ig-btn--secondary ig-btn--sm">Invia richiesta</button></Link>
              </div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {filtered.map(s => <SchedaCard key={s.id} scheda={s} layout="list"/>)}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function FilterChip({ label, onRemove }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, height: 28, padding: '0 10px', borderRadius: 6, background: 'var(--ig-blue-100)', color: 'var(--ig-blue-800)', fontSize: 13, fontWeight: 600 }}>
      {label}
      <button onClick={onRemove} style={{ background: 'none', border: 'none', padding: 2, color: 'var(--ig-blue-800)', cursor: 'pointer', display: 'inline-flex' }}><I.X size={12}/></button>
    </span>
  );
}

function FilterGroup({ title, options, selected, onToggle }) {
  const [open, setOpen] = useState(true);
  return (
    <div style={{ padding: '18px 0', borderBottom: '1px solid var(--ig-border-soft)' }}>
      <button onClick={() => setOpen(!open)} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%', background: 'none', border: 'none', cursor: 'pointer', padding: 0, marginBottom: open ? 12 : 0 }}>
        <h4 style={{ fontSize: 13, fontWeight: 700, color: 'var(--ig-ink-900)' }}>{title}</h4>
        {open ? <I.ChevU size={14} color="var(--ig-ink-500)"/> : <I.ChevD size={14} color="var(--ig-ink-500)"/>}
      </button>
      {open && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {options.map(([value, label, count]) => {
            const checked = selected.includes(value);
            return (
              <label key={value} style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', fontSize: 13 }}>
                <span style={{
                  width: 17, height: 17, borderRadius: 4,
                  border: checked ? 'none' : '1.5px solid var(--ig-ink-300)',
                  background: checked ? 'var(--ig-primary)' : 'white',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', flex: '0 0 auto',
                }}>
                  {checked && <I.Check size={11} color="white" strokeWidth={3}/>}
                </span>
                <input type="checkbox" checked={checked} onChange={() => onToggle(value)} style={{ display: 'none' }}/>
                <span style={{ color: checked ? 'var(--ig-ink-900)' : 'var(--ig-ink-700)', fontWeight: checked ? 600 : 500, flex: 1 }}>{label}</span>
                {count !== undefined && <span style={{ fontSize: 12, color: 'var(--ig-ink-400)', fontFamily: 'var(--ig-font-mono)' }}>{count}</span>}
              </label>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ============================================================
// SCHEDA DETAIL · interactive (save, share, related)
// ============================================================
function PublicDetail({ route }) {
  const id = route.parts[1];
  const [storeState, dispatch] = useStore();
  const toast = useToast();
  const { open, close } = useModal();
  const scheda = getScheda(id, storeState);

  if (!scheda) {
    return (
      <div className="ig" style={{ padding: 80, textAlign: 'center', background: 'var(--ig-bg)' }}>
        <h2>Scheda non trovata</h2>
        <Link to="/opportunita"><button className="ig-btn ig-btn--primary" style={{ marginTop: 14 }}>Torna alle opportunità</button></Link>
      </div>
    );
  }

  const saved = storeState.saved.has(scheda.id);

  const handleSave = () => {
    dispatch({ type: 'TOGGLE_SAVED', id: scheda.id });
    toast.success(saved ? 'Rimossa dai preferiti' : 'Opportunità salvata', !saved ? 'Trovi questa scheda nella tua area personale.' : null);
  };

  const handleShare = () => {
    open({
      title: 'Condividi opportunità',
      icon: <I.Share size={20}/>,
      content: (
        <div>
          <p style={{ fontSize: 14, color: 'var(--ig-ink-700)', marginBottom: 14, lineHeight: 1.5 }}>Copia il link diretto a questa scheda informativa:</p>
          <div style={{ display: 'flex', gap: 8 }}>
            <input className="ig-input" readOnly value={`informagiovani.enna.it/scheda/${scheda.id}`} style={{ fontFamily: 'var(--ig-font-mono)', fontSize: 13 }}/>
            <button className="ig-btn ig-btn--primary" onClick={() => { toast.success('Link copiato negli appunti'); close(); }}>Copia</button>
          </div>
          <div style={{ marginTop: 18, display: 'flex', gap: 8 }}>
            <button className="ig-btn ig-btn--secondary ig-btn--sm" onClick={() => { toast.info('Apertura email…'); close(); }}><I.Mail size={14}/> Via email</button>
            <button className="ig-btn ig-btn--secondary ig-btn--sm" onClick={() => { toast.info('Condivisione WhatsApp…'); close(); }}><I.Send size={14}/> WhatsApp</button>
          </div>
        </div>
      ),
    });
  };

  const handlePrint = () => {
    open({
      title: 'Anteprima stampa',
      subtitle: scheda.title,
      icon: <I.Print size={20}/>,
      width: 640,
      content: (
        <div style={{ padding: 14, border: '1px solid var(--ig-border)', background: 'var(--ig-ink-50)', borderRadius: 8, fontSize: 13, lineHeight: 1.6 }}>
          <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6 }}>{scheda.areaLabel} · {scheda.type}</div>
          <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 8 }}>{scheda.title}</div>
          <p style={{ color: 'var(--ig-ink-700)' }}>{scheda.short}</p>
          <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid var(--ig-border-soft)', fontSize: 12, color: 'var(--ig-ink-500)' }}>
            Scadenza: {scheda.deadlineLabel} · Fonte: {scheda.source} · Aggiornata {scheda.updated}
          </div>
        </div>
      ),
      actions: <>
        <button className="ig-btn ig-btn--ghost" onClick={close}>Annulla</button>
        <button className="ig-btn ig-btn--primary" onClick={() => { toast.success('Inviato alla stampante'); close(); }}><I.Print size={14}/> Stampa</button>
      </>,
    });
  };

  const isExpired = scheda.daysLeft !== null && scheda.daysLeft !== undefined && scheda.daysLeft <= 0;

  return (
    <div className="ig" style={{ background: 'var(--ig-bg)' }}>
      {/* Breadcrumb */}
      <div style={{ background: 'white', borderBottom: '1px solid var(--ig-border-soft)' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '16px 32px' }}>
          <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', display: 'flex', alignItems: 'center', gap: 6 }}>
            <Link to="/" style={{ color: 'var(--ig-ink-500)' }}>Home</Link>
            <I.ChevR size={12}/>
            <Link to="/opportunita" style={{ color: 'var(--ig-ink-500)' }}>Opportunità</Link>
            <I.ChevR size={12}/>
            <Link to={`/opportunita?area=${scheda.area}`} style={{ color: 'var(--ig-ink-500)' }}>{scheda.areaLabel}</Link>
            <I.ChevR size={12}/>
            <span style={{ color: 'var(--ig-ink-900)', fontWeight: 600 }}>{scheda.title.slice(0, 50)}…</span>
          </div>
        </div>
      </div>

      {/* Header */}
      <div style={{ background: 'white', borderBottom: '1px solid var(--ig-border-soft)' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '30px 32px 24px', display: 'grid', gridTemplateColumns: '1fr 340px', gap: 48 }}>
          <div>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 16 }}>
              <span className={`ig-badge ig-badge--${scheda.area}`}>{scheda.areaLabel}</span>
              <span className="ig-badge ig-badge--src-ufficiale"><I.ShieldChk size={12}/>Fonte ufficiale</span>
              <span className="ig-badge" style={{ background: 'var(--ig-ink-75)', color: 'var(--ig-ink-700)' }}>{scheda.type}</span>
              <span className="ig-badge" style={{ background: 'var(--ig-ink-75)', color: 'var(--ig-ink-700)' }}>{scheda.target.join(' · ')}</span>
            </div>
            <h1 style={{ fontSize: 34, fontWeight: 800, letterSpacing: '-0.025em', lineHeight: 1.1, color: 'var(--ig-ink-900)', marginBottom: 14, textWrap: 'balance' }}>{scheda.title}</h1>
            <p style={{ fontSize: 17, color: 'var(--ig-ink-500)', lineHeight: 1.55, maxWidth: 760 }}>{scheda.short}</p>
            <div style={{ display: 'flex', gap: 18, marginTop: 18, fontSize: 13, color: 'var(--ig-ink-500)', alignItems: 'center', flexWrap: 'wrap' }}>
              <span><I.Eye size={14} style={{ display: 'inline', verticalAlign: '-2px', marginRight: 4 }}/> {scheda.views} visualizzazioni</span>
              <span>·</span>
              <span><I.Bookmark size={14} style={{ display: 'inline', verticalAlign: '-2px', marginRight: 4 }}/> {scheda.saves} salvataggi</span>
              <span>·</span>
              <span>Aggiornata {scheda.updated} da <strong style={{ color: 'var(--ig-ink-700)', fontWeight: 600 }}>{scheda.updatedBy}</strong></span>
            </div>
          </div>

          {/* Sidebar countdown */}
          {scheda.urg === 'ok' ? (
            <div style={{ background: 'var(--ig-green-50)', border: '2px solid var(--ig-green-100)', borderRadius: 14, padding: 22 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-green-700)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>Sempre aperta</div>
              <div style={{ fontSize: 20, fontWeight: 700, color: 'var(--ig-green-700)', marginBottom: 12 }}>{scheda.deadlineLabel}</div>
              <button className="ig-btn ig-btn--primary" style={{ width: '100%', justifyContent: 'center', marginBottom: 8 }} onClick={() => toast.info('Apertura bando ufficiale…', scheda.sourceUrl)}>
                <I.Send size={16}/> Vai al bando
              </button>
              <DetailActions scheda={scheda} saved={saved} onSave={handleSave} onShare={handleShare} onPrint={handlePrint}/>
            </div>
          ) : (
            <div style={{ background: scheda.urg === 'urgent' ? 'var(--ig-red-50)' : 'var(--ig-amber-50)', border: `2px solid ${scheda.urg === 'urgent' ? 'var(--ig-red-100)' : 'var(--ig-amber-100)'}`, borderRadius: 14, padding: 22 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: scheda.urg === 'urgent' ? 'var(--ig-red-700)' : 'var(--ig-amber-800)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4, display: 'flex', alignItems: 'center', gap: 5 }}>
                <I.Alert size={12}/> {scheda.urg === 'urgent' ? 'Scadenza imminente' : 'In scadenza'}
              </div>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 4 }}>
                <span className="ig-num" style={{ fontSize: 48, fontWeight: 800, color: scheda.urg === 'urgent' ? 'var(--ig-red-700)' : 'var(--ig-amber-800)', letterSpacing: '-0.03em', lineHeight: 1 }}>{scheda.daysLeft}</span>
                <span style={{ fontSize: 16, fontWeight: 600, color: scheda.urg === 'urgent' ? 'var(--ig-red-700)' : 'var(--ig-amber-800)' }}>giorni</span>
              </div>
              <div style={{ fontSize: 13, color: 'var(--ig-ink-700)', marginBottom: 14 }}>Termine: <strong>{scheda.deadlineLabel}</strong></div>
              <button className="ig-btn ig-btn--primary" style={{ width: '100%', justifyContent: 'center', marginBottom: 8 }} onClick={() => toast.info('Apertura bando ufficiale…', scheda.sourceUrl)}>
                <I.Send size={16}/> Vai al bando ufficiale
              </button>
              <DetailActions scheda={scheda} saved={saved} onSave={handleSave} onShare={handleShare} onPrint={handlePrint}/>
            </div>
          )}
        </div>
      </div>

      {/* Body */}
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '36px 32px 60px', display: 'grid', gridTemplateColumns: '1fr 340px', gap: 48 }}>
        <div>
          {isExpired && (
            <div style={{ background: 'var(--ig-amber-50)', border: '1px solid var(--ig-amber-100)', borderRadius: 12, padding: 18, marginBottom: 28, display: 'flex', alignItems: 'flex-start', gap: 14 }}>
              <I.Alert size={20} color="var(--ig-amber-700)"/>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--ig-amber-800)' }}>Questa opportunità risulta scaduta</div>
                <div style={{ fontSize: 13, color: 'var(--ig-ink-700)', marginTop: 4 }}>Puoi consultarla come archivio o cercare opportunità simili.</div>
              </div>
              <Link to={`/opportunita?area=${scheda.area}`}><button className="ig-btn ig-btn--primary ig-btn--sm">Cerca simili</button></Link>
            </div>
          )}

          {scheda.sections?.cosaOffre && (
            <Block num="01" title="Cosa offre">
              <p style={{ marginBottom: 14 }}>{scheda.sections.cosaOffre}</p>
              {scheda.contributo && (
                <div style={{ background: 'var(--ig-blue-50)', border: '1px solid var(--ig-blue-100)', borderRadius: 12, padding: 20, marginTop: 8, display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 22 }}>
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Contributo</div>
                    <div className="ig-num" style={{ fontSize: 24, fontWeight: 800, color: 'var(--ig-blue-700)', letterSpacing: '-0.02em', margin: '4px 0' }}>{scheda.contributo}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Durata</div>
                    <div className="ig-num" style={{ fontSize: 24, fontWeight: 800, color: 'var(--ig-blue-700)', letterSpacing: '-0.02em', margin: '4px 0' }}>{scheda.durata}</div>
                  </div>
                </div>
              )}
            </Block>
          )}

          {scheda.sections?.aChiRivolto && (
            <Block num="02" title="A chi è rivolto">
              <ul style={{ paddingLeft: 20, lineHeight: 1.7 }}>
                {scheda.sections.aChiRivolto.map((it, i) => <li key={i}>{it}</li>)}
              </ul>
            </Block>
          )}

          {scheda.sections?.requisiti && (
            <Block num="03" title="Requisiti">
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                {scheda.sections.requisiti.map(([k, v]) => (
                  <div key={k} style={{ display: 'flex', gap: 12, alignItems: 'flex-start', padding: 12, background: 'var(--ig-ink-50)', borderRadius: 8 }}>
                    <I.Check size={16} color="var(--ig-green-600)" strokeWidth={2.4}/>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ig-ink-900)' }}>{k}</div>
                      <div style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginTop: 2 }}>{v}</div>
                    </div>
                  </div>
                ))}
              </div>
            </Block>
          )}

          {/* Source verification */}
          <div style={{ marginTop: 28, background: 'var(--ig-green-50)', border: '1px solid var(--ig-green-100)', borderRadius: 14, padding: 24 }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14 }}>
              <div style={{ width: 40, height: 40, borderRadius: 10, background: 'var(--ig-green-600)', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', flex: '0 0 auto' }}>
                <I.ShieldChk size={20}/>
              </div>
              <div>
                <h3 style={{ fontSize: 16, fontWeight: 700, color: 'var(--ig-ink-900)', marginBottom: 4 }}>Le informazioni sono state verificate dagli operatori del servizio.</h3>
                <p style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>Fonte: {scheda.source} · <a href="#" onClick={(e) => { e.preventDefault(); toast.info('Apertura URL fonte…', scheda.sourceUrl); }}>{scheda.sourceUrl}</a></p>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <aside>
          <div className="ig-card" style={{ padding: '4px 22px' }}>
            <div style={{ padding: '16px 0 10px', borderBottom: '1px solid var(--ig-border-soft)' }}>
              <h3 style={{ fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)' }}>Riepilogo</h3>
            </div>
            <SideRow label="Scadenza" value={scheda.deadlineLabel} accent={scheda.urg === 'urgent' ? 'var(--ig-red-700)' : null}/>
            <SideRow label="Territorio" value={scheda.territory}/>
            <SideRow label="Destinatari" value={scheda.target.join(', ')}/>
            <SideRow label="Tipologia" value={scheda.type}/>
            <SideRow label="Fonte" value={scheda.source}/>
            <div style={{ padding: '16px 0' }}>
              <Link to={`/prenota?ref=${scheda.id}`}>
                <button className="ig-btn ig-btn--accent" style={{ width: '100%', justifyContent: 'center', marginBottom: 8 }}>
                  <I.Calendar size={16}/> Prenota un colloquio
                </button>
              </Link>
              <Link to={`/ticket?ref=${scheda.id}`}>
                <button className="ig-btn ig-btn--secondary" style={{ width: '100%', justifyContent: 'center' }}>
                  <I.Chat size={16}/> Chiedi informazioni
                </button>
              </Link>
            </div>
          </div>
        </aside>
      </div>

      {/* Related */}
      <section style={{ background: 'white', padding: '48px 0', borderTop: '1px solid var(--ig-border-soft)' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 32px' }}>
          <h2 style={{ fontSize: 24, fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 20 }}>Opportunità correlate</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 18 }}>
            {SCHEDE.filter(s => s.id !== scheda.id && s.area === scheda.area).slice(0, 3).map(s => (
              <Link key={s.id} to={`/scheda/${s.id}`} className="ig-card" style={{ padding: 18, textDecoration: 'none', color: 'inherit' }}>
                <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
                  <span className={`ig-badge ig-badge--${s.area}`}>{s.areaLabel}</span>
                  {s.daysLeft && <span className={`ig-badge ig-badge--scad-${s.urg}`}><I.Clock size={11}/>{s.daysLeft}g</span>}
                </div>
                <h3 style={{ fontSize: 15, fontWeight: 700, lineHeight: 1.3, color: 'var(--ig-ink-900)', marginBottom: 6 }}>{s.title}</h3>
                <p style={{ fontSize: 13, color: 'var(--ig-ink-500)', lineHeight: 1.5 }}>{s.short.slice(0, 120)}…</p>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

function DetailActions({ scheda, saved, onSave, onShare, onPrint }) {
  return (
    <div style={{ display: 'flex', gap: 6 }}>
      <button className={saved ? 'ig-btn ig-btn--secondary ig-btn--sm' : 'ig-btn ig-btn--secondary ig-btn--sm'} style={{ flex: 1, justifyContent: 'center', background: saved ? 'var(--ig-amber-100)' : 'white', borderColor: saved ? 'var(--ig-amber-500)' : 'var(--ig-border)' }} onClick={onSave}>
        {saved ? <I.BookmarkF size={14} color="var(--ig-amber-700)"/> : <I.Bookmark size={14}/>} {saved ? 'Salvata' : 'Salva'}
      </button>
      <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ flex: 1, justifyContent: 'center' }} onClick={onShare}><I.Share size={14}/> Condividi</button>
      <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ flex: 1, justifyContent: 'center' }} onClick={onPrint}><I.Print size={14}/> Stampa</button>
    </div>
  );
}

function Block({ num, title, children }) {
  return (
    <div style={{ marginBottom: 28 }}>
      <h3 style={{ fontSize: 19, fontWeight: 700, color: 'var(--ig-ink-900)', display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
        <span style={{ width: 30, height: 30, borderRadius: 8, background: 'var(--ig-blue-50)', color: 'var(--ig-blue-700)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 800, fontFamily: 'var(--ig-font-mono)' }}>{num}</span>
        {title}
      </h3>
      <div style={{ paddingLeft: 42, color: 'var(--ig-ink-700)', fontSize: 14, lineHeight: 1.6 }}>{children}</div>
    </div>
  );
}

function SideRow({ label, value, accent }) {
  return (
    <div style={{ padding: '14px 0', borderBottom: '1px solid var(--ig-border-soft)' }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 14, fontWeight: 600, color: accent || 'var(--ig-ink-900)' }}>{value}</div>
    </div>
  );
}

window.PROTO_LIST = PublicList;
window.PROTO_DETAIL = PublicDetail;

})();
