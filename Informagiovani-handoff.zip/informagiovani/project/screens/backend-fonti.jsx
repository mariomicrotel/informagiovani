/* global React, IGIcons, BackendShell, PageHeader */
const I = IGIcons;

const fontiRows = [
  ['INDIRE Erasmus+', 'erasmusplus.indire.it', 'Agenzia Nazionale INDIRE', 'Europa', 'Portale ufficiale', 'ufficiale', 'settimanale', '2 giorni fa', 'tra 5 giorni', 'M. Greco', 'ok', 'Aggiornata', 47],
  ['Invitalia · Resto al Sud', 'invitalia.it/sostegno', 'Invitalia S.p.A.', 'Italia', 'Portale ufficiale', 'ufficiale', 'mensile', '3 giorni fa', 'tra 27 giorni', 'F. Bellomo', 'ok', 'Aggiornata', 12],
  ['Regione Siciliana · Politiche Giovanili', 'regione.sicilia.it/giovani', 'Regione Siciliana', 'Sicilia', 'Portale ufficiale', 'ufficiale', 'settimanale', '6 giorni fa', 'oggi', 'P. Rizzo', 'check', 'Da controllare', 28],
  ['Comune di Enna · Bandi', 'comune.enna.it/bandi', 'Comune di Enna', 'Enna città', 'Albo pretorio', 'ufficiale', 'giornaliera', '12 ore fa', 'oggi', 'L. Marino', 'ok', 'Aggiornata', 56],
  ['Cliclavoro Sicilia', 'cliclavorosicilia.it', 'ANPAL Sicilia', 'Sicilia', 'Portale lavoro', 'ufficiale', 'settimanale', '14 giorni fa', '7 giorni fa', 'P. Rizzo', 'overdue', 'Da controllare', 34],
  ['Dipartimento Politiche Giovanili', 'politichegiovanili.gov.it', 'Presidenza CdM', 'Italia', 'Portale governativo', 'ufficiale', 'mensile', '5 giorni fa', 'tra 25 giorni', 'M. Greco', 'ok', 'Aggiornata', 19],
  ['Eures · Lavoro in Europa', 'eures.europa.eu', 'Commissione Europea', 'Europa', 'Portale lavoro UE', 'ufficiale', 'settimanale', '8 giorni fa', 'tra 1 giorno', 'M. Greco', 'check', 'Da controllare', 22],
  ['Garanzia Giovani Sicilia', 'garanziagiovanisicilia.it', 'Regione Siciliana', 'Sicilia', 'Portale dedicato', 'ufficiale', 'settimanale', '4 giorni fa', 'tra 3 giorni', 'P. Rizzo', 'ok', 'Aggiornata', 18],
  ['Fondazione ITS Steve Jobs', 'itsstevejobs.org', 'Fondazione ITS', 'Sicilia', 'Sito istituzionale', 'partner', 'quindicinale', '22 giorni fa', '7 giorni fa', 'L. Marino', 'overdue', 'Da controllare', 6],
  ['Camera di Commercio Enna', 'cc-enna.it', 'CCIAA Enna', 'Enna città', 'Sito istituzionale', 'partner', 'mensile', '32 giorni fa', '2 giorni fa', 'F. Bellomo', 'overdue', 'Non aggiornata', 11],
  ['Centro per l\u2019Impiego Enna', 'cpi-enna.it/offerte', 'ANPAL', 'Enna città', 'Portale offerte', 'ufficiale', 'giornaliera', '8 ore fa', 'oggi', 'P. Rizzo', 'ok', 'Aggiornata', 89],
  ['Erasmusintern.org', 'erasmusintern.org', 'ESN', 'Europa', 'Database tirocini', 'verificata', 'settimanale', 'mai · errore 404', '—', 'M. Greco', 'error', 'Non raggiungibile', 0],
];

function HealthDot({ status }) {
  const map = {
    ok:      { color: 'var(--ig-green-600)', label: 'Aggiornata' },
    check:   { color: 'var(--ig-amber-600)', label: 'Da controllare' },
    overdue: { color: 'var(--ig-amber-700)', label: 'In ritardo' },
    error:   { color: 'var(--ig-red-600)',   label: 'Non raggiungibile' },
  };
  const s = map[status];
  return (
    <span style={{
      position: 'relative', width: 10, height: 10, display: 'inline-block',
    }}>
      <span style={{ position: 'absolute', inset: 0, borderRadius: '50%', background: s.color }}/>
      {(status === 'check' || status === 'error') && (
        <span style={{ position: 'absolute', inset: -3, borderRadius: '50%', background: s.color, opacity: 0.25, animation: 'pulse 2s ease-out infinite' }}/>
      )}
    </span>
  );
}

function BackendFontiScreen() {
  return (
    <BackendShell active="Fonti" breadcrumb={['Console', 'Contenuti', 'Fonti']} height={1480}>
      <PageHeader
        title="Fonti informative"
        subtitle="76 fonti monitorate · 8 da controllare · 2 non raggiungibili · 4 partner accreditati"
        actions={<>
          <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Download size={14}/> Esporta</button>
          <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Sparkle size={14}/> Verifica tutte</button>
          <button className="ig-btn ig-btn--primary ig-btn--sm"><I.Plus size={14}/> Nuova fonte</button>
        </>}
      />

      {/* Stats strip */}
      <div style={{ padding: '24px 32px 0' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
          {[
            ['Aggiornate', '64', 'var(--ig-green-600)', '84% sul totale'],
            ['Da controllare', '8', 'var(--ig-amber-600)', 'soglia: 14 giorni'],
            ['In ritardo', '3', 'var(--ig-amber-700)', 'oltre 30 giorni'],
            ['Non raggiungibili', '2', 'var(--ig-red-600)', 'verifica URL urgente'],
          ].map(([l, v, c, h]) => (
            <div key={l} className="ig-card" style={{ padding: 20, borderLeft: `4px solid ${c}` }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
                <HealthDot status={l === 'Aggiornate' ? 'ok' : l === 'Da controllare' ? 'check' : l === 'In ritardo' ? 'overdue' : 'error'}/>
                <span style={{ fontSize: 13, color: 'var(--ig-ink-500)', fontWeight: 600 }}>{l}</span>
              </div>
              <div className="ig-num" style={{ fontSize: 32, fontWeight: 800, color: 'var(--ig-ink-900)', letterSpacing: '-0.02em', lineHeight: 1.05, marginBottom: 4 }}>{v}</div>
              <div style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}>{h}</div>
            </div>
          ))}
        </div>
      </div>

      {/* TABLE */}
      <div style={{ padding: '0 32px 32px' }}>
        <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
          {/* head */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '20px 1fr 130px 140px 110px 130px 130px 140px 110px 80px',
            gap: 14, padding: '12px 18px',
            background: 'var(--ig-ink-50)', borderBottom: '1px solid var(--ig-border-soft)',
            fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.05em',
          }}>
            <span></span>
            <span>Nome fonte</span>
            <span>Ente proprietario</span>
            <span>Ambito</span>
            <span>Affidabilità</span>
            <span>Frequenza</span>
            <span>Ultimo controllo</span>
            <span>Prossimo</span>
            <span>Responsabile</span>
            <span style={{ textAlign: 'right' }}>Azioni</span>
          </div>

          {fontiRows.map((r, i) => (
            <div key={r[0]} style={{
              display: 'grid',
              gridTemplateColumns: '20px 1fr 130px 140px 110px 130px 130px 140px 110px 80px',
              gap: 14, padding: '16px 18px',
              borderBottom: i < fontiRows.length - 1 ? '1px solid var(--ig-border-soft)' : 'none',
              alignItems: 'center',
            }}>
              <HealthDot status={r[10]}/>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-900)' }}>{r[0]}</div>
                <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', display: 'flex', alignItems: 'center', gap: 4, marginTop: 2 }}>
                  <I.Link size={11}/>{r[1]} · <span style={{ fontWeight: 600, color: r[12] > 0 ? 'var(--ig-blue-700)' : 'var(--ig-ink-400)' }}>{r[12]} schede</span>
                </div>
              </div>
              <span style={{ fontSize: 12, color: 'var(--ig-ink-700)' }}>{r[2]}</span>
              <span style={{ fontSize: 12, color: 'var(--ig-ink-700)' }}>{r[3]} · {r[4]}</span>
              <span className={`ig-badge ig-badge--src-${r[5]}`} style={{ height: 22, fontSize: 11 }}>
                {r[5] === 'ufficiale' && <I.ShieldChk size={11}/>}
                {r[5] === 'partner' && <I.Shield size={11}/>}
                {r[5] === 'verificata' && <I.Check size={11}/>}
                {r[5] === 'ufficiale' ? 'Ufficiale' : r[5] === 'partner' ? 'Partner' : 'Verificata'}
              </span>
              <span style={{ fontSize: 12, color: 'var(--ig-ink-700)', textTransform: 'capitalize' }}>{r[6]}</span>
              <span style={{ fontSize: 12, color: r[10] === 'error' ? 'var(--ig-red-700)' : r[10] === 'overdue' ? 'var(--ig-amber-800)' : 'var(--ig-ink-700)', fontWeight: r[10] !== 'ok' ? 600 : 400 }}>{r[7]}</span>
              <span style={{ fontSize: 12, fontWeight: 600, color: r[8] === 'oggi' ? 'var(--ig-amber-800)' : r[8].startsWith('-') ? 'var(--ig-red-700)' : 'var(--ig-ink-700)' }}>{r[8]}</span>
              <span style={{ fontSize: 12, color: 'var(--ig-ink-700)' }}>{r[9]}</span>
              <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                <button className="ig-btn ig-btn--ghost ig-btn--sm ig-btn--icon" style={{ width: 28, height: 28 }} title="Apri URL"><I.Link size={14}/></button>
                <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 28, padding: '0 10px', fontSize: 12 }}>Controllo OK</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </BackendShell>
  );
}

window.BackendFontiScreen = BackendFontiScreen;
