/* global React, IGIcons */
const I = IGIcons;

// ============================================================
// Shared backend chrome — sidebar + topbar + page header.
// Each new screen wraps its content with <BackendShell active="Schede informative" breadcrumb={...}>
// ============================================================

function ShellNavItem({ icon, label, active, badge }) {
  return (
    <a href="#" style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '9px 12px', borderRadius: 6,
      fontSize: 14, fontWeight: 600,
      color: active ? 'white' : 'rgba(255,255,255,0.7)',
      background: active ? 'rgba(255,255,255,0.12)' : 'transparent',
      borderLeft: active ? '3px solid var(--ig-amber-500)' : '3px solid transparent',
      marginLeft: -3,
      textDecoration: 'none',
    }}>
      <span style={{ color: active ? 'var(--ig-amber-500)' : 'rgba(255,255,255,0.45)' }}>{icon}</span>
      <span style={{ flex: 1 }}>{label}</span>
      {badge && (
        <span style={{
          background: 'var(--ig-amber-500)', color: 'var(--ig-blue-900)',
          fontSize: 11, fontWeight: 800,
          padding: '2px 7px', borderRadius: 999, minWidth: 22, textAlign: 'center',
        }}>{badge}</span>
      )}
    </a>
  );
}
function ShellNavGroup({ title, children }) {
  return (
    <div style={{ marginBottom: 22 }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', letterSpacing: '0.1em', padding: '0 12px 10px' }}>{title}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>{children}</div>
    </div>
  );
}

function BackendSidebar({ active, height }) {
  return (
    <aside style={{
      width: 256, background: 'var(--ig-blue-900)', color: 'white',
      flex: '0 0 auto', display: 'flex', flexDirection: 'column',
      height: height,
    }}>
      <div style={{ padding: '22px 18px', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 38, height: 38, borderRadius: 8, background: 'var(--ig-amber-500)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="22" height="22" viewBox="0 0 28 28" fill="none">
              <path d="M4 22 L14 4 L24 22 Z" stroke="var(--ig-blue-900)" strokeWidth="2.4" strokeLinejoin="round"/>
              <circle cx="14" cy="15" r="2.4" fill="var(--ig-blue-900)"/>
            </svg>
          </div>
          <div style={{ lineHeight: 1.1 }}>
            <div style={{ fontSize: 14, fontWeight: 800, color: 'white' }}>Informagiovani</div>
            <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)', marginTop: 3 }}>Console operatori · Enna</div>
          </div>
        </div>
      </div>

      <nav style={{ flex: 1, padding: '20px 10px', overflowY: 'auto' }}>
        <ShellNavGroup title="Panoramica">
          <ShellNavItem icon={<I.Home size={18}/>} label="Dashboard" active={active==='Dashboard'}/>
          <ShellNavItem icon={<I.Chart size={18}/>} label="Report" active={active==='Report'}/>
          <ShellNavItem icon={<I.Sparkle size={18}/>} label="Audit log" active={active==='Audit log'}/>
        </ShellNavGroup>
        <ShellNavGroup title="Contenuti">
          <ShellNavItem icon={<I.Doc size={18}/>} label="Schede informative" active={active==='Schede informative'} badge="12"/>
          <ShellNavItem icon={<I.Link size={18}/>} label="Fonti" active={active==='Fonti'} badge="4"/>
          <ShellNavItem icon={<I.Calendar size={18}/>} label="Eventi" active={active==='Eventi'}/>
          <ShellNavItem icon={<I.Send size={18}/>} label="Newsletter" active={active==='Newsletter'}/>
        </ShellNavGroup>
        <ShellNavGroup title="Sportello">
          <ShellNavItem icon={<I.Users size={18}/>} label="Utenti giovani" active={active==='Utenti giovani'}/>
          <ShellNavItem icon={<I.Chat size={18}/>} label="Colloqui" active={active==='Colloqui'}/>
          <ShellNavItem icon={<I.Calendar size={18}/>} label="Appuntamenti" active={active==='Appuntamenti'} badge="8"/>
          <ShellNavItem icon={<I.Flag size={18}/>} label="Ticket / Richieste" active={active==='Ticket'} badge="23"/>
          <ShellNavItem icon={<I.Bulb size={18}/>} label="Percorsi impresa" active={active==='Percorsi impresa'}/>
        </ShellNavGroup>
        <ShellNavGroup title="Ecosistema">
          <ShellNavItem icon={<I.Building size={18}/>} label="Partner" active={active==='Partner'}/>
          <ShellNavItem icon={<I.Download size={18}/>} label="Import / Export"/>
          <ShellNavItem icon={<I.Settings size={18}/>} label="Impostazioni"/>
        </ShellNavGroup>
      </nav>

      <div style={{ padding: 14, borderTop: '1px solid rgba(255,255,255,0.08)', display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'var(--ig-teal-600)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 13, color: 'white' }}>GF</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: 'white' }}>Giulia Fontana</div>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.55)' }}>Responsabile servizio</div>
        </div>
        <I.ChevR size={14} color="rgba(255,255,255,0.5)"/>
      </div>
    </aside>
  );
}

function BackendTopbar({ breadcrumb }) {
  return (
    <div style={{ background: 'white', borderBottom: '1px solid var(--ig-border-soft)', padding: '14px 32px', display: 'flex', alignItems: 'center', gap: 20 }}>
      <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0 }}>
        {breadcrumb && breadcrumb.map((b, i) => (
          <React.Fragment key={i}>
            {i > 0 && <I.ChevR size={12}/>}
            <span style={{ color: i === breadcrumb.length - 1 ? 'var(--ig-ink-900)' : 'var(--ig-ink-500)', fontWeight: i === breadcrumb.length - 1 ? 600 : 400 }}>{b}</span>
          </React.Fragment>
        ))}
      </div>
      <div style={{ flex: 1, maxWidth: 520, position: 'relative' }}>
        <input
          className="ig-input"
          placeholder="Cerca schede, utenti, fonti, ticket, eventi… (Ctrl K)"
          style={{ paddingLeft: 40, height: 38, fontSize: 14 }}
        />
        <div style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }}>
          <I.Search size={16} color="var(--ig-ink-400)"/>
        </div>
      </div>
      <div style={{ display: 'flex', gap: 4, alignItems: 'center', marginLeft: 'auto' }}>
        <button className="ig-btn ig-btn--ghost ig-btn--icon" style={{ width: 38, height: 38, position: 'relative' }}>
          <I.Bell size={18}/>
          <span style={{ position: 'absolute', top: 7, right: 7, width: 8, height: 8, background: 'var(--ig-red-600)', borderRadius: '50%', border: '2px solid white' }}/>
        </button>
        <button className="ig-btn ig-btn--ghost ig-btn--icon" style={{ width: 38, height: 38 }}><I.Mail size={18}/></button>
        <div style={{ width: 1, height: 24, background: 'var(--ig-border-soft)', margin: '0 8px' }}/>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 34, height: 34, borderRadius: '50%', background: 'var(--ig-teal-600)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 13, color: 'white' }}>GF</div>
          <I.ChevD size={14} color="var(--ig-ink-500)"/>
        </div>
      </div>
    </div>
  );
}

function BackendShell({ active, breadcrumb, height = 1500, children }) {
  return (
    <div className="ig" style={{ width: 1440, background: 'var(--ig-bg)', minHeight: height, display: 'flex' }}>
      <BackendSidebar active={active} height={height}/>
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        <BackendTopbar breadcrumb={breadcrumb}/>
        {children}
      </div>
    </div>
  );
}

// ============================================================
// Page header used inside the shell
// ============================================================
function PageHeader({ title, subtitle, actions, tabs, activeTab }) {
  return (
    <div style={{ padding: '24px 32px 0', background: 'white', borderBottom: '1px solid var(--ig-border-soft)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: tabs ? 22 : 24 }}>
        <div>
          <h1 style={{ fontSize: 26, fontWeight: 700, letterSpacing: '-0.02em', color: 'var(--ig-ink-900)' }}>{title}</h1>
          {subtitle && <p style={{ fontSize: 14, color: 'var(--ig-ink-500)', marginTop: 6 }}>{subtitle}</p>}
        </div>
        {actions && <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>{actions}</div>}
      </div>
      {tabs && (
        <div style={{ display: 'flex', gap: 4 }}>
          {tabs.map((t) => (
            <a key={t} href="#" style={{
              padding: '12px 14px',
              fontSize: 14, fontWeight: 600,
              color: t === activeTab ? 'var(--ig-blue-700)' : 'var(--ig-ink-700)',
              borderBottom: t === activeTab ? '2px solid var(--ig-blue-700)' : '2px solid transparent',
              marginBottom: -1,
              textDecoration: 'none',
            }}>{t}</a>
          ))}
        </div>
      )}
    </div>
  );
}

window.BackendShell = BackendShell;
window.PageHeader = PageHeader;
