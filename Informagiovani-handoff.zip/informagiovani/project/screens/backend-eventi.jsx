/* global React, IGIcons, BackendShell, PageHeader */
const I = IGIcons;

const eventiRows = [
  { d: 18, m: 'MAR', t: 'Open day Erasmus+ a Enna', mode: 'In presenza', place: 'Sala Cerere · Castello di Lombardia', area: 'estero', areaLab: 'Estero', target: '18–30 anni', iscritti: 14, posti: 30, status: 'state-pub', statusLab: 'Aperto', resp: 'M. Greco', avgFeedback: null },
  { d: 22, m: 'MAR', t: 'Workshop: scrivi il tuo curriculum', mode: 'In presenza', place: 'Sportello principale', area: 'lavoro', areaLab: 'Lavoro', target: 'Disoccupati', iscritti: 8, posti: 12, status: 'state-pub', statusLab: 'Aperto', resp: 'P. Rizzo', avgFeedback: null },
  { d: 26, m: 'MAR', t: 'Costruisci la tua idea di impresa', mode: 'Online · Zoom', place: 'meet.io/idea-impresa', area: 'impresa', areaLab: 'Impresa', target: 'Aspiranti imprenditori', iscritti: 32, posti: 50, status: 'state-pub', statusLab: 'Aperto', resp: 'F. Bellomo', avgFeedback: null },
  { d: 3, m: 'APR', t: 'Resto al Sud · come candidarsi', mode: 'In presenza', place: 'Camera di Commercio Enna', area: 'impresa', areaLab: 'Impresa', target: '18–55 anni', iscritti: 28, posti: 30, status: 'state-review', statusLab: 'Posti esauriti', resp: 'F. Bellomo', avgFeedback: null },
  { d: 8, m: 'APR', t: 'Concorsi Comune di Enna · simulazione', mode: 'In presenza', place: 'Sportello principale', area: 'concorso', areaLab: 'Concorsi', target: 'Diplomati', iscritti: 0, posti: 25, status: 'state-draft', statusLab: 'Bozza', resp: 'L. Marino', avgFeedback: null },
  { d: 14, m: 'APR', t: 'Servizio Civile · serata informativa', mode: 'In presenza', place: 'Sala Cerere · Castello di Lombardia', area: 'civile', areaLab: 'Servizio Civile', target: '18–28 anni', iscritti: 5, posti: 80, status: 'state-pub', statusLab: 'Aperto', resp: 'M. Greco', avgFeedback: null },
  // passati
  { d: 6, m: 'MAR', t: 'Career Day Università Kore', mode: 'In presenza', place: 'Università Kore Enna', area: 'lavoro', areaLab: 'Lavoro', target: 'Universitari', iscritti: 142, posti: 150, status: 'state-archive', statusLab: 'Concluso', resp: 'P. Rizzo', avgFeedback: 4.6 },
  { d: 28, m: 'FEB', t: 'Sportello Curriculum · open day', mode: 'In presenza', place: 'Sportello principale', area: 'lavoro', areaLab: 'Lavoro', target: 'Disoccupati', iscritti: 22, posti: 25, status: 'state-archive', statusLab: 'Concluso', resp: 'P. Rizzo', avgFeedback: 4.3 },
];

function CapacityBar({ iscritti, posti, color }) {
  const pct = Math.min(100, (iscritti / posti) * 100);
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, fontWeight: 600, color: 'var(--ig-ink-700)', marginBottom: 4 }}>
        <span className="ig-num">{iscritti} / {posti}</span>
        <span style={{ color: pct >= 90 ? 'var(--ig-red-700)' : pct >= 70 ? 'var(--ig-amber-700)' : 'var(--ig-green-700)' }}>
          {pct >= 90 ? 'Quasi pieno' : pct >= 70 ? 'In riempimento' : 'Disponibile'}
        </span>
      </div>
      <div style={{ height: 4, background: 'var(--ig-ink-150)', borderRadius: 999, overflow: 'hidden' }}>
        <div style={{ width: `${pct}%`, height: '100%', background: color || (pct >= 90 ? 'var(--ig-red-600)' : pct >= 70 ? 'var(--ig-amber-600)' : 'var(--ig-green-600)') }}/>
      </div>
    </div>
  );
}

function BackendEventiScreen() {
  return (
    <BackendShell active="Eventi" breadcrumb={['Console', 'Contenuti', 'Eventi']} height={1500}>
      <PageHeader
        title="Eventi"
        subtitle="14 eventi prossimi · 247 iscritti totali · 4 eventi conclusi questo mese · feedback medio 4.5/5"
        actions={<>
          <div style={{ display: 'flex', border: '1px solid var(--ig-border)', borderRadius: 6, overflow: 'hidden' }}>
            <button style={{ background: 'var(--ig-ink-900)', color: 'white', border: 'none', padding: '8px 14px', cursor: 'pointer', fontSize: 13, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 6 }}><I.List size={14}/> Lista</button>
            <button style={{ background: 'white', border: 'none', padding: '8px 14px', cursor: 'pointer', fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-700)', display: 'flex', alignItems: 'center', gap: 6 }}><I.Calendar size={14}/> Calendario</button>
          </div>
          <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Download size={14}/> Esporta</button>
          <button className="ig-btn ig-btn--primary ig-btn--sm"><I.Plus size={14}/> Nuovo evento</button>
        </>}
        tabs={['Tutti · 22', 'Prossimi · 14', 'In corso · 0', 'Bozze · 3', 'Conclusi · 18']}
        activeTab="Prossimi · 14"
      />

      <div style={{ padding: '24px 32px 32px' }}>
        {/* Stats strip */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 24 }}>
          {[
            ['Iscritti totali', '247', 'questo mese', 'var(--ig-blue-700)'],
            ['Tasso partecipazione', '87%', 'media 30 giorni', 'var(--ig-green-700)'],
            ['Feedback medio', '4.5', '★★★★★ su 5', 'var(--ig-amber-700)'],
            ['Eventi sold-out', '3', 'su 14 prossimi', 'var(--ig-red-700)'],
          ].map(([l, v, h, c]) => (
            <div key={l} className="ig-card" style={{ padding: 18 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--ig-ink-500)' }}>{l}</div>
              <div className="ig-num" style={{ fontSize: 32, fontWeight: 800, color: c, letterSpacing: '-0.02em', lineHeight: 1.1, margin: '6px 0' }}>{v}</div>
              <div style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}>{h}</div>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 18 }}>
          <div style={{ flex: 1, maxWidth: 320, position: 'relative' }}>
            <input className="ig-input" placeholder="Cerca per titolo, sede, relatore…" style={{ height: 38, paddingLeft: 38, fontSize: 14 }}/>
            <div style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)' }}>
              <I.Search size={16} color="var(--ig-ink-400)"/>
            </div>
          </div>
          <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 38 }}>Area: Tutte <I.ChevD size={14}/></button>
          <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 38 }}>Modalità: Tutte <I.ChevD size={14}/></button>
          <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 38 }}>Mese: Marzo 2026 <I.ChevD size={14}/></button>
          <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 38 }}>Responsabile: Tutti <I.ChevD size={14}/></button>
        </div>

        {/* Cards */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {eventiRows.map((e, i) => (
            <div key={i} className="ig-card" style={{ padding: 20, display: 'grid', gridTemplateColumns: '76px 1fr 220px 180px 110px', gap: 24, alignItems: 'center' }}>
              {/* Date */}
              <div style={{
                textAlign: 'center', padding: '12px 0', borderRadius: 10,
                background: e.status === 'state-archive' ? 'var(--ig-ink-100)' : 'var(--ig-blue-50)',
                color: e.status === 'state-archive' ? 'var(--ig-ink-500)' : 'var(--ig-blue-700)',
                border: e.status === 'state-archive' ? '1px solid var(--ig-border)' : '1px solid var(--ig-blue-100)',
              }}>
                <div className="ig-num" style={{ fontSize: 26, fontWeight: 800, letterSpacing: '-0.02em', lineHeight: 1 }}>{e.d}</div>
                <div style={{ fontSize: 11, fontWeight: 800, marginTop: 4, letterSpacing: '0.06em' }}>{e.m}</div>
              </div>
              {/* Content */}
              <div style={{ minWidth: 0 }}>
                <div style={{ display: 'flex', gap: 6, marginBottom: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                  <span className={`ig-badge ig-badge--${e.area}`} style={{ height: 22, fontSize: 11 }}>{e.areaLab}</span>
                  <span className={`ig-badge ig-badge--${e.status}`} style={{ height: 22, fontSize: 11 }}>{e.statusLab}</span>
                  <span style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>Target: <strong style={{ color: 'var(--ig-ink-700)' }}>{e.target}</strong></span>
                </div>
                <h3 style={{ fontSize: 16, fontWeight: 700, color: 'var(--ig-ink-900)', marginBottom: 4 }}>{e.t}</h3>
                <div style={{ display: 'flex', gap: 14, fontSize: 12, color: 'var(--ig-ink-500)' }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                    {e.mode === 'Online · Zoom' ? <I.Video size={12}/> : <I.MapPin size={12}/>}
                    {e.mode} · {e.place}
                  </span>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                    <I.User size={12}/> Responsabile: <strong style={{ color: 'var(--ig-ink-700)' }}>{e.resp}</strong>
                  </span>
                </div>
              </div>
              {/* Capacity */}
              <div>
                <CapacityBar iscritti={e.iscritti} posti={e.posti}/>
              </div>
              {/* Feedback or status info */}
              <div>
                {e.avgFeedback ? (
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>Feedback</div>
                    <div className="ig-num" style={{ fontSize: 18, fontWeight: 800, color: 'var(--ig-amber-700)' }}>★ {e.avgFeedback}</div>
                    <div style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>{e.iscritti} risposte</div>
                  </div>
                ) : (
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>Promemoria</div>
                    <div style={{ fontSize: 12, color: 'var(--ig-ink-700)' }}>📩 Email programmata 2g prima</div>
                  </div>
                )}
              </div>
              {/* Actions */}
              <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end' }}>
                <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 32, padding: '0 10px' }}><I.Users size={14}/></button>
                <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 32, padding: '0 10px' }}><I.Edit size={14}/></button>
                <button className="ig-btn ig-btn--ghost ig-btn--icon" style={{ width: 32, height: 32 }}><I.ChevD size={14}/></button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </BackendShell>
  );
}

window.BackendEventiScreen = BackendEventiScreen;
