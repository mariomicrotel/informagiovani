/* global React, IGIcons, PublicHeader, PublicFooter */
const I = IGIcons;

function ContentBlock({ icon, title, children, num }) {
  return (
    <div style={{ marginBottom: 32 }}>
      <h3 style={{ fontSize: 20, fontWeight: 700, color: 'var(--ig-ink-900)', display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14, letterSpacing: '-0.01em' }}>
        <span style={{
          width: 32, height: 32, borderRadius: 8,
          background: 'var(--ig-blue-50)', color: 'var(--ig-blue-700)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 13, fontWeight: 800, fontFamily: 'var(--ig-font-mono)',
        }}>{num}</span>
        {title}
      </h3>
      <div style={{ paddingLeft: 44, color: 'var(--ig-ink-700)', fontSize: 15, lineHeight: 1.65 }}>
        {children}
      </div>
    </div>
  );
}

function SidebarRow({ label, value, accent }) {
  return (
    <div style={{ padding: '14px 0', borderBottom: '1px solid var(--ig-border-soft)' }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 15, fontWeight: 600, color: accent || 'var(--ig-ink-900)' }}>{value}</div>
    </div>
  );
}

function SchedaScreen() {
  return (
    <div className="ig" style={{ width: 1440, background: 'var(--ig-bg)', minHeight: 1900 }}>
      <PublicHeader active="Opportunità"/>

      {/* Breadcrumb */}
      <div style={{ background: 'white', borderBottom: '1px solid var(--ig-border-soft)' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '18px 32px' }}>
          <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', display: 'flex', alignItems: 'center', gap: 6 }}>
            <a href="#" style={{ color: 'var(--ig-ink-500)' }}>Home</a>
            <I.ChevR size={12}/>
            <a href="#" style={{ color: 'var(--ig-ink-500)' }}>Opportunità</a>
            <I.ChevR size={12}/>
            <a href="#" style={{ color: 'var(--ig-ink-500)' }}>Estero & Mobilità</a>
            <I.ChevR size={12}/>
            <span style={{ color: 'var(--ig-ink-900)', fontWeight: 600 }}>Erasmus+ Traineeship 2026/27</span>
          </div>
        </div>
      </div>

      {/* HEADER scheda */}
      <div style={{ background: 'white', borderBottom: '1px solid var(--ig-border-soft)' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '32px 32px 28px', display: 'grid', gridTemplateColumns: '1fr 360px', gap: 56 }}>
          <div>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 18 }}>
              <span className="ig-badge ig-badge--estero">Estero & Mobilità</span>
              <span className="ig-badge ig-badge--state-pub">In scadenza</span>
              <span className="ig-badge ig-badge--src-ufficiale"><I.ShieldChk size={12}/>Fonte ufficiale</span>
              <span className="ig-badge" style={{ background: 'var(--ig-ink-75)', color: 'var(--ig-ink-700)' }}>Tirocinio</span>
              <span className="ig-badge" style={{ background: 'var(--ig-ink-75)', color: 'var(--ig-ink-700)' }}>Universitari · Neolaureati</span>
            </div>

            <h1 style={{ fontSize: 40, fontWeight: 800, letterSpacing: '-0.025em', lineHeight: 1.1, color: 'var(--ig-ink-900)', marginBottom: 16, textWrap: 'balance' }}>
              Erasmus+ Traineeship 2026/27 · tirocini retribuiti in 33 paesi europei
            </h1>
            <p style={{ fontSize: 18, color: 'var(--ig-ink-500)', lineHeight: 1.55, maxWidth: 720 }}>
              Periodi di tirocinio da 2 a 12 mesi presso aziende, enti pubblici, organizzazioni internazionali e centri di ricerca in tutta Europa. Per studenti universitari iscritti e neolaureati entro 12 mesi.
            </p>

            <div style={{ display: 'flex', gap: 24, marginTop: 24, fontSize: 13, color: 'var(--ig-ink-500)', alignItems: 'center', flexWrap: 'wrap' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><I.Eye size={14}/> 1.289 visualizzazioni</span>
              <span>·</span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><I.Bookmark size={14}/> 84 utenti l&apos;hanno salvata</span>
              <span>·</span>
              <span>Aggiornata ieri alle 17:22 da <strong style={{ color: 'var(--ig-ink-700)', fontWeight: 600 }}>M. Greco</strong></span>
            </div>
          </div>

          {/* Sidebar header right side: deadline counter */}
          <div style={{
            background: 'var(--ig-red-50)', border: '2px solid var(--ig-red-100)', borderRadius: 14,
            padding: 24, position: 'relative', overflow: 'hidden',
          }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-red-700)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6, display: 'flex', alignItems: 'center', gap: 6 }}>
              <I.Alert size={14}/> Scadenza imminente
            </div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 6 }}>
              <span className="ig-num" style={{ fontSize: 56, fontWeight: 800, letterSpacing: '-0.035em', color: 'var(--ig-red-700)', lineHeight: 1 }}>3</span>
              <span style={{ fontSize: 18, fontWeight: 600, color: 'var(--ig-red-700)' }}>giorni</span>
            </div>
            <div style={{ fontSize: 14, color: 'var(--ig-ink-700)', marginBottom: 18 }}>
              Termine candidature il <strong>17 marzo 2026 ore 12:00</strong>
            </div>
            <button className="ig-btn ig-btn--primary" style={{ width: '100%', justifyContent: 'center' }}>
              <I.Send size={16}/> Vai al bando ufficiale
            </button>
            <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
              <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ flex: 1, justifyContent: 'center' }}><I.Bookmark size={14}/>Salva</button>
              <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ flex: 1, justifyContent: 'center' }}><I.Share size={14}/>Condividi</button>
              <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ flex: 1, justifyContent: 'center' }}><I.Print size={14}/>Stampa</button>
            </div>
          </div>
        </div>
      </div>

      {/* Anchor nav */}
      <div style={{ background: 'white', borderBottom: '1px solid var(--ig-border-soft)', position: 'sticky', top: 0, zIndex: 1 }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 32px' }}>
          <div style={{ display: 'flex', gap: 4 }}>
            {[
              ['Cosa offre', true],
              ['A chi è rivolto', false],
              ['Requisiti', false],
              ['Come partecipare', false],
              ['Documenti', false],
              ['Contatti', false],
              ['Fonte', false],
            ].map(([label, active]) => (
              <a key={label} href="#" style={{
                padding: '14px 16px',
                fontSize: 14, fontWeight: 600,
                color: active ? 'var(--ig-blue-700)' : 'var(--ig-ink-700)',
                borderBottom: active ? '2px solid var(--ig-blue-700)' : '2px solid transparent',
                marginBottom: -1,
              }}>{label}</a>
            ))}
          </div>
        </div>
      </div>

      {/* MAIN */}
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '40px 32px 60px', display: 'grid', gridTemplateColumns: '1fr 360px', gap: 56 }}>
        {/* Content */}
        <div>
          <ContentBlock num="01" title="Cosa offre">
            <p style={{ marginBottom: 14 }}>
              Il programma Erasmus+ Traineeship 2026/27 finanzia <strong>tirocini all&apos;estero in Europa</strong> della durata compresa tra 2 e 12 mesi, presso imprese, centri di ricerca, enti pubblici, ONG, scuole o altri organismi attivi nel mercato del lavoro o nei settori dell&apos;istruzione, formazione e gioventù.
            </p>
            <div style={{ background: 'var(--ig-blue-50)', border: '1px solid var(--ig-blue-100)', borderRadius: 12, padding: 22, marginTop: 8 }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 22 }}>
                {[
                  ['Contributo mensile', '550–700€', 'in base al paese'],
                  ['Top-up KA131', '+250€', 'fondi inclusione'],
                  ['Durata', '2–12 mesi', 'consecutivi'],
                ].map(([l, v, sub]) => (
                  <div key={l}>
                    <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{l}</div>
                    <div className="ig-num" style={{ fontSize: 28, fontWeight: 800, color: 'var(--ig-blue-700)', letterSpacing: '-0.02em', margin: '4px 0' }}>{v}</div>
                    <div style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>{sub}</div>
                  </div>
                ))}
              </div>
            </div>
          </ContentBlock>

          <ContentBlock num="02" title="A chi è rivolto">
            <ul style={{ paddingLeft: 20, marginBottom: 0, lineHeight: 1.8 }}>
              <li><strong>Studenti universitari</strong> iscritti a corsi di laurea, laurea magistrale o dottorato presso un&apos;università italiana titolare di Erasmus Charter for Higher Education</li>
              <li><strong>Neolaureati</strong> entro 12 mesi dal conseguimento del titolo (la candidatura deve essere presentata prima della laurea)</li>
              <li>Studenti dei <strong>cicli unici</strong> e degli <strong>ITS Academy</strong> accreditati</li>
              <li>Cittadini italiani, UE o di paesi terzi associati al programma</li>
            </ul>
          </ContentBlock>

          <ContentBlock num="03" title="Requisiti">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
              {[
                ['Anagrafico', 'Età massima 35 anni alla data di candidatura'],
                ['Iscrizione', 'Regolare iscrizione al proprio ateneo al momento della partenza'],
                ['Lingua', 'Conoscenza linguistica adeguata (livello B1+ certificato o equivalente)'],
                ['Carriera', 'Aver superato almeno il 50% dei CFU previsti dal piano di studi'],
                ['Compatibilità', 'Non aver già usufruito di mobilità Erasmus per più di 11 mesi nello stesso ciclo'],
                ['Riconoscimento', 'Tirocinio coerente con il piano di studi, riconosciuto in CFU'],
              ].map(([k, v]) => (
                <div key={k} style={{ display: 'flex', gap: 12, alignItems: 'flex-start', padding: 12, background: 'var(--ig-ink-50)', borderRadius: 8 }}>
                  <I.Check size={16} color="var(--ig-green-600)" strokeWidth={2.4}/>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ig-ink-900)' }}>{k}</div>
                    <div style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginTop: 2 }}>{v}</div>
                  </div>
                </div>
              ))}
            </div>
          </ContentBlock>

          <ContentBlock num="04" title="Come partecipare">
            <ol style={{ paddingLeft: 0, listStyle: 'none', counterReset: 'step', margin: 0 }}>
              {[
                ['Contatta l\u2019Ufficio Relazioni Internazionali', 'Richiedi il modulo di candidatura presso l\u2019URI del tuo ateneo o accedi al portale online.'],
                ['Trova un host', 'Cerca un\u2019organizzazione ospitante con database di università o piattaforme come Erasmusintern.org.'],
                ['Compila il Learning Agreement', 'Concorda obiettivi formativi e attività con il tuo tutor accademico e l\u2019organizzazione ospitante.'],
                ['Invia la candidatura', 'Carica tutti i documenti nel portale del tuo ateneo entro il 17 marzo 2026 ore 12:00.'],
                ['Selezione e graduatoria', 'Pubblicazione della graduatoria entro 30 giorni dalla scadenza.'],
                ['Mobilità', 'Partenza tra giugno 2026 e settembre 2027.'],
              ].map(([t, d], i) => (
                <li key={t} style={{ position: 'relative', paddingLeft: 56, marginBottom: 18 }}>
                  <span style={{
                    position: 'absolute', left: 0, top: 0,
                    width: 36, height: 36, borderRadius: 10,
                    background: 'var(--ig-blue-700)', color: 'white',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 14, fontWeight: 800, fontFamily: 'var(--ig-font-mono)',
                  }}>{i+1}</span>
                  <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--ig-ink-900)', marginBottom: 4 }}>{t}</div>
                  <div style={{ fontSize: 14, color: 'var(--ig-ink-500)', lineHeight: 1.55 }}>{d}</div>
                </li>
              ))}
            </ol>
          </ContentBlock>

          <ContentBlock num="05" title="Documenti necessari">
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {[
                ['Modulo di candidatura', 'PDF, da scaricare dal portale URI', '124 KB'],
                ['Curriculum europeo (Europass)', 'In inglese e italiano', '—'],
                ['Lettera motivazionale', 'In lingua del paese ospitante o inglese', '—'],
                ['Certificazione linguistica', 'B1+ minimo richiesto', '—'],
                ['Piano di studi attuale', 'Rilasciato dalla segreteria', '—'],
                ['Learning Agreement firmato', 'Da tutor accademico e host', '—'],
              ].map(([n, d, s]) => (
                <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 14, border: '1px solid var(--ig-border-soft)', borderRadius: 8, background: 'white' }}>
                  <I.Doc size={20} color="var(--ig-blue-700)"/>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ig-ink-900)' }}>{n}</div>
                    <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginTop: 2 }}>{d}</div>
                  </div>
                  <span style={{ fontSize: 12, color: 'var(--ig-ink-400)', fontFamily: 'var(--ig-font-mono)' }}>{s}</span>
                  <button className="ig-btn ig-btn--ghost ig-btn--sm"><I.Download size={14}/></button>
                </div>
              ))}
            </div>
          </ContentBlock>

          {/* SOURCE */}
          <div style={{ marginTop: 40, background: 'var(--ig-green-50)', border: '1px solid var(--ig-green-100)', borderRadius: 14, padding: 28 }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: 16, marginBottom: 16 }}>
              <div style={{ width: 44, height: 44, borderRadius: 10, background: 'var(--ig-green-600)', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', flex: '0 0 auto' }}>
                <I.ShieldChk size={22}/>
              </div>
              <div>
                <h3 style={{ fontSize: 17, fontWeight: 700, color: 'var(--ig-ink-900)', marginBottom: 4 }}>Le informazioni sono state verificate dagli operatori del servizio.</h3>
                <p style={{ fontSize: 14, color: 'var(--ig-ink-500)', lineHeight: 1.5 }}>
                  Questa scheda viene aggiornata ogni 7 giorni sulla base della fonte ufficiale. L&apos;ultimo controllo è del 14 marzo 2026.
                </p>
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 18, paddingTop: 16, borderTop: '1px solid var(--ig-green-100)' }}>
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>Fonte</div>
                <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ig-ink-900)' }}>Agenzia Nazionale INDIRE</div>
                <a href="#" style={{ fontSize: 12, color: 'var(--ig-blue-700)', display: 'flex', alignItems: 'center', gap: 4, marginTop: 2 }}>
                  <I.Link size={12}/> erasmusplus.indire.it
                </a>
              </div>
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>Affidabilità</div>
                <span className="ig-badge ig-badge--src-ufficiale"><I.ShieldChk size={12}/>Ufficiale istituzionale</span>
              </div>
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>Responsabile</div>
                <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ig-ink-900)' }}>Operatore: M. Greco</div>
                <div style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}>Sportello Estero</div>
              </div>
            </div>
          </div>
        </div>

        {/* SIDEBAR */}
        <aside>
          <div className="ig-card" style={{ padding: '4px 22px', marginBottom: 20, position: 'sticky', top: 70 }}>
            <div style={{ padding: '18px 0 12px', borderBottom: '1px solid var(--ig-border-soft)' }}>
              <h3 style={{ fontSize: 14, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--ig-ink-700)' }}>Riepilogo scheda</h3>
            </div>
            <SidebarRow label="Scadenza" value="17 marzo 2026 · 12:00" accent="var(--ig-red-700)"/>
            <SidebarRow label="Ente promotore" value="Commissione Europea"/>
            <SidebarRow label="Fonte" value="Agenzia Nazionale INDIRE"/>
            <SidebarRow label="Territorio" value="33 paesi europei"/>
            <SidebarRow label="Destinatari" value="Universitari, neolaureati"/>
            <SidebarRow label="Tipologia" value="Tirocinio retribuito"/>
            <SidebarRow label="Contributo" value="Da 550€ a 700€ / mese"/>
            <SidebarRow label="Durata" value="2 – 12 mesi"/>

            <div style={{ padding: '20px 0 18px' }}>
              <button className="ig-btn ig-btn--accent" style={{ width: '100%', justifyContent: 'center', marginBottom: 8 }}>
                <I.Calendar size={16}/> Prenota un colloquio
              </button>
              <button className="ig-btn ig-btn--secondary" style={{ width: '100%', justifyContent: 'center' }}>
                <I.Chat size={16}/> Chiedi informazioni
              </button>
            </div>
          </div>

          {/* Quick contact card */}
          <div style={{ background: 'var(--ig-ink-50)', borderRadius: 14, padding: 22, border: '1px solid var(--ig-border-soft)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
              <div style={{ width: 44, height: 44, borderRadius: '50%', background: 'var(--ig-blue-700)', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 15 }}>MG</div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ig-ink-900)' }}>Martina Greco</div>
                <div style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}>Sportello Estero & Mobilità</div>
              </div>
            </div>
            <p style={{ fontSize: 13, color: 'var(--ig-ink-500)', lineHeight: 1.5, marginBottom: 14 }}>
              È l&apos;operatrice di riferimento per le opportunità Erasmus+ e mobilità internazionale. Risponde dal lunedì al venerdì.
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, fontSize: 13 }}>
              <a href="#" style={{ display: 'flex', alignItems: 'center', gap: 8 }}><I.Mail size={14}/> estero@informagiovani.enna.it</a>
              <a href="#" style={{ display: 'flex', alignItems: 'center', gap: 8 }}><I.Phone size={14}/> 0935 40 04 07</a>
            </div>
          </div>
        </aside>
      </div>

      {/* RELATED + CTA */}
      <section style={{ background: 'white', padding: '64px 0', borderTop: '1px solid var(--ig-border-soft)' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 32px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 24 }}>
            <h2 style={{ fontSize: 28, fontWeight: 700, letterSpacing: '-0.02em' }}>Opportunità correlate</h2>
            <a href="#" style={{ fontSize: 14, fontWeight: 600 }}>Vedi tutte →</a>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 18 }}>
            {[
              ['Estero', 'estero', 'Corpo Europeo di Solidarietà · volontariato in Europa', 'Per 18-30 anni, 2-12 mesi, alloggio e vitto coperti', '21 giorni', 'soon'],
              ['Estero', 'estero', 'EURES · offerte di lavoro in Europa con supporto alla mobilità', 'Per disoccupati e in cerca di lavoro, contributo trasferta', 'Sempre aperta', 'ok'],
              ['Formazione', 'formazione', 'Borse di studio MAECI per cittadini stranieri', 'Per cittadini italiani residenti all\u2019estero, fino a 9 mesi', '45 giorni', 'soon'],
            ].map(([area, ac, t, d, s, urg], i) => (
              <article key={i} className="ig-card" style={{ padding: 20, cursor: 'pointer' }}>
                <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
                  <span className={`ig-badge ig-badge--${ac}`}>{area}</span>
                  <span className={`ig-badge ig-badge--scad-${urg}`}><I.Clock size={12}/>{s}</span>
                </div>
                <h3 style={{ fontSize: 16, fontWeight: 700, lineHeight: 1.3, color: 'var(--ig-ink-900)', marginBottom: 8 }}>{t}</h3>
                <p style={{ fontSize: 13, color: 'var(--ig-ink-500)', lineHeight: 1.5 }}>{d}</p>
              </article>
            ))}
          </div>

          {/* CTA */}
          <div style={{ marginTop: 48, background: 'var(--ig-ink-50)', borderRadius: 16, padding: '36px 40px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 32, border: '1px solid var(--ig-border-soft)' }}>
            <div>
              <h3 style={{ fontSize: 22, fontWeight: 700, marginBottom: 6 }}>Non sai se questa opportunità è adatta a te?</h3>
              <p style={{ fontSize: 15, color: 'var(--ig-ink-500)' }}>Prenota un colloquio gratuito con un operatore o invia una richiesta di informazioni allo sportello.</p>
            </div>
            <div style={{ display: 'flex', gap: 10, flexShrink: 0 }}>
              <button className="ig-btn ig-btn--primary"><I.Calendar size={16}/> Prenota un colloquio</button>
              <button className="ig-btn ig-btn--secondary"><I.Send size={16}/> Invia una richiesta</button>
            </div>
          </div>
        </div>
      </section>

      <PublicFooter/>
    </div>
  );
}

window.SchedaScreen = SchedaScreen;
