/* global React, IGIcons, BackendShell, PageHeader */
const I = IGIcons;

const partnerRows = [
  ['Università Kore di Enna', 'Università', 'UKE', 'Prof. M. Rinaudo', 'orientamento@unikore.it', 'Universitari · Estero', 12, 4, 'state-pub', 'Accreditato'],
  ['Camera di Commercio Enna', 'Ente pubblico', 'CCIAA', 'Dott. R. Sciascia', 'protocollo@cc-enna.it', 'Impresa · SUAP', 8, 2, 'state-pub', 'Accreditato'],
  ['Fondazione ITS Steve Jobs', 'Fondazione ITS', 'ITS', 'Ing. P. Morgana', 'comunicazione@itsstevejobs.org', 'Formazione · Lavoro', 7, 1, 'state-pub', 'Accreditato'],
  ['CSV Enna · Centro Servizi Volontariato', 'Terzo settore', 'CSV', 'D.ssa F. Carcaci', 'segreteria@csv-enna.it', 'Civile · Diritti', 5, 3, 'state-pub', 'Accreditato'],
  ['Associazione Giovani Imprenditori Enna', 'Associazione', 'AGI', 'Avv. G. La Spina', 'agi.enna@gmail.com', 'Impresa', 4, 1, 'state-pub', 'Accreditato'],
  ['Centro per l\u2019Impiego Enna', 'Ente pubblico', 'CPI', 'Dott.ssa A. Greco', 'cpi.enna@anpal.it', 'Lavoro', 22, 0, 'state-pub', 'Accreditato'],
  ['ESN Enna · Erasmus Student Network', 'Associazione', 'ESN', 'F. Costanza', 'esn.enna@erasmus.eu', 'Estero · Cultura', 3, 2, 'state-review', 'In revisione'],
  ['Confcommercio Enna', 'Sindacato', 'CONF', 'Dott. M. Lo Bue', 'enna@confcommercio.it', 'Impresa · Lavoro', 0, 1, 'state-review', 'In revisione'],
  ['Caritas Diocesana Enna', 'Terzo settore', 'CARI', 'Don L. Pirrotta', 'caritas.enna@diocesi.it', 'Diritti · Inclusione', 6, 0, 'state-update', 'Da aggiornare'],
];

const proposte = [
  ['Workshop · Erasmus+ studenti UKE', 'Università Kore', 'Evento', 'oggi', 'Estero', 'estero', 'state-review', 'In revisione'],
  ['Corso PMI Digital Skills 2026', 'Fondazione ITS Steve Jobs', 'Corso', '2g fa', 'Formazione', 'formazione', 'state-review', 'Da validare'],
  ['Bando Microcredito CCIAA 2026', 'Camera di Commercio Enna', 'Bando', '3g fa', 'Impresa', 'impresa', 'state-valid', 'Da pubblicare'],
  ['Volontariato Caritas · raccolta cibo', 'Caritas Enna', 'Iniziativa', '5g fa', 'Diritti', 'diritti', 'state-review', 'Integrazione richiesta'],
];

function BackendPartnerScreen() {
  return (
    <BackendShell active="Partner" breadcrumb={['Console', 'Ecosistema', 'Partner']} height={1700}>
      <PageHeader
        title="Partner territoriali"
        subtitle="42 partner accreditati · 3 in revisione · 67 contenuti proposti dall'inizio dell'anno · 18 trasformati in scheda"
        actions={<>
          <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Mail size={14}/> Invio comunicazione</button>
          <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Download size={14}/> Esporta</button>
          <button className="ig-btn ig-btn--primary ig-btn--sm"><I.Plus size={14}/> Nuovo partner</button>
        </>}
        tabs={['Partner · 42', 'Contenuti proposti · 12', 'In revisione · 6', 'Inviti in sospeso · 3']}
        activeTab="Partner · 42"
      />

      <div style={{ padding: '24px 32px 32px' }}>
        {/* KPI */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 24 }}>
          {[
            ['Partner attivi', '42', 'tasso accreditamento 89%', 'var(--ig-blue-700)'],
            ['Proposte aperte', '12', '4 da assegnare', 'var(--ig-amber-700)'],
            ['Schede co-prodotte', '67', 'questo anno', 'var(--ig-teal-700)'],
            ['Tempo medio approvazione', '2.3g', 'target: 3 giorni', 'var(--ig-green-700)'],
          ].map(([l, v, h, c]) => (
            <div key={l} className="ig-card" style={{ padding: 18 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--ig-ink-500)' }}>{l}</div>
              <div className="ig-num" style={{ fontSize: 30, fontWeight: 800, color: c, letterSpacing: '-0.02em', lineHeight: 1.1, margin: '6px 0' }}>{v}</div>
              <div style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}>{h}</div>
            </div>
          ))}
        </div>

        {/* TWO-COLUMN: Partner list + Proposals */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 20 }}>
          {/* Partner list */}
          <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ padding: '16px 22px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <h3 style={{ fontSize: 16, fontWeight: 700 }}>Elenco partner</h3>
              <div style={{ display: 'flex', gap: 8 }}>
                <div style={{ position: 'relative' }}>
                  <input className="ig-input" placeholder="Cerca…" style={{ height: 32, paddingLeft: 30, fontSize: 12, width: 180 }}/>
                  <div style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)' }}>
                    <I.Search size={14} color="var(--ig-ink-400)"/>
                  </div>
                </div>
                <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 32 }}>Tutti i tipi <I.ChevD size={12}/></button>
              </div>
            </div>
            <div>
              {partnerRows.map((p) => (
                <div key={p[0]} style={{ padding: '14px 22px', borderBottom: '1px solid var(--ig-border-soft)', display: 'grid', gridTemplateColumns: '40px 1fr 130px 110px 90px', gap: 12, alignItems: 'center' }}>
                  <div style={{
                    width: 36, height: 36, borderRadius: 8,
                    background: p[8] === 'state-pub' ? 'var(--ig-blue-50)' : p[8] === 'state-review' ? 'var(--ig-amber-50)' : 'var(--ig-violet-100)',
                    color: p[8] === 'state-pub' ? 'var(--ig-blue-700)' : p[8] === 'state-review' ? 'var(--ig-amber-700)' : 'var(--ig-violet-700)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontWeight: 800, fontSize: 11,
                  }}>{p[2]}</div>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ig-ink-900)' }}>{p[0]}</div>
                    <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', marginTop: 2 }}>{p[1]} · {p[3]} · {p[4]}</div>
                  </div>
                  <span style={{ fontSize: 11, color: 'var(--ig-ink-700)' }}>{p[5]}</span>
                  <div>
                    <span className={`ig-badge ig-badge--${p[8]}`} style={{ height: 22, fontSize: 11 }}>{p[9]}</span>
                    <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', marginTop: 4 }}>{p[6]} schede · {p[7]} proposte</div>
                  </div>
                  <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                    <button className="ig-btn ig-btn--ghost ig-btn--icon" style={{ width: 28, height: 28 }}><I.Mail size={14}/></button>
                    <button className="ig-btn ig-btn--ghost ig-btn--icon" style={{ width: 28, height: 28 }}><I.ChevR size={14}/></button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Proposals */}
          <div>
            <div className="ig-card" style={{ padding: 0, overflow: 'hidden', marginBottom: 16 }}>
              <div style={{ padding: '16px 22px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', alignItems: 'center', gap: 10 }}>
                <I.Sparkle size={18} color="var(--ig-amber-700)"/>
                <h3 style={{ fontSize: 16, fontWeight: 700 }}>Contenuti proposti</h3>
                <span style={{ fontSize: 11, color: 'white', background: 'var(--ig-red-600)', padding: '2px 8px', borderRadius: 999, fontWeight: 700, marginLeft: 'auto' }}>4 nuovi</span>
              </div>
              <div>
                {proposte.map((p, i) => (
                  <div key={i} style={{ padding: '16px 22px', borderBottom: i < proposte.length - 1 ? '1px solid var(--ig-border-soft)' : 'none' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                      <span className={`ig-badge ig-badge--${p[5]}`} style={{ height: 20, fontSize: 11 }}>{p[4]}</span>
                      <span style={{ fontSize: 11, color: 'var(--ig-ink-500)', background: 'var(--ig-ink-100)', padding: '2px 8px', borderRadius: 999, fontWeight: 600 }}>{p[2]}</span>
                      <span style={{ fontSize: 11, color: 'var(--ig-ink-400)', marginLeft: 'auto' }}>{p[3]}</span>
                    </div>
                    <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ig-ink-900)', marginBottom: 4 }}>{p[0]}</div>
                    <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginBottom: 10 }}>da <strong style={{ color: 'var(--ig-ink-700)' }}>{p[1]}</strong> · <span style={{ color: 'var(--ig-amber-800)' }}>{p[7]}</span></div>
                    <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                      <button className="ig-btn ig-btn--primary ig-btn--sm" style={{ height: 28, padding: '0 10px', fontSize: 12 }}>
                        <I.Check size={12}/> Approva
                      </button>
                      <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 28, padding: '0 10px', fontSize: 12 }}>
                        Converti in {p[2] === 'Evento' ? 'evento' : 'scheda'}
                      </button>
                      <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 28, padding: '0 10px', fontSize: 12 }}>
                        Richiedi integrazione
                      </button>
                      <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ height: 28, padding: '0 10px', fontSize: 12, color: 'var(--ig-red-700)' }}>
                        Rifiuta
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="ig-card" style={{ padding: 20 }}>
              <h3 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)', marginBottom: 14 }}>Top contributori 2026</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {[
                  ['Centro per l\u2019Impiego Enna', 'CPI', 22, 100, 'var(--ig-blue-700)'],
                  ['Università Kore di Enna', 'UKE', 12, 55, 'var(--ig-violet-700)'],
                  ['Camera di Commercio Enna', 'CCIAA', 8, 36, 'var(--ig-teal-700)'],
                  ['Fondazione ITS Steve Jobs', 'ITS', 7, 32, 'var(--ig-amber-700)'],
                  ['Caritas Diocesana Enna', 'CARI', 6, 27, 'var(--ig-pink-700)'],
                ].map(([n, s, v, w, c]) => (
                  <div key={n}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 4 }}>
                      <span style={{ color: 'var(--ig-ink-900)', fontWeight: 600 }}>{s} · {n}</span>
                      <span className="ig-num" style={{ color: c, fontWeight: 700 }}>{v} schede</span>
                    </div>
                    <div style={{ height: 5, background: 'var(--ig-ink-150)', borderRadius: 999, overflow: 'hidden' }}>
                      <div style={{ width: `${w}%`, height: '100%', background: c }}/>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </BackendShell>
  );
}

window.BackendPartnerScreen = BackendPartnerScreen;
