/* global React, IGIcons */
const I = IGIcons;

const sysSwatches = [
  ['Primary · Blu istituzionale', 'var(--ig-blue-700)', '#143F7A', 'blu-700'],
  ['Primary hover',               'var(--ig-blue-800)', '#0E2E58', 'blu-800'],
  ['Blu chiaro · superfici',      'var(--ig-blue-100)', '#E3EDFA', 'blu-100'],
  ['Accent · Opportunità',        'var(--ig-teal-700)', '#0F8077', 'teal-700'],
  ['Teal · superfici',            'var(--ig-teal-100)', '#D4F1EC', 'teal-100'],
  ['Amber · scadenze, CTA',       'var(--ig-amber-600)', '#D28A1C', 'amber-600'],
  ['Amber · superfici',           'var(--ig-amber-100)', '#FBEAC6', 'amber-100'],
  ['Verde · stato pubblicato',    'var(--ig-green-600)', '#1F8A55', 'green-600'],
  ['Rosso · errori/scaduto',      'var(--ig-red-600)',   '#C2362B', 'red-600'],
  ['Viola · da aggiornare',       'var(--ig-violet-600)','#6E4DC6', 'violet-600'],
];

const sysInk = [
  ['Ink 900 · testo',  'var(--ig-ink-900)', '#0C1A2C'],
  ['Ink 700 · titoli', 'var(--ig-ink-700)', '#2C3A4F'],
  ['Ink 500 · muted',  'var(--ig-ink-500)', '#5B6779'],
  ['Ink 300',          'var(--ig-ink-300)', '#B7BFCB'],
  ['Ink 200 · bordi',  'var(--ig-ink-200)', '#D6DCE5'],
  ['Ink 100',          'var(--ig-ink-100)', '#EEF1F5'],
  ['Ink 50 · bg app',  'var(--ig-ink-50)',  '#F7F8FA'],
  ['Paper',            'var(--ig-paper)',   '#FFFFFF'],
];

function Swatch({ name, value, hex, token }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <div style={{
        background: value, height: 78, borderRadius: 10,
        border: '1px solid rgba(12,26,44,0.08)',
      }} />
      <div style={{ fontSize: 12, color: 'var(--ig-ink-700)', fontWeight: 600, lineHeight: 1.3 }}>{name}</div>
      <div style={{ fontFamily: 'var(--ig-font-mono)', fontSize: 11, color: 'var(--ig-ink-500)' }}>
        {hex}{token ? ` · --ig-${token}` : ''}
      </div>
    </div>
  );
}

function SysSection({ title, eyebrow, children, style }) {
  return (
    <section style={{ padding: '32px 56px', borderBottom: '1px solid var(--ig-border-soft)', ...style }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 14, marginBottom: 22 }}>
        <span style={{
          fontSize: 11, fontWeight: 700, letterSpacing: '0.14em',
          color: 'var(--ig-teal-700)', textTransform: 'uppercase',
        }}>{eyebrow}</span>
        <h2 style={{ fontSize: 22, fontWeight: 700 }}>{title}</h2>
      </div>
      {children}
    </section>
  );
}

function SystemScreen() {
  return (
    <div className="ig" style={{ width: 1440, background: 'var(--ig-paper)', minHeight: 1700 }}>
      {/* Top banner */}
      <div style={{
        padding: '40px 56px 36px',
        background: 'linear-gradient(135deg, var(--ig-blue-700) 0%, var(--ig-blue-800) 60%, #08213f 100%)',
        color: 'white',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <div style={{
              fontSize: 12, fontWeight: 700, letterSpacing: '0.18em',
              color: 'var(--ig-amber-500)', marginBottom: 14, textTransform: 'uppercase',
            }}>Design System · v0.1</div>
            <h1 style={{ fontSize: 44, fontWeight: 800, color: 'white', letterSpacing: '-0.02em', marginBottom: 8 }}>
              Informagiovani Enna
            </h1>
            <p style={{ fontSize: 17, color: 'rgba(255,255,255,0.78)', maxWidth: 640 }}>
              Sistema visivo per la piattaforma di orientamento, informazione e servizi rivolti ai giovani del territorio. Istituzionale, accessibile, costruito per scalare.
            </p>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 8 }}>
            <div style={{ display: 'flex', gap: 14, fontSize: 13, color: 'rgba(255,255,255,0.7)' }}>
              <span>Comune di Enna</span>
              <span style={{ opacity: 0.4 }}>·</span>
              <span>WCAG AA</span>
              <span style={{ opacity: 0.4 }}>·</span>
              <span>Responsive</span>
            </div>
            {/* Brand mark */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 8 }}>
              <div style={{
                width: 48, height: 48, borderRadius: 12,
                background: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center',
                position: 'relative',
              }}>
                <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
                  <path d="M4 22 L14 4 L24 22 Z" stroke="#143F7A" strokeWidth="2.4" strokeLinejoin="round"/>
                  <circle cx="14" cy="15" r="2.4" fill="#0F8077"/>
                </svg>
              </div>
              <div style={{ lineHeight: 1.1 }}>
                <div style={{ fontSize: 18, fontWeight: 800, letterSpacing: '-0.01em' }}>Informagiovani</div>
                <div style={{ fontSize: 13, color: 'var(--ig-amber-500)', fontWeight: 600, letterSpacing: '0.04em' }}>ENNA</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* COLORI */}
      <SysSection eyebrow="01 · Foundations" title="Palette colore">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 18, marginBottom: 28 }}>
          {sysSwatches.map((s) => <Swatch key={s[0]} name={s[0]} value={s[1]} hex={s[2]} token={s[3]} />)}
        </div>
        <h3 style={{ fontSize: 14, fontWeight: 700, color: 'var(--ig-ink-700)', marginBottom: 14, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Scala neutrale</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', gap: 12 }}>
          {sysInk.map((s) => <Swatch key={s[0]} name={s[0]} value={s[1]} hex={s[2]} />)}
        </div>
      </SysSection>

      {/* TIPOGRAFIA */}
      <SysSection eyebrow="02 · Foundations" title="Tipografia">
        <div style={{ display: 'grid', gridTemplateColumns: '320px 1fr', gap: 48 }}>
          <div>
            <div style={{ fontFamily: 'var(--ig-font)', fontSize: 80, fontWeight: 800, letterSpacing: '-0.04em', lineHeight: 1, color: 'var(--ig-ink-900)' }}>Aa</div>
            <div style={{ marginTop: 10, fontSize: 18, fontWeight: 700, color: 'var(--ig-ink-900)' }}>Manrope</div>
            <div style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginTop: 2 }}>Primary · 400 / 500 / 600 / 700 / 800</div>
            <div style={{ fontFamily: 'var(--ig-font-mono)', fontSize: 12, color: 'var(--ig-ink-500)', marginTop: 14 }}>--ig-font</div>
            <div style={{ marginTop: 26, paddingTop: 22, borderTop: '1px solid var(--ig-border-soft)' }}>
              <div className="ig-serif" style={{ fontSize: 36, color: 'var(--ig-ink-900)' }}>Aa</div>
              <div style={{ marginTop: 10, fontSize: 15, fontWeight: 700, color: 'var(--ig-ink-900)' }}>Newsreader</div>
              <div style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginTop: 2 }}>Display serif · usato per accenti editoriali nell&apos;hero</div>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            {[
              ['Display / 44px / 800', 44, 800, 'Il punto di accesso alle opportunità'],
              ['H1 / 32px / 700', 32, 700, 'Opportunità e servizi per i giovani di Enna'],
              ['H2 / 24px / 700', 24, 700, 'Schede informative in scadenza questa settimana'],
              ['H3 / 18px / 600', 18, 600, 'Servizio Civile Universale 2026 · candidature aperte'],
              ['Body / 16px / 400', 16, 400, 'Le informazioni pubblicate sono verificate dagli operatori dello sportello e aggiornate periodicamente in base alle fonti istituzionali.'],
              ['Caption / 13px / 500', 13, 500, 'Aggiornato il 14 marzo · Fonte: Dipartimento Politiche Giovanili'],
            ].map(([label, size, weight, sample]) => (
              <div key={label} style={{ display: 'grid', gridTemplateColumns: '160px 1fr', gap: 24, alignItems: 'baseline', paddingBottom: 14, borderBottom: '1px solid var(--ig-border-soft)' }}>
                <div style={{ fontSize: 11, fontFamily: 'var(--ig-font-mono)', color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{label}</div>
                <div style={{ fontSize: size, fontWeight: weight, letterSpacing: size > 28 ? '-0.02em' : '-0.005em', color: 'var(--ig-ink-900)', lineHeight: 1.2 }}>
                  {sample}
                </div>
              </div>
            ))}
          </div>
        </div>
      </SysSection>

      {/* BADGES */}
      <SysSection eyebrow="03 · Components" title="Badge · stati e tassonomie">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 32 }}>
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-ink-700)', marginBottom: 12, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Aree tematiche</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              <span className="ig-badge ig-badge--lavoro">Lavoro</span>
              <span className="ig-badge ig-badge--formazione">Formazione</span>
              <span className="ig-badge ig-badge--impresa">Fare Impresa</span>
              <span className="ig-badge ig-badge--estero">Estero & Mobilità</span>
              <span className="ig-badge ig-badge--diritti">Diritti</span>
              <span className="ig-badge ig-badge--cultura">Cultura</span>
              <span className="ig-badge ig-badge--sport">Sport</span>
              <span className="ig-badge ig-badge--civile">Servizio Civile</span>
              <span className="ig-badge ig-badge--concorso">Concorsi</span>
            </div>
          </div>
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-ink-700)', marginBottom: 12, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Stato scheda</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              <span className="ig-badge ig-badge--state-draft">Bozza</span>
              <span className="ig-badge ig-badge--state-review">Da verificare</span>
              <span className="ig-badge ig-badge--state-valid">Validata</span>
              <span className="ig-badge ig-badge--state-pub">Pubblicata</span>
              <span className="ig-badge ig-badge--state-exp">Scaduta</span>
              <span className="ig-badge ig-badge--state-archive">Archiviata</span>
              <span className="ig-badge ig-badge--state-update">Da aggiornare</span>
            </div>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-ink-700)', margin: '20px 0 12px', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Scadenza</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              <span className="ig-badge ig-badge--scad-urgent"><I.Clock size={12}/>Entro 3 giorni</span>
              <span className="ig-badge ig-badge--scad-soon"><I.Clock size={12}/>Entro 14 giorni</span>
              <span className="ig-badge ig-badge--scad-ok">Sempre aperta</span>
            </div>
          </div>
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-ink-700)', marginBottom: 12, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Affidabilità fonte</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              <span className="ig-badge ig-badge--src-ufficiale"><I.ShieldChk size={12}/>Ufficiale</span>
              <span className="ig-badge ig-badge--src-partner"><I.Shield size={12}/>Partner accreditato</span>
              <span className="ig-badge ig-badge--src-verificata"><I.Check size={12}/>Verificata</span>
            </div>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-ink-700)', margin: '20px 0 12px', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Ticket</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              <span className="ig-badge" style={{ background: 'var(--ig-blue-100)', color: 'var(--ig-blue-800)' }}>Nuovo</span>
              <span className="ig-badge" style={{ background: 'var(--ig-violet-100)', color: 'var(--ig-violet-700)' }}>Assegnato</span>
              <span className="ig-badge" style={{ background: 'var(--ig-amber-100)', color: 'var(--ig-amber-800)' }}>In lavorazione</span>
              <span className="ig-badge" style={{ background: '#fdf1c2', color: '#8a5d0a' }}>In attesa utente</span>
              <span className="ig-badge ig-badge--state-pub">Evaso</span>
              <span className="ig-badge ig-badge--state-archive">Chiuso</span>
            </div>
          </div>
        </div>
      </SysSection>

      {/* BUTTONS + INPUTS */}
      <SysSection eyebrow="04 · Components" title="Buttons, input, controlli">
        <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 48 }}>
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-ink-700)', marginBottom: 14, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Buttons</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, alignItems: 'center', marginBottom: 12 }}>
              <button className="ig-btn ig-btn--primary"><I.Search size={16}/>Cerca opportunità</button>
              <button className="ig-btn ig-btn--accent">Prenota colloquio</button>
              <button className="ig-btn ig-btn--secondary"><I.Bookmark size={16}/>Salva</button>
              <button className="ig-btn ig-btn--ghost">Annulla</button>
              <button className="ig-btn ig-btn--danger">Elimina</button>
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, alignItems: 'center', marginBottom: 12 }}>
              <button className="ig-btn ig-btn--primary ig-btn--lg">Inizia ora <I.ArrowR size={18}/></button>
              <button className="ig-btn ig-btn--secondary ig-btn--sm">Dettagli</button>
              <button className="ig-btn ig-btn--secondary ig-btn--sm">Filtri <I.ChevD size={14}/></button>
              <button className="ig-btn ig-btn--secondary ig-btn--icon"><I.Heart size={16}/></button>
              <button className="ig-btn ig-btn--secondary ig-btn--icon"><I.Share size={16}/></button>
            </div>

            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-ink-700)', margin: '26px 0 14px', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Stati alert</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                ['var(--ig-blue-100)','var(--ig-blue-700)', <I.Info size={18}/>, 'Informazione','Le candidature al Servizio Civile chiudono tra 3 giorni.'],
                ['var(--ig-green-100)','var(--ig-green-700)', <I.Check size={18}/>, 'Operazione riuscita','La scheda è stata pubblicata correttamente.'],
                ['var(--ig-amber-100)','var(--ig-amber-800)', <I.Alert size={18}/>, 'Attenzione','Questa fonte non viene aggiornata da 60 giorni. Verifica i dati.'],
                ['var(--ig-red-100)','var(--ig-red-700)', <I.Alert size={18}/>, 'Errore','Impossibile inviare la richiesta. Riprova tra qualche istante.'],
              ].map(([bg, fg, ico, title, msg]) => (
                <div key={title} style={{ display: 'flex', gap: 12, alignItems: 'flex-start', padding: '12px 16px', borderRadius: 10, background: bg, color: fg }}>
                  {ico}
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 14 }}>{title}</div>
                    <div style={{ fontSize: 14, color: 'var(--ig-ink-700)' }}>{msg}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-ink-700)', marginBottom: 14, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Input & form</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div>
                <label className="ig-label">Email</label>
                <input className="ig-input" placeholder="nome@email.it" defaultValue="m.scalisi@email.it" />
              </div>
              <div>
                <label className="ig-label">Argomento del colloquio</label>
                <div className="ig-input" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', color: 'var(--ig-ink-900)' }}>
                  <span>Fare Impresa</span>
                  <I.ChevD size={16} color="var(--ig-ink-500)"/>
                </div>
              </div>
              <div>
                <label className="ig-label">Focus state</label>
                <div className="ig-input" style={{ borderColor: 'var(--ig-primary)', boxShadow: 'var(--ig-ring)', display: 'flex', alignItems: 'center', color: 'var(--ig-ink-900)' }}>
                  Erasmus+ traineeship 2026
                </div>
              </div>
              <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                <div style={{ width: 20, height: 20, borderRadius: 4, background: 'var(--ig-primary)', display: 'flex', alignItems: 'center', justifyContent: 'center', flex: '0 0 auto', marginTop: 2 }}>
                  <I.Check size={14} color="white" strokeWidth={2.5}/>
                </div>
                <div style={{ fontSize: 14, color: 'var(--ig-ink-700)' }}>Ho letto e accetto l&apos;<a href="#">informativa sulla privacy</a> del Comune di Enna.</div>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                <span style={{ background: 'var(--ig-blue-100)', color: 'var(--ig-blue-800)', height: 32, padding: '0 12px', borderRadius: 6, fontSize: 13, fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                  Lavoro <I.X size={12}/>
                </span>
                <span style={{ background: 'var(--ig-blue-100)', color: 'var(--ig-blue-800)', height: 32, padding: '0 12px', borderRadius: 6, fontSize: 13, fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                  18-25 anni <I.X size={12}/>
                </span>
                <span style={{ background: 'var(--ig-blue-100)', color: 'var(--ig-blue-800)', height: 32, padding: '0 12px', borderRadius: 6, fontSize: 13, fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                  Enna <I.X size={12}/>
                </span>
              </div>
            </div>
          </div>
        </div>
      </SysSection>

      {/* SPACING & GRID */}
      <SysSection eyebrow="05 · Foundations" title="Spaziature, radius, ombre" style={{ borderBottom: 'none', paddingBottom: 60 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 32 }}>
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-ink-700)', marginBottom: 14, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Spaziatura · 4pt</div>
            {[4, 8, 12, 16, 24, 32, 48].map((s) => (
              <div key={s} style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
                <div style={{ width: 60, fontFamily: 'var(--ig-font-mono)', fontSize: 12, color: 'var(--ig-ink-500)' }}>{s} px</div>
                <div style={{ width: s, height: 18, background: 'var(--ig-blue-700)', borderRadius: 2 }}/>
              </div>
            ))}
          </div>
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-ink-700)', marginBottom: 14, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Border radius</div>
            <div style={{ display: 'flex', gap: 14 }}>
              {[
                ['xs', 4], ['sm', 6], ['md', 10], ['lg', 14], ['xl', 20]
              ].map(([n, v]) => (
                <div key={n} style={{ textAlign: 'center' }}>
                  <div style={{ width: 64, height: 64, borderRadius: v, background: 'var(--ig-blue-100)', border: '1px solid var(--ig-blue-300)' }}/>
                  <div style={{ fontSize: 11, fontFamily: 'var(--ig-font-mono)', color: 'var(--ig-ink-500)', marginTop: 6 }}>{n} · {v}px</div>
                </div>
              ))}
            </div>
          </div>
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-ink-700)', marginBottom: 14, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Elevazione</div>
            <div style={{ display: 'flex', gap: 16 }}>
              {[
                ['xs', 'var(--ig-shadow-xs)'],
                ['sm', 'var(--ig-shadow-sm)'],
                ['md', 'var(--ig-shadow-md)'],
                ['lg', 'var(--ig-shadow-lg)'],
              ].map(([n, v]) => (
                <div key={n} style={{ textAlign: 'center' }}>
                  <div style={{ width: 64, height: 64, borderRadius: 10, background: 'white', boxShadow: v }}/>
                  <div style={{ fontSize: 11, fontFamily: 'var(--ig-font-mono)', color: 'var(--ig-ink-500)', marginTop: 6 }}>{n}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </SysSection>
    </div>
  );
}

window.SystemScreen = SystemScreen;
