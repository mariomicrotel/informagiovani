/* global React, IGIcons, BackendShell, PageHeader */
const I = IGIcons;

function Section({ num, icon, title, subtitle, status, children }) {
  return (
    <div className="ig-card" style={{ padding: 0, marginBottom: 16, overflow: 'hidden' }}>
      <div style={{ padding: '18px 24px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', alignItems: 'center', gap: 14 }}>
        <div style={{
          width: 36, height: 36, borderRadius: 10, background: 'var(--ig-blue-700)', color: 'white',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 14, fontWeight: 800, fontFamily: 'var(--ig-font-mono)',
        }}>{num}</div>
        <div style={{ flex: 1 }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, color: 'var(--ig-ink-900)', display: 'flex', alignItems: 'center', gap: 8 }}>
            {icon} {title}
          </h3>
          {subtitle && <div style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginTop: 2 }}>{subtitle}</div>}
        </div>
        {status && <span style={{
          height: 24, padding: '0 10px', borderRadius: 999,
          background: status === 'done' ? 'var(--ig-green-100)' : status === 'progress' ? 'var(--ig-amber-100)' : 'var(--ig-ink-100)',
          color: status === 'done' ? 'var(--ig-green-700)' : status === 'progress' ? 'var(--ig-amber-800)' : 'var(--ig-ink-700)',
          fontSize: 11, fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: 4,
        }}>
          {status === 'done' ? <><I.Check size={12}/>Completato</> : status === 'progress' ? 'In compilazione' : 'Non iniziato'}
        </span>}
      </div>
      <div style={{ padding: 24 }}>{children}</div>
    </div>
  );
}

function Field({ label, value, hint }) {
  return (
    <div>
      <label className="ig-label">{label}</label>
      <div className="ig-input" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', color: 'var(--ig-ink-900)' }}>
        <span>{value}</span>
        <I.ChevD size={16} color="var(--ig-ink-500)"/>
      </div>
      {hint && <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', marginTop: 4 }}>{hint}</div>}
    </div>
  );
}

function PillRow({ label, options, selected }) {
  return (
    <div>
      <label className="ig-label">{label}</label>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
        {options.map((o) => (
          <span key={o} style={{
            height: 32, padding: '0 12px', borderRadius: 6,
            border: '1px solid',
            borderColor: selected.includes(o) ? 'var(--ig-blue-700)' : 'var(--ig-border)',
            background: selected.includes(o) ? 'var(--ig-blue-50)' : 'white',
            color: selected.includes(o) ? 'var(--ig-blue-700)' : 'var(--ig-ink-700)',
            fontSize: 13, fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 6,
            cursor: 'pointer',
          }}>
            {selected.includes(o) && <I.Check size={12}/>}
            {o}
          </span>
        ))}
      </div>
    </div>
  );
}

function BackendColloquiScreen() {
  return (
    <BackendShell active="Colloqui" breadcrumb={['Console', 'Sportello', 'Colloqui', 'Nuovo colloquio · S. Catanzaro']} height={2350}>
      <PageHeader
        title="Colloquio · Salvatore Catanzaro"
        subtitle="Sabato 14 marzo 2026 · 09:30 · in presenza · sportello principale · operatore M. Greco"
        actions={<>
          <span style={{ fontSize: 13, color: 'var(--ig-ink-500)', display: 'flex', alignItems: 'center', gap: 6 }}>
            <I.Clock size={14}/> Iniziato 12 minuti fa · salvataggio automatico
          </span>
          <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Doc size={14}/> Anteprima report</button>
          <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ color: 'var(--ig-ink-700)' }}>Salva bozza</button>
          <button className="ig-btn ig-btn--primary ig-btn--sm"><I.Check size={14}/> Chiudi colloquio</button>
        </>}
      />

      <div style={{ padding: '24px 32px', display: 'grid', gridTemplateColumns: '1fr 320px', gap: 24 }}>
        {/* MAIN FORM */}
        <div>
          {/* USER STRIP */}
          <div style={{
            background: 'linear-gradient(120deg, var(--ig-blue-50) 0%, white 50%)',
            border: '1px solid var(--ig-blue-100)', borderRadius: 12,
            padding: 18, display: 'flex', alignItems: 'center', gap: 16, marginBottom: 20,
          }}>
            <div style={{ width: 52, height: 52, borderRadius: '50%', background: 'var(--ig-amber-500)', color: 'var(--ig-blue-900)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 17, flex: '0 0 auto' }}>SC</div>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
                <h2 style={{ fontSize: 18, fontWeight: 700 }}>Salvatore Catanzaro</h2>
                <span style={{ fontSize: 12, fontFamily: 'var(--ig-font-mono)', color: 'var(--ig-ink-500)' }}>USR-001284</span>
                <span className="ig-badge" style={{ background: 'var(--ig-amber-100)', color: 'var(--ig-amber-800)' }}>NEET</span>
                <span className="ig-badge" style={{ background: 'var(--ig-teal-100)', color: 'var(--ig-teal-700)' }}>Aspirante imprenditore</span>
              </div>
              <div style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>
                22 anni · Enna · diploma tecnico · disoccupato · 4 colloqui precedenti · ultimo 5 giorni fa con F. Bellomo (idea food truck)
              </div>
            </div>
            <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ color: 'var(--ig-blue-700)' }}>Apri scheda utente →</button>
          </div>

          {/* 01 — Dati colloquio */}
          <Section num="01" icon={<I.Calendar size={18} color="var(--ig-blue-700)"/>} title="Dati colloquio" status="done">
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
              <Field label="Operatore" value="M. Greco"/>
              <Field label="Data" value="14 marzo 2026"/>
              <Field label="Ora" value="09:30 (durata stimata 45 min)"/>
              <Field label="Canale" value="In presenza · Sportello principale"/>
              <Field label="Argomento prevalente" value="Fare Impresa"/>
              <Field label="Riferimento richiesta" value="#R-2841 · Resto al Sud"/>
            </div>
          </Section>

          {/* 02 — Bisogno espresso */}
          <Section num="02" icon={<I.Chat size={18} color="var(--ig-violet-700)"/>} title="Bisogno espresso" subtitle="Cosa ha chiesto l'utente · in sue parole" status="progress">
            <label className="ig-label">Bisogno espresso</label>
            <textarea
              className="ig-textarea"
              defaultValue={`L'utente chiede chiarimenti sulla procedura di candidatura a Resto al Sud per la propria idea imprenditoriale di catering siciliano per eventi. In particolare:\n• quali documenti servono per la fase 1\n• se può candidarsi prima di aver costituito la società\n• tempi di erogazione del contributo\n• se il microcredito Sicilia è cumulabile con Resto al Sud`}
              style={{ minHeight: 110 }}
            />
            <div style={{ marginTop: 14 }}>
              <PillRow
                label="Categoria prevalente"
                options={['Fare Impresa', 'Lavoro', 'Formazione', 'Estero', 'Diritti', 'Concorsi', 'Servizio Civile', 'Altro']}
                selected={['Fare Impresa']}
              />
            </div>
          </Section>

          {/* 03 — Sintesi colloquio */}
          <Section num="03" icon={<I.Edit size={18} color="var(--ig-teal-700)"/>} title="Sintesi colloquio" subtitle="Note strutturate dell'operatore · visibili solo internamente" status="progress">
            <label className="ig-label">Sintesi</label>
            <textarea
              className="ig-textarea"
              defaultValue={`Abbiamo ripercorso la documentazione Resto al Sud, verificando i requisiti dell'utente (under 56, residente in regione idonea, non occupato a tempo indeterminato). L'idea food truck è coerente con le attività finanziabili.\n\nPunti chiarificati:\n• non è necessaria costituzione preventiva, basta la prenotazione dei codici ATECO\n• la documentazione tecnica può essere preparata in 30-45 giorni con il supporto del tutor\n• microcredito e Resto al Sud sono cumulabili nei limiti del massimale per singolo richiedente`}
              style={{ minHeight: 130 }}
            />
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginTop: 14 }}>
              <div>
                <label className="ig-label">Problemi emersi</label>
                <textarea className="ig-textarea" defaultValue={`• competenze contabili limitate\n• difficoltà nel reperire un commercialista accessibile\n• ansia rispetto alla gestione fiscale`} style={{ minHeight: 90 }}/>
              </div>
              <div>
                <label className="ig-label">Obiettivi del percorso</label>
                <textarea className="ig-textarea" defaultValue={`• completare BMC entro 7 giorni\n• identificare un commercialista convenzionato\n• avviare pratica microcredito Sicilia\n• preparare business plan entro 30 giorni`} style={{ minHeight: 90 }}/>
              </div>
            </div>
          </Section>

          {/* 04 — Schede consigliate */}
          <Section num="04" icon={<I.Sparkle size={18} color="var(--ig-amber-700)"/>} title="Schede consigliate" subtitle="Suggerimenti automatici sulla base di interessi e bisogno · seleziona quelle consegnate">
            <div style={{ background: 'var(--ig-amber-50)', border: '1px solid var(--ig-amber-100)', borderRadius: 10, padding: 12, marginBottom: 14, display: 'flex', alignItems: 'center', gap: 10 }}>
              <I.Sparkle size={16} color="var(--ig-amber-700)"/>
              <span style={{ fontSize: 13, color: 'var(--ig-amber-800)' }}>4 schede sembrano in linea con il bisogno espresso. Le schede selezionate verranno inviate via email al termine del colloquio.</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {[
                ['IMP-2026-085', 'Resto al Sud · contributo a fondo perduto fino a 200.000€', 'impresa', 'Fare Impresa', 'Sempre aperta', true],
                ['IMP-2026-091', 'Microcredito Sicilia per giovani imprenditori', 'impresa', 'Fare Impresa', '60 giorni', true],
                ['FOR-2026-152', 'ITS Academy · Digital Marketing per imprese', 'formazione', 'Formazione', '14 giorni', false],
                ['IMP-2026-019', 'Selfiemployment Invitalia · finanziamento autoimpiego', 'impresa', 'Fare Impresa', 'Sempre aperta', true],
                ['LAV-2026-204', 'Garanzia Giovani Sicilia · 120 tirocini retribuiti', 'lavoro', 'Lavoro', '12 giorni', false],
              ].map(([id, t, ac, area, when, checked]) => (
                <div key={id} style={{
                  display: 'flex', alignItems: 'center', gap: 14, padding: 14,
                  border: `1px solid ${checked ? 'var(--ig-blue-300)' : 'var(--ig-border-soft)'}`,
                  background: checked ? 'var(--ig-blue-50)' : 'white',
                  borderRadius: 8,
                }}>
                  <span style={{
                    width: 20, height: 20, borderRadius: 4,
                    border: checked ? 'none' : '1.5px solid var(--ig-ink-300)',
                    background: checked ? 'var(--ig-blue-700)' : 'white',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    {checked && <I.Check size={14} color="white" strokeWidth={3}/>}
                  </span>
                  <span style={{ fontFamily: 'var(--ig-font-mono)', fontSize: 11, color: 'var(--ig-ink-500)' }}>{id}</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-900)' }}>{t}</div>
                  </div>
                  <span className={`ig-badge ig-badge--${ac}`} style={{ height: 22, fontSize: 11 }}>{area}</span>
                  <span style={{ fontSize: 12, color: 'var(--ig-ink-500)', minWidth: 80 }}>{when}</span>
                  <button className="ig-btn ig-btn--ghost ig-btn--sm ig-btn--icon" style={{ width: 28, height: 28 }}><I.Eye size={14}/></button>
                </div>
              ))}
            </div>
            <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ marginTop: 10, color: 'var(--ig-blue-700)' }}>+ Aggiungi un'altra scheda</button>
          </Section>

          {/* 05 — Azioni suggerite */}
          <Section num="05" icon={<I.Flag size={18} color="var(--ig-red-600)"/>} title="Azioni suggerite all'utente">
            <PillRow
              label="Quali azioni sono state proposte"
              options={[
                'Iscrizione CPI',
                'Candidatura offerta lavoro',
                'Iscrizione corso',
                'Prenotazione evento',
                'Avvio percorso impresa',
                'Invio a partner territoriale',
                'Iscrizione newsletter tematica',
                'Caricamento documenti',
                'Altro',
              ]}
              selected={['Avvio percorso impresa', 'Caricamento documenti', 'Invio a partner territoriale']}
            />
            <div style={{ marginTop: 16, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
              <Field label="Invio a partner" value="Camera di Commercio Enna · Sportello SUAP" hint="Verrà notificato a F. Bellomo · CCIAA"/>
              <Field label="Documenti richiesti" value="3 documenti da caricare entro 7 giorni"/>
            </div>
          </Section>

          {/* 06 — Follow-up */}
          <Section num="06" icon={<I.Clock size={18} color="var(--ig-blue-700)"/>} title="Follow-up">
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
              <Field label="Prossimo appuntamento" value="18 marzo 2026 · 10:00" hint="Sportello principale · Fare Impresa"/>
              <Field label="Operatore di riferimento" value="F. Bellomo (tutor impresa)"/>
              <Field label="Promemoria automatico" value="48 ore prima · email"/>
            </div>
            <div style={{ marginTop: 14 }}>
              <label className="ig-label">Note per il prossimo incontro</label>
              <textarea
                className="ig-textarea"
                defaultValue="Portare bozza BMC compilata. Verificare disponibilità commercialista convenzionato. Iniziare a impostare struttura business plan: analisi mercato locale + concorrenza."
                style={{ minHeight: 80 }}
              />
            </div>
          </Section>

          {/* 07 — Esito */}
          <Section num="07" icon={<I.Check size={18} color="var(--ig-green-700)"/>} title="Esito del colloquio">
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10 }}>
              {[
                ['Risolto', false, 'var(--ig-green-700)'],
                ['In carico · follow-up necessario', true, 'var(--ig-blue-700)'],
                ['Rinviato', false, 'var(--ig-amber-700)'],
                ['Chiuso', false, 'var(--ig-ink-500)'],
                ['Candidatura inviata', false, 'var(--ig-blue-700)'],
                ['Iscritto a corso', false, 'var(--ig-violet-700)'],
                ['Inviato a partner', true, 'var(--ig-teal-700)'],
                ['Percorso impresa avviato', true, 'var(--ig-teal-700)'],
              ].map(([label, sel, color]) => (
                <label key={label} style={{
                  display: 'flex', alignItems: 'center', gap: 10,
                  padding: 14, border: `1px solid ${sel ? color : 'var(--ig-border-soft)'}`,
                  background: sel ? `color-mix(in srgb, ${color} 6%, white)` : 'white',
                  borderRadius: 8, cursor: 'pointer',
                }}>
                  <span style={{
                    width: 18, height: 18, borderRadius: '50%',
                    border: `1.5px solid ${sel ? color : 'var(--ig-ink-300)'}`,
                    background: sel ? color : 'white',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    {sel && <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'white' }}/>}
                  </span>
                  <span style={{ fontSize: 13, fontWeight: 600, color: sel ? color : 'var(--ig-ink-700)' }}>{label}</span>
                </label>
              ))}
            </div>
          </Section>

          {/* Final actions */}
          <div style={{ background: 'var(--ig-ink-50)', border: '1px solid var(--ig-border-soft)', borderRadius: 12, padding: 22, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 20 }}>
            <div style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>
              <I.Info size={14} style={{ display: 'inline', verticalAlign: '-2px', marginRight: 4 }}/>
              Alla chiusura verranno: inviato il riepilogo email all'utente, creato l'appuntamento di follow-up, notificato il partner.
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="ig-btn ig-btn--ghost">Salva bozza</button>
              <button className="ig-btn ig-btn--secondary"><I.Send size={16}/> Invia riepilogo all'utente</button>
              <button className="ig-btn ig-btn--primary"><I.Check size={16}/> Chiudi colloquio</button>
            </div>
          </div>
        </div>

        {/* SIDEBAR · Storico colloqui */}
        <aside>
          <div className="ig-card" style={{ padding: 0, overflow: 'hidden', marginBottom: 16 }}>
            <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--ig-border-soft)' }}>
              <h3 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)' }}>Storico colloqui</h3>
              <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginTop: 2 }}>4 colloqui · ultimo 5 giorni fa</div>
            </div>
            <div>
              {[
                ['5 mar 2026', 'Idea food truck · BMC redatto', 'F. Bellomo · Impresa', 'In carico'],
                ['18 feb 2026', 'Orientamento autoimpiego', 'F. Bellomo · Impresa', 'Risolto'],
                ['12 gen 2026', 'Resto al Sud · primo orientamento', 'M. Greco · Estero', 'Rinviato'],
                ['08 nov 2025', 'Revisione CV e candidature', 'P. Rizzo · Lavoro', 'Risolto'],
              ].map(([d, t, op, esito], i) => (
                <div key={i} style={{ padding: '14px 20px', borderBottom: '1px solid var(--ig-border-soft)' }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>{d}</div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-900)', marginBottom: 2 }}>{t}</div>
                  <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginBottom: 6 }}>{op}</div>
                  <span style={{ fontSize: 11, fontWeight: 700, padding: '2px 8px', borderRadius: 4, background: esito === 'Risolto' ? 'var(--ig-green-100)' : esito === 'In carico' ? 'var(--ig-blue-100)' : 'var(--ig-amber-100)', color: esito === 'Risolto' ? 'var(--ig-green-700)' : esito === 'In carico' ? 'var(--ig-blue-800)' : 'var(--ig-amber-800)' }}>{esito}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="ig-card" style={{ padding: 20 }}>
            <h3 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)', marginBottom: 14 }}>Ticket collegati</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                ['#R-2841', 'Documentazione Resto al Sud', 'state-valid', 'Nuovo'],
                ['#R-2812', 'Domanda microcredito Sicilia', 'state-pub', 'Evaso'],
              ].map(([id, t, sc, lab]) => (
                <a key={id} href="#" style={{ display: 'flex', alignItems: 'center', gap: 10, padding: 10, border: '1px solid var(--ig-border-soft)', borderRadius: 8 }}>
                  <span style={{ fontFamily: 'var(--ig-font-mono)', fontSize: 11, color: 'var(--ig-ink-500)' }}>{id}</span>
                  <span style={{ flex: 1, fontSize: 13, color: 'var(--ig-ink-900)', fontWeight: 600 }}>{t}</span>
                  <span className={`ig-badge ig-badge--${sc}`} style={{ height: 20, fontSize: 10 }}>{lab}</span>
                </a>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </BackendShell>
  );
}

window.BackendColloquiScreen = BackendColloquiScreen;
