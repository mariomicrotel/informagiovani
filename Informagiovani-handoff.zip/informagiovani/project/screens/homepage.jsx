/* global React, IGIcons */
const I = IGIcons;

// =========================================================
// Shared header + footer used across public screens
// =========================================================
function PublicHeader({ active }) {
  const items = ['Opportunità', 'Lavoro', 'Formazione', 'Fare Impresa', 'Estero', 'Diritti', 'Eventi', 'Prenota colloquio'];
  return (
    <header style={{ background: 'white', borderBottom: '1px solid var(--ig-border-soft)', position: 'relative', zIndex: 2 }}>
      {/* Top utility bar */}
      <div style={{ background: 'var(--ig-blue-800)', color: 'rgba(255,255,255,0.78)', fontSize: 12 }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '8px 32px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', gap: 18, alignItems: 'center' }}>
            <span style={{ fontWeight: 600, color: 'white' }}>Comune di Enna</span>
            <span style={{ opacity: 0.5 }}>·</span>
            <span>Servizio per i giovani · città di Enna</span>
          </div>
          <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><I.Phone size={12}/> 0935 40 04 00</span>
            <span style={{ opacity: 0.5 }}>·</span>
            <a href="#" style={{ color: 'rgba(255,255,255,0.85)' }}>IT</a>
            <a href="#" style={{ color: 'rgba(255,255,255,0.5)' }}>EN</a>
            <span style={{ opacity: 0.5 }}>·</span>
            <a href="#" style={{ color: 'rgba(255,255,255,0.85)' }}>Accessibilità</a>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '20px 32px', display: 'flex', alignItems: 'center', gap: 48 }}>
        {/* Brand */}
        <a href="#" style={{ display: 'flex', alignItems: 'center', gap: 12, textDecoration: 'none' }}>
          <div style={{ width: 44, height: 44, borderRadius: 10, background: 'var(--ig-blue-700)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="26" height="26" viewBox="0 0 28 28" fill="none">
              <path d="M4 22 L14 4 L24 22 Z" stroke="white" strokeWidth="2.4" strokeLinejoin="round"/>
              <circle cx="14" cy="15" r="2.4" fill="var(--ig-amber-500)"/>
            </svg>
          </div>
          <div style={{ lineHeight: 1.1 }}>
            <div style={{ fontSize: 17, fontWeight: 800, color: 'var(--ig-ink-900)', letterSpacing: '-0.01em' }}>Informagiovani</div>
            <div style={{ fontSize: 12, color: 'var(--ig-amber-700)', fontWeight: 700, letterSpacing: '0.06em', marginTop: 2 }}>ENNA</div>
          </div>
        </a>

        {/* Nav */}
        <nav style={{ display: 'flex', gap: 4, flex: 1, justifyContent: 'center' }}>
          {items.map((it) => (
            <a key={it} href="#" style={{
              padding: '10px 14px',
              fontSize: 14,
              fontWeight: 600,
              color: it === active ? 'var(--ig-blue-700)' : 'var(--ig-ink-700)',
              borderRadius: 6,
              background: it === active ? 'var(--ig-blue-50)' : 'transparent',
              position: 'relative',
            }}>{it}</a>
          ))}
        </nav>

        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <a href="#" style={{ fontSize: 14, fontWeight: 600, color: 'var(--ig-ink-700)' }}>Area personale</a>
          <button className="ig-btn ig-btn--primary ig-btn--sm" style={{ height: 38 }}>
            <I.User size={15}/> Accedi
          </button>
        </div>
      </div>
    </header>
  );
}

function PublicFooter() {
  return (
    <footer style={{ background: 'var(--ig-blue-900)', color: 'rgba(255,255,255,0.7)', padding: '56px 0 28px' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 32px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr 1fr 1fr 1fr', gap: 48 }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
              <div style={{ width: 38, height: 38, borderRadius: 8, background: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="22" height="22" viewBox="0 0 28 28" fill="none">
                  <path d="M4 22 L14 4 L24 22 Z" stroke="var(--ig-blue-700)" strokeWidth="2.4" strokeLinejoin="round"/>
                  <circle cx="14" cy="15" r="2.4" fill="var(--ig-amber-500)"/>
                </svg>
              </div>
              <div>
                <div style={{ color: 'white', fontWeight: 800, fontSize: 16 }}>Informagiovani Enna</div>
                <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)' }}>Servizio del Comune di Enna</div>
              </div>
            </div>
            <p style={{ fontSize: 13, lineHeight: 1.6, color: 'rgba(255,255,255,0.65)', maxWidth: 280 }}>
              Punto di accesso unico alle opportunità di lavoro, formazione, impresa, estero e partecipazione civica per i giovani del territorio ennese.
            </p>
            <div style={{ marginTop: 20, fontSize: 13, color: 'rgba(255,255,255,0.6)', lineHeight: 1.7 }}>
              Piazza Garibaldi, 1 · 94100 Enna<br/>
              0935 40 04 00 · informagiovani@comune.enna.it<br/>
              Lun – Ven, 9:00 – 13:00 / 15:00 – 17:30
            </div>
          </div>

          {[
            ['Servizi', ['Opportunità', 'Lavoro', 'Formazione', 'Fare impresa', 'Estero & Mobilità', 'Eventi']],
            ['Strumenti', ['Prenota colloquio', 'Invia richiesta', 'Newsletter', 'Area personale', 'Partner', 'Open data']],
            ['Comune', ['Comune di Enna', 'Politiche giovanili', 'Albo pretorio', 'Trasparenza', 'PagoPA', 'IO']],
            ['Trasparenza', ['Privacy policy', 'Cookie policy', 'Accessibilità', 'Note legali', 'Mappa del sito', 'Contatti']],
          ].map(([title, links]) => (
            <div key={title}>
              <div style={{ color: 'white', fontWeight: 700, fontSize: 13, marginBottom: 14, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{title}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {links.map((l) => <a key={l} href="#" style={{ fontSize: 13, color: 'rgba(255,255,255,0.7)' }}>{l}</a>)}
              </div>
            </div>
          ))}
        </div>

        <div style={{ marginTop: 48, paddingTop: 24, borderTop: '1px solid rgba(255,255,255,0.12)', display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'rgba(255,255,255,0.5)' }}>
          <div>© 2026 Comune di Enna · C.F. 80000810863 · Tutti i diritti riservati</div>
          <div style={{ display: 'flex', gap: 18 }}>
            <a href="#" style={{ color: 'rgba(255,255,255,0.6)' }}>Dichiarazione di accessibilità</a>
            <a href="#" style={{ color: 'rgba(255,255,255,0.6)' }}>WCAG 2.1 AA</a>
            <a href="#" style={{ color: 'rgba(255,255,255,0.6)' }}>Mappa</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

// =========================================================
// Card opportunità · used on homepage + list page
// =========================================================
function OpportunityCard({ data, compact }) {
  return (
    <article className="ig-card" style={{ display: 'flex', flexDirection: 'column', padding: 22, gap: 14, position: 'relative' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10 }}>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          <span className={`ig-badge ig-badge--${data.areaClass}`}>{data.area}</span>
          {data.scadenza && <span className={`ig-badge ig-badge--scad-${data.urg}`}><I.Clock size={12}/>{data.scadenza}</span>}
        </div>
        <button title="Salva" style={{ background: 'transparent', border: 'none', color: 'var(--ig-ink-400)', padding: 4, cursor: 'pointer' }}>
          <I.Bookmark size={20}/>
        </button>
      </div>

      <h3 style={{ fontSize: 17, fontWeight: 700, lineHeight: 1.3, color: 'var(--ig-ink-900)' }}>{data.title}</h3>
      {!compact && <p style={{ fontSize: 14, color: 'var(--ig-ink-500)', lineHeight: 1.5 }}>{data.desc}</p>}

      <div style={{ display: 'flex', flexDirection: 'column', gap: 6, fontSize: 13, color: 'var(--ig-ink-500)', marginTop: 'auto' }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <I.Users size={14}/><span><strong style={{ color: 'var(--ig-ink-700)', fontWeight: 600 }}>{data.target}</strong></span>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <I.MapPin size={14}/><span>{data.territory}</span>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <I.ShieldChk size={14} color="var(--ig-green-700)"/><span>{data.source}</span>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8, paddingTop: 14, borderTop: '1px solid var(--ig-border-soft)' }}>
        <button className="ig-btn ig-btn--primary ig-btn--sm" style={{ flex: 1, justifyContent: 'center' }}>Dettagli <I.ArrowR size={14}/></button>
        <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ width: 38, padding: 0, justifyContent: 'center' }} title="Chiedi info"><I.Chat size={14}/></button>
      </div>
    </article>
  );
}

// =========================================================
// Homepage
// =========================================================
const heroOpps = [
  {
    area: 'Lavoro', areaClass: 'lavoro',
    title: 'Garanzia Giovani Sicilia · 120 tirocini retribuiti',
    desc: 'Tirocini extracurriculari di 6 mesi con indennità mensile di 500€ presso aziende del territorio ennese.',
    target: '18-29 anni · NEET', territory: 'Provincia di Enna',
    source: 'Regione Siciliana · ufficiale',
    scadenza: 'Scade tra 12 giorni', urg: 'soon',
  },
  {
    area: 'Fare Impresa', areaClass: 'impresa',
    title: 'Resto al Sud · agevolazioni per startup giovanili',
    desc: 'Fino a 200.000€ a fondo perduto per nuove attività imprenditoriali di under 56 nelle regioni del Mezzogiorno.',
    target: '18-55 anni · Aspiranti imprenditori', territory: 'Italia · Sud',
    source: 'Invitalia · ufficiale',
    scadenza: 'Sempre aperta', urg: 'ok',
  },
  {
    area: 'Estero & Mobilità', areaClass: 'estero',
    title: 'Erasmus+ Traineeship 2026/27 · tirocini in Europa',
    desc: 'Tirocini retribuiti da 2 a 12 mesi presso enti pubblici e imprese in tutta Europa, con borsa mensile fino a 700€.',
    target: 'Universitari · Neolaureati', territory: 'Europa',
    source: 'Agenzia Nazionale INDIRE · ufficiale',
    scadenza: 'Scade tra 3 giorni', urg: 'urgent',
  },
  {
    area: 'Servizio Civile', areaClass: 'civile',
    title: 'Servizio Civile Universale · 18 posti a Enna',
    desc: 'Progetti annuali nei settori educazione, ambiente e patrimonio culturale con assegno mensile di 507€.',
    target: '18-28 anni', territory: 'Enna città',
    source: 'Dipartimento Politiche Giovanili',
    scadenza: 'Scade tra 21 giorni', urg: 'soon',
  },
];

function HomepageScreen() {
  return (
    <div className="ig" style={{ width: 1440, background: 'var(--ig-bg)', minHeight: 3200 }}>
      <PublicHeader/>

      {/* ============ HERO ============ */}
      <section style={{
        background: 'linear-gradient(135deg, var(--ig-blue-700) 0%, var(--ig-blue-800) 70%, #08213f 100%)',
        color: 'white', position: 'relative', overflow: 'hidden',
      }}>
        {/* decorative shapes */}
        <svg width="600" height="600" viewBox="0 0 600 600" style={{ position: 'absolute', top: -160, right: -120, opacity: 0.08 }}>
          <circle cx="300" cy="300" r="280" stroke="white" strokeWidth="1.2" fill="none"/>
          <circle cx="300" cy="300" r="200" stroke="white" strokeWidth="1.2" fill="none"/>
          <circle cx="300" cy="300" r="120" stroke="white" strokeWidth="1.2" fill="none"/>
          <circle cx="300" cy="300" r="60" stroke="white" strokeWidth="1.2" fill="none"/>
        </svg>
        <div style={{ position: 'absolute', bottom: -120, left: -80, width: 320, height: 320, borderRadius: '50%', background: 'radial-gradient(circle, rgba(232,169,58,0.18) 0%, transparent 65%)' }}/>

        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '88px 32px 96px', position: 'relative' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 80, alignItems: 'center' }}>
            <div>
              <div style={{
                display: 'inline-flex', alignItems: 'center', gap: 8,
                background: 'rgba(232,169,58,0.18)', color: 'var(--ig-amber-500)',
                padding: '6px 12px', borderRadius: 999,
                fontSize: 12, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase',
                marginBottom: 24,
              }}>
                <I.Sparkle size={12}/> Servizio del Comune di Enna
              </div>
              <h1 style={{ fontSize: 56, fontWeight: 800, color: 'white', letterSpacing: '-0.025em', lineHeight: 1.05, marginBottom: 22 }}>
                Il punto di accesso alle <span className="ig-serif" style={{ color: 'var(--ig-amber-500)', fontWeight: 500, fontStyle: 'italic' }}>opportunità</span> per i giovani di Enna
              </h1>
              <p style={{ fontSize: 19, color: 'rgba(255,255,255,0.78)', lineHeight: 1.5, maxWidth: 600, marginBottom: 36 }}>
                Lavoro, formazione, impresa, estero, concorsi, eventi e servizi utili — verificati dagli operatori dello sportello, in un&apos;unica piattaforma.
              </p>

              {/* Search */}
              <div style={{
                background: 'white', borderRadius: 14, padding: 8,
                display: 'flex', gap: 6, alignItems: 'center',
                boxShadow: '0 24px 64px rgba(6,26,50,0.35)', maxWidth: 640,
              }}>
                <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 10, padding: '0 16px' }}>
                  <I.Search size={20} color="var(--ig-ink-400)"/>
                  <input
                    style={{ flex: 1, border: 'none', outline: 'none', fontSize: 16, padding: '14px 0', color: 'var(--ig-ink-900)', background: 'transparent', fontFamily: 'inherit' }}
                    placeholder="Cerca lavoro, corsi, concorsi, bonus, eventi..."
                  />
                </div>
                <button className="ig-btn ig-btn--primary" style={{ height: 48 }}>Cerca <I.ArrowR size={16}/></button>
              </div>

              <div style={{ display: 'flex', gap: 14, marginTop: 22, fontSize: 13, color: 'rgba(255,255,255,0.65)', alignItems: 'center' }}>
                <span>Ricerche popolari:</span>
                {['Servizio civile', 'Erasmus+', 'Resto al Sud', 'Concorsi Enna', 'Bonus cultura'].map(s => (
                  <a key={s} href="#" style={{ color: 'rgba(255,255,255,0.85)', padding: '4px 10px', border: '1px solid rgba(255,255,255,0.2)', borderRadius: 999, fontSize: 12 }}>{s}</a>
                ))}
              </div>

              <div style={{ marginTop: 36 }}>
                <button className="ig-btn ig-btn--accent ig-btn--lg" style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.25)', color: 'white' }}>
                  <I.Calendar size={18}/> Prenota un colloquio
                </button>
              </div>
            </div>

            {/* Numbers card */}
            <div style={{ background: 'rgba(255,255,255,0.06)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 20, padding: 32 }}>
              <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.14em', color: 'var(--ig-amber-500)', textTransform: 'uppercase', marginBottom: 24 }}>Lo sportello in numeri</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
                {[
                  ['487', 'Opportunità attive'],
                  ['2.140', 'Giovani registrati'],
                  ['12', 'Operatori dedicati'],
                  ['98%', 'Risposta entro 48h'],
                ].map(([n, l]) => (
                  <div key={l}>
                    <div className="ig-num" style={{ fontSize: 38, fontWeight: 800, color: 'white', letterSpacing: '-0.02em', lineHeight: 1 }}>{n}</div>
                    <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.65)', marginTop: 6 }}>{l}</div>
                  </div>
                ))}
              </div>
              <div style={{ marginTop: 24, paddingTop: 20, borderTop: '1px solid rgba(255,255,255,0.12)', fontSize: 12, color: 'rgba(255,255,255,0.55)', display: 'flex', alignItems: 'center', gap: 6 }}>
                <I.Dot size={8} color="var(--ig-green-600)"/>
                Sportello aperto ora · prossimo slot libero alle 11:30
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============ PERCORSI RAPIDI ============ */}
      <section style={{ maxWidth: 1280, margin: '0 auto', padding: '80px 32px 0' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 32 }}>
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.14em', color: 'var(--ig-teal-700)', textTransform: 'uppercase', marginBottom: 10 }}>Da dove vuoi partire?</div>
            <h2 style={{ fontSize: 36, fontWeight: 700, letterSpacing: '-0.02em' }}>Percorsi rapidi</h2>
          </div>
          <a href="#" style={{ fontSize: 14, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 6 }}>Esplora tutti i servizi <I.ArrowR size={14}/></a>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 18 }}>
          {[
            { ico: <I.Briefcase size={24}/>, t: 'Cerco lavoro', d: 'Offerte, CPI, tirocini retribuiti e accompagnamento alla candidatura.', c: 'var(--ig-blue-700)', bg: 'var(--ig-blue-50)' },
            { ico: <I.GradCap size={24}/>, t: 'Voglio formarmi', d: 'Corsi, borse di studio, ITS, dottorati e percorsi professionalizzanti.', c: 'var(--ig-violet-700)', bg: '#f3eefc' },
            { ico: <I.Bulb size={24}/>, t: 'Voglio aprire un\u2019impresa', d: 'Business plan, microcredito, bandi giovani e accompagnamento dedicato.', c: 'var(--ig-teal-700)', bg: 'var(--ig-teal-50)' },
            { ico: <I.Globe size={24}/>, t: 'Voglio andare all\u2019estero', d: 'Erasmus+, Corpo Europeo di Solidarietà, work&travel e mobilità internazionale.', c: 'var(--ig-amber-700)', bg: 'var(--ig-amber-50)' },
            { ico: <I.Award size={24}/>, t: 'Cerco un concorso', d: 'Concorsi pubblici di Comune, Regione, Stato ed enti partecipati a misura di NEET.', c: '#1b3a8a', bg: '#e8efff' },
            { ico: <I.Heart size={24}/>, t: 'Ho bisogno di un servizio', d: 'Salute, casa, diritti, supporto psicologico, residenza, ISEE e bonus.', c: '#a13564', bg: '#fbe9f0' },
          ].map((p, idx) => (
            <a key={p.t} href="#" className="ig-card" style={{
              padding: 28, display: 'flex', flexDirection: 'column', gap: 14,
              border: '1px solid var(--ig-border-soft)', transition: 'all .2s',
              textDecoration: 'none', color: 'inherit',
              minHeight: 220,
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div style={{
                  width: 52, height: 52, borderRadius: 12,
                  background: p.bg, color: p.c,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>{p.ico}</div>
                <div style={{ fontSize: 12, fontFamily: 'var(--ig-font-mono)', color: 'var(--ig-ink-400)' }}>0{idx+1}</div>
              </div>
              <h3 style={{ fontSize: 22, fontWeight: 700, lineHeight: 1.2, color: 'var(--ig-ink-900)' }}>{p.t}</h3>
              <p style={{ fontSize: 14, color: 'var(--ig-ink-500)', lineHeight: 1.5, flex: 1 }}>{p.d}</p>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 14, fontWeight: 600, color: p.c }}>
                Esplora <I.ArrowR size={14}/>
              </div>
            </a>
          ))}
        </div>
      </section>

      {/* ============ OPPORTUNITÀ IN EVIDENZA ============ */}
      <section style={{ maxWidth: 1280, margin: '0 auto', padding: '80px 32px 0' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 32 }}>
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.14em', color: 'var(--ig-teal-700)', textTransform: 'uppercase', marginBottom: 10 }}>Aggiornate dagli operatori</div>
            <h2 style={{ fontSize: 36, fontWeight: 700, letterSpacing: '-0.02em' }}>Opportunità in evidenza</h2>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            {['Tutte', 'Lavoro', 'Formazione', 'Impresa', 'Estero'].map((f, i) => (
              <button key={f} style={{
                height: 36, padding: '0 14px',
                border: '1px solid var(--ig-border)',
                background: i === 0 ? 'var(--ig-ink-900)' : 'white',
                color: i === 0 ? 'white' : 'var(--ig-ink-700)',
                borderColor: i === 0 ? 'var(--ig-ink-900)' : 'var(--ig-border)',
                borderRadius: 6, fontSize: 13, fontWeight: 600, cursor: 'pointer',
              }}>{f}</button>
            ))}
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 18 }}>
          {heroOpps.map((o, i) => <OpportunityCard key={i} data={o} compact/>)}
        </div>
      </section>

      {/* ============ SCADENZE + EVENTI (split) ============ */}
      <section style={{ maxWidth: 1280, margin: '0 auto', padding: '80px 32px 0' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 28 }}>
          {/* Scadenze */}
          <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ padding: '22px 26px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{ width: 36, height: 36, borderRadius: 8, background: 'var(--ig-amber-100)', color: 'var(--ig-amber-700)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <I.Clock size={18}/>
                </div>
                <div>
                  <h3 style={{ fontSize: 18, fontWeight: 700 }}>Scadenze imminenti</h3>
                  <div style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>Non perdere queste opportunità</div>
                </div>
              </div>
              <a href="#" style={{ fontSize: 13, fontWeight: 600 }}>Tutte →</a>
            </div>
            <div>
              {[
                ['Erasmus+ Traineeship 2026/27', 'estero', 'Estero', 'urgent', '3 giorni', '17 mar 2026'],
                ['Bando Caro Energia Famiglie', 'diritti', 'Diritti', 'urgent', '5 giorni', '19 mar 2026'],
                ['Bonus Cultura 18app residui', 'cultura', 'Cultura', 'soon', '12 giorni', '26 mar 2026'],
                ['Tirocini extracurriculari ANPAL', 'lavoro', 'Lavoro', 'soon', '14 giorni', '28 mar 2026'],
                ['Concorso Istruttore Amm.vo Comune', 'concorso', 'Concorso', 'soon', '21 giorni', '4 apr 2026'],
              ].map(([title, ac, area, urg, when, date], i) => (
                <div key={title} style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '18px 26px', borderBottom: i < 4 ? '1px solid var(--ig-border-soft)' : 'none' }}>
                  <div style={{
                    width: 56, textAlign: 'center', padding: '8px 0', borderRadius: 8,
                    background: urg === 'urgent' ? 'var(--ig-red-100)' : 'var(--ig-amber-100)',
                    color: urg === 'urgent' ? 'var(--ig-red-700)' : 'var(--ig-amber-800)',
                    flex: '0 0 auto',
                  }}>
                    <div className="ig-num" style={{ fontSize: 20, fontWeight: 800, lineHeight: 1 }}>{when.split(' ')[0]}</div>
                    <div style={{ fontSize: 10, fontWeight: 700, marginTop: 2, textTransform: 'uppercase', letterSpacing: '0.05em' }}>giorni</div>
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--ig-ink-900)', marginBottom: 4 }}>{title}</div>
                    <div style={{ display: 'flex', gap: 10, fontSize: 12, color: 'var(--ig-ink-500)', alignItems: 'center' }}>
                      <span className={`ig-badge ig-badge--${ac}`} style={{ height: 20, fontSize: 11 }}>{area}</span>
                      <span>Scade il {date}</span>
                    </div>
                  </div>
                  <I.ChevR size={16} color="var(--ig-ink-400)"/>
                </div>
              ))}
            </div>
          </div>

          {/* Eventi */}
          <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ padding: '22px 26px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{ width: 36, height: 36, borderRadius: 8, background: 'var(--ig-teal-100)', color: 'var(--ig-teal-700)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <I.Calendar size={18}/>
                </div>
                <div>
                  <h3 style={{ fontSize: 18, fontWeight: 700 }}>Eventi prossimi</h3>
                  <div style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>Sportello e partner del territorio</div>
                </div>
              </div>
              <a href="#" style={{ fontSize: 13, fontWeight: 600 }}>Calendario →</a>
            </div>
            <div>
              {[
                { d: 18, m: 'MAR', t: 'Open day Erasmus+ a Enna', l: 'In presenza · Sala Cerere', s: '14 posti su 30', cat: 'estero' },
                { d: 22, m: 'MAR', t: 'Workshop: scrivi il tuo curriculum', l: 'Sportello Informagiovani', s: '8 posti su 12', cat: 'lavoro' },
                { d: 26, m: 'MAR', t: 'Costruisci la tua idea di impresa', l: 'Online · Zoom', s: '32 posti su 50', cat: 'impresa' },
                { d: 3, m: 'APR', t: 'Resto al Sud: come candidarsi', l: 'Camera di Commercio Enna', s: 'Posti limitati', cat: 'impresa' },
              ].map((e) => (
                <div key={e.t} style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '18px 26px', borderBottom: '1px solid var(--ig-border-soft)' }}>
                  <div style={{
                    width: 56, textAlign: 'center', padding: '6px 0', borderRadius: 8,
                    background: 'var(--ig-blue-50)', color: 'var(--ig-blue-700)',
                    border: '1px solid var(--ig-blue-100)', flex: '0 0 auto',
                  }}>
                    <div className="ig-num" style={{ fontSize: 22, fontWeight: 800, lineHeight: 1 }}>{e.d}</div>
                    <div style={{ fontSize: 10, fontWeight: 700, marginTop: 2 }}>{e.m}</div>
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--ig-ink-900)', marginBottom: 4 }}>{e.t}</div>
                    <div style={{ display: 'flex', gap: 10, fontSize: 12, color: 'var(--ig-ink-500)', alignItems: 'center', flexWrap: 'wrap' }}>
                      <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><I.MapPin size={11}/>{e.l}</span>
                      <span>·</span>
                      <span style={{ color: 'var(--ig-green-700)', fontWeight: 600 }}><I.Dot size={6} color="var(--ig-green-600)"/> {e.s}</span>
                    </div>
                  </div>
                  <button className="ig-btn ig-btn--secondary ig-btn--sm">Iscriviti</button>
                </div>
              ))}
              <div style={{ padding: '20px 26px', textAlign: 'center', background: 'var(--ig-ink-50)' }}>
                <a href="#" style={{ fontSize: 14, fontWeight: 600 }}>Vedi tutti gli eventi del mese →</a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============ COME FUNZIONA ============ */}
      <section style={{ background: 'white', marginTop: 80, padding: '80px 0', borderTop: '1px solid var(--ig-border-soft)', borderBottom: '1px solid var(--ig-border-soft)' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 32px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: 64, alignItems: 'start' }}>
            <div>
              <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.14em', color: 'var(--ig-teal-700)', textTransform: 'uppercase', marginBottom: 14 }}>In 4 passi</div>
              <h2 style={{ fontSize: 36, fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 18, lineHeight: 1.15 }}>
                Come funziona il <span className="ig-serif" style={{ fontStyle: 'italic', fontWeight: 500, color: 'var(--ig-blue-700)' }}>servizio</span>
              </h2>
              <p style={{ fontSize: 16, color: 'var(--ig-ink-500)', lineHeight: 1.6, marginBottom: 28 }}>
                Da un&apos;idea generica a un percorso costruito su misura con i tuoi operatori dello sportello. Tutto in un&apos;unica piattaforma, gratuita e pubblica.
              </p>
              <button className="ig-btn ig-btn--primary ig-btn--lg">Crea il tuo profilo <I.ArrowR size={18}/></button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              {[
                ['01', 'Cerca un\u2019opportunità', 'Esplora schede informative su lavoro, corsi, concorsi e bandi filtrate per età, interessi e territorio.', <I.Search size={20}/>],
                ['02', 'Salva ciò che ti interessa', 'Tieni traccia di scadenze, requisiti e documenti. Ricevi promemoria automatici prima della chiusura.', <I.Bookmark size={20}/>],
                ['03', 'Prenota un colloquio', 'Parla con un operatore in presenza, in videochiamata o al telefono. Lo sportello è gratuito.', <I.Calendar size={20}/>],
                ['04', 'Costruisci il tuo percorso', 'Insieme agli operatori definisci obiettivi, azioni e tappe. Tieni tutto nella tua area personale.', <I.Flag size={20}/>],
              ].map(([n, t, d, ico]) => (
                <div key={n} style={{ display: 'grid', gridTemplateColumns: '56px 1fr', gap: 20, padding: '18px 0', borderBottom: '1px solid var(--ig-border-soft)' }}>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
                    <div className="ig-num" style={{ fontSize: 22, fontWeight: 800, color: 'var(--ig-blue-700)', fontFamily: 'var(--ig-font-mono)', letterSpacing: '-0.02em' }}>{n}</div>
                    <div style={{ color: 'var(--ig-ink-400)' }}>{ico}</div>
                  </div>
                  <div>
                    <h4 style={{ fontSize: 19, fontWeight: 700, marginBottom: 6, color: 'var(--ig-ink-900)' }}>{t}</h4>
                    <p style={{ fontSize: 15, color: 'var(--ig-ink-500)', lineHeight: 1.55 }}>{d}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ============ CTA ORIENTAMENTO ============ */}
      <section style={{ padding: '80px 0' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 32px' }}>
          <div style={{
            background: 'linear-gradient(120deg, var(--ig-teal-800) 0%, var(--ig-teal-700) 60%, var(--ig-teal-600) 100%)',
            borderRadius: 24, padding: '64px 56px', color: 'white', position: 'relative', overflow: 'hidden',
          }}>
            <svg width="400" height="400" viewBox="0 0 400 400" style={{ position: 'absolute', top: -120, right: -60, opacity: 0.18 }}>
              <circle cx="200" cy="200" r="180" stroke="white" strokeWidth="0.8" fill="none"/>
              <circle cx="200" cy="200" r="120" stroke="white" strokeWidth="0.8" fill="none"/>
              <circle cx="200" cy="200" r="60" stroke="white" strokeWidth="0.8" fill="none"/>
            </svg>
            <div style={{ position: 'relative', display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 64, alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.14em', color: 'rgba(255,255,255,0.7)', textTransform: 'uppercase', marginBottom: 14 }}>Orientamento personalizzato</div>
                <h2 style={{ fontSize: 44, fontWeight: 700, color: 'white', letterSpacing: '-0.02em', lineHeight: 1.1, marginBottom: 18 }}>
                  Hai bisogno di orientamento personalizzato?
                </h2>
                <p style={{ fontSize: 17, color: 'rgba(255,255,255,0.82)', lineHeight: 1.55, maxWidth: 540 }}>
                  Parla con uno dei 12 operatori dello sportello. Insieme analizziamo la tua situazione, definiamo un percorso e ti accompagniamo nelle candidature.
                </p>
                <div style={{ display: 'flex', gap: 12, marginTop: 32 }}>
                  <button className="ig-btn ig-btn--lg" style={{ background: 'white', color: 'var(--ig-teal-800)' }}>
                    <I.Calendar size={18}/> Prenota un colloquio
                  </button>
                  <button className="ig-btn ig-btn--lg" style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.3)', color: 'white' }}>
                    <I.Chat size={18}/> Invia una richiesta
                  </button>
                </div>
              </div>
              <div style={{ background: 'rgba(255,255,255,0.08)', backdropFilter: 'blur(6px)', borderRadius: 16, padding: 28, border: '1px solid rgba(255,255,255,0.15)' }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: 'rgba(255,255,255,0.65)', marginBottom: 16, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Modalità colloquio</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                  {[
                    [<I.User size={18}/>, 'In presenza', 'Sportello in Piazza Garibaldi, 1'],
                    [<I.Video size={18}/>, 'Videochiamata', 'Google Meet o Zoom · 30 min'],
                    [<I.Phone size={18}/>, 'Telefono', 'Su appuntamento, 9:00 - 17:30'],
                    [<I.Mail size={18}/>, 'Email', 'Risposta entro 48 ore lavorative'],
                  ].map(([ico, t, d]) => (
                    <div key={t} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                      <div style={{ width: 40, height: 40, borderRadius: 8, background: 'rgba(255,255,255,0.12)', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{ico}</div>
                      <div>
                        <div style={{ color: 'white', fontWeight: 600, fontSize: 15 }}>{t}</div>
                        <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.65)' }}>{d}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <PublicFooter/>
    </div>
  );
}

window.HomepageScreen = HomepageScreen;
window.PublicHeader = PublicHeader;
window.PublicFooter = PublicFooter;
window.OpportunityCard = OpportunityCard;
