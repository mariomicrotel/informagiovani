/* global React, IGIcons, BackendShell, PageHeader */
const I = IGIcons;

const schedeRows = [
  ['ERA-2026-117', 'Erasmus+ Traineeship 2026/27 · tirocini retribuiti in Europa', 'estero', 'Estero & Mobilità', 'Universitari', 'Europa', 'INDIRE', 'ufficiale', '17 mar 2026', 'urgent', 'state-pub', 'Pubblicata', 'M. Greco', 'ieri 17:22'],
  ['SCN-2026-022', 'Servizio Civile Universale 2026 · 18 posti a Enna', 'civile', 'Servizio Civile', '18–28 anni', 'Enna città', 'Dip. Politiche Giovanili', 'ufficiale', '21 mar 2026', 'urgent', 'state-review', 'Da verificare', 'M. Greco', '2h fa'],
  ['LAV-2026-204', 'Garanzia Giovani Sicilia · 120 tirocini retribuiti', 'lavoro', 'Lavoro', 'NEET', 'Prov. Enna', 'Regione Siciliana', 'ufficiale', '28 mar 2026', 'soon', 'state-pub', 'Pubblicata', 'P. Rizzo', '1g fa'],
  ['IMP-2026-085', 'Resto al Sud · contributo a fondo perduto fino a 200.000€', 'impresa', 'Fare Impresa', 'Aspiranti imprenditori', 'Italia · Sud', 'Invitalia', 'ufficiale', 'Sempre aperta', 'ok', 'state-pub', 'Pubblicata', 'F. Bellomo', '3g fa'],
  ['CON-2026-046', 'Concorso · 4 Istruttori Amm.vi · Comune di Enna', 'concorso', 'Concorsi', 'Diplomati', 'Enna città', 'Comune di Enna', 'ufficiale', '4 apr 2026', 'soon', 'state-valid', 'Validata', 'L. Marino', '5g fa'],
  ['FOR-2026-152', 'ITS Academy Sicilia · Tecnico superiore Digital Marketing', 'formazione', 'Formazione', 'Diplomati', 'Sicilia', 'Fondazione ITS Steve Jobs', 'partner', '30 mar 2026', 'soon', 'state-update', 'Da aggiornare', 'P. Rizzo', '7g fa'],
  ['CUL-2025-198', 'Bonus Cultura 18app · residui 2025', 'cultura', 'Cultura', '18 anni', 'Italia', 'MiC', 'ufficiale', '26 mar 2026', 'soon', 'state-pub', 'Pubblicata', 'L. Marino', '4g fa'],
  ['DIR-2026-014', 'Bando Caro Energia · sostegno alle famiglie', 'diritti', 'Diritti', 'Famiglie ISEE', 'Enna città', 'Comune di Enna', 'ufficiale', '19 mar 2026', 'urgent', 'state-pub', 'Pubblicata', 'F. Bellomo', '6h fa'],
  ['IMP-2026-091', 'Microcredito Sicilia per giovani imprenditori', 'impresa', 'Fare Impresa', '18–35 anni', 'Sicilia', 'IRFIS Sicilia', 'ufficiale', '15 mag 2026', 'ok', 'state-review', 'Da verificare', 'F. Bellomo', '8h fa'],
  ['LAV-2025-187', 'Tirocini extracurriculari ANPAL · ciclo 2025', 'lavoro', 'Lavoro', 'Disoccupati', 'Italia', 'ANPAL', 'ufficiale', '15 feb 2026', '', 'state-exp', 'Scaduta', 'P. Rizzo', '30g fa'],
  ['EVT-2026-009', 'Open Day Erasmus+ a Enna', 'estero', 'Estero & Mobilità', '18–30 anni', 'Enna città', 'Informagiovani', 'ufficiale', '18 mar 2026', 'soon', 'state-draft', 'Bozza', 'M. Greco', '12h fa'],
  ['FOR-2026-148', 'Borse di studio MAECI per cittadini stranieri', 'formazione', 'Formazione', 'Italiani all\u2019estero', 'Italia', 'MAECI', 'ufficiale', '30 apr 2026', 'soon', 'state-pub', 'Pubblicata', 'L. Marino', '2g fa'],
];

function FilterPill({ label, value, active }) {
  return (
    <button style={{
      display: 'inline-flex', alignItems: 'center', gap: 8,
      height: 36, padding: '0 12px',
      borderRadius: 6,
      border: `1px solid ${active ? 'var(--ig-blue-700)' : 'var(--ig-border)'}`,
      background: active ? 'var(--ig-blue-50)' : 'white',
      color: active ? 'var(--ig-blue-700)' : 'var(--ig-ink-700)',
      fontSize: 13, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer',
    }}>
      {label}
      <span style={{ color: active ? 'var(--ig-blue-700)' : 'var(--ig-ink-500)' }}>{value}</span>
      <I.ChevD size={14}/>
    </button>
  );
}

function BackendSchedeScreen() {
  return (
    <BackendShell active="Schede informative" breadcrumb={['Console', 'Contenuti', 'Schede informative']} height={1700}>
      <PageHeader
        title="Schede informative"
        subtitle="487 schede totali · 12 in coda di verifica · 24 in scadenza nei prossimi 14 giorni"
        actions={<>
          <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Download size={14}/> Esporta CSV</button>
          <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Link size={14}/> Importa da fonte</button>
          <button className="ig-btn ig-btn--primary ig-btn--sm"><I.Plus size={14}/> Nuova scheda</button>
        </>}
        tabs={['Tutte · 487', 'Pubblicate · 412', 'Da verificare · 12', 'Bozze · 24', 'In scadenza · 24', 'Scadute · 18', 'Archiviate · 9']}
        activeTab="Tutte · 487"
      />

      {/* Toolbar */}
      <div style={{ padding: '18px 32px', background: 'white', borderBottom: '1px solid var(--ig-border-soft)' }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <div style={{ flex: 1, maxWidth: 360, position: 'relative' }}>
            <input className="ig-input" placeholder="Cerca per titolo, ID, contenuto…" style={{ height: 38, paddingLeft: 38, fontSize: 14 }}/>
            <div style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)' }}>
              <I.Search size={16} color="var(--ig-ink-400)"/>
            </div>
          </div>
          <FilterPill label="Area:" value="Tutte" active={false}/>
          <FilterPill label="Target:" value="Tutti" active={false}/>
          <FilterPill label="Territorio:" value="Tutti" active={false}/>
          <FilterPill label="Stato:" value="Tutti" active={false}/>
          <FilterPill label="Scadenza:" value="Qualsiasi" active={false}/>
          <FilterPill label="Fonte:" value="Tutte" active={false}/>
          <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ color: 'var(--ig-blue-700)' }}>+ Filtro avanzato</button>
        </div>
      </div>

      {/* Bulk actions bar */}
      <div style={{ padding: '12px 32px', background: 'var(--ig-blue-700)', color: 'white', display: 'flex', alignItems: 'center', gap: 12 }}>
        <span style={{
          width: 18, height: 18, borderRadius: 4, background: 'white',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <I.Check size={12} color="var(--ig-blue-700)" strokeWidth={3}/>
        </span>
        <span style={{ fontSize: 13, fontWeight: 600 }}>3 schede selezionate</span>
        <div style={{ width: 1, height: 18, background: 'rgba(255,255,255,0.25)', margin: '0 4px' }}/>
        <button className="ig-btn ig-btn--sm" style={{ background: 'rgba(255,255,255,0.15)', color: 'white', height: 30 }}>Pubblica</button>
        <button className="ig-btn ig-btn--sm" style={{ background: 'rgba(255,255,255,0.15)', color: 'white', height: 30 }}>Archivia</button>
        <button className="ig-btn ig-btn--sm" style={{ background: 'rgba(255,255,255,0.15)', color: 'white', height: 30 }}>Segna da aggiornare</button>
        <button className="ig-btn ig-btn--sm" style={{ background: 'rgba(255,255,255,0.15)', color: 'white', height: 30 }}>Assegna fonte</button>
        <button className="ig-btn ig-btn--sm" style={{ background: 'rgba(255,255,255,0.15)', color: 'white', height: 30 }}>Esporta CSV</button>
        <button style={{ marginLeft: 'auto', background: 'none', border: 'none', color: 'white', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>Deseleziona tutto ×</button>
      </div>

      {/* TABLE */}
      <div style={{ padding: '0 32px 32px', flex: 1 }}>
        <div className="ig-card" style={{ padding: 0, overflow: 'hidden', marginTop: 24 }}>
          {/* head */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '36px 110px 1fr 130px 110px 130px 110px 130px 110px 80px',
            gap: 14, padding: '12px 18px',
            background: 'var(--ig-ink-50)', borderBottom: '1px solid var(--ig-border-soft)',
            fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.05em',
          }}>
            <span>
              <span style={{ width: 18, height: 18, borderRadius: 4, border: '1.5px solid var(--ig-ink-300)', display: 'inline-block' }}/>
            </span>
            <span>ID</span>
            <span>Titolo</span>
            <span>Area</span>
            <span>Target</span>
            <span>Fonte</span>
            <span>Scadenza</span>
            <span>Stato</span>
            <span>Aggiornato</span>
            <span style={{ textAlign: 'right' }}>Azioni</span>
          </div>

          {schedeRows.map((r, i) => (
            <div key={r[0]} style={{
              display: 'grid',
              gridTemplateColumns: '36px 110px 1fr 130px 110px 130px 110px 130px 110px 80px',
              gap: 14, padding: '14px 18px',
              borderBottom: i < schedeRows.length - 1 ? '1px solid var(--ig-border-soft)' : 'none',
              alignItems: 'center', minHeight: 56,
              background: i === 0 || i === 2 || i === 4 ? 'rgba(31,90,168,0.03)' : 'white',
            }}>
              <span>
                <span style={{
                  width: 18, height: 18, borderRadius: 4,
                  border: i === 0 || i === 2 || i === 4 ? 'none' : '1.5px solid var(--ig-ink-300)',
                  background: i === 0 || i === 2 || i === 4 ? 'var(--ig-primary)' : 'white',
                  display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  {(i === 0 || i === 2 || i === 4) && <I.Check size={12} color="white" strokeWidth={3}/>}
                </span>
              </span>
              <span style={{ fontFamily: 'var(--ig-font-mono)', fontSize: 11, color: 'var(--ig-ink-500)' }}>{r[0]}</span>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-900)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r[1]}</div>
                <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', marginTop: 2 }}>Autore: {r[12]}</div>
              </div>
              <span className={`ig-badge ig-badge--${r[2]}`} style={{ height: 22, fontSize: 11 }}>{r[3]}</span>
              <span style={{ fontSize: 12, color: 'var(--ig-ink-700)' }}>{r[4]}</span>
              <div>
                <div style={{ fontSize: 12, color: 'var(--ig-ink-700)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{r[6]}</div>
                <span className={`ig-badge ig-badge--src-${r[7]}`} style={{ height: 18, fontSize: 10, padding: '0 6px' }}>
                  {r[7] === 'ufficiale' ? 'Ufficiale' : r[7] === 'partner' ? 'Partner' : 'Verificata'}
                </span>
              </div>
              <div>
                <div style={{ fontSize: 12, fontWeight: 600, color: r[9] === 'urgent' ? 'var(--ig-red-700)' : r[9] === 'soon' ? 'var(--ig-amber-800)' : r[9] === 'ok' ? 'var(--ig-green-700)' : 'var(--ig-ink-400)' }}>{r[8]}</div>
                {r[9] && (
                  <div style={{ fontSize: 11, color: 'var(--ig-ink-400)' }}>{r[9] === 'urgent' ? 'critica' : r[9] === 'soon' ? 'a breve' : r[9] === 'ok' ? 'continua' : 'scaduta'}</div>
                )}
              </div>
              <span className={`ig-badge ig-badge--${r[10]}`} style={{ height: 22, fontSize: 11 }}>{r[11]}</span>
              <span style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}>{r[13]}</span>
              <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                <button className="ig-btn ig-btn--ghost ig-btn--sm ig-btn--icon" style={{ width: 28, height: 28 }} title="Anteprima"><I.Eye size={14}/></button>
                <button className="ig-btn ig-btn--ghost ig-btn--sm ig-btn--icon" style={{ width: 28, height: 28 }} title="Modifica"><I.Edit size={14}/></button>
              </div>
            </div>
          ))}

          {/* Pagination */}
          <div style={{ padding: '14px 18px', borderTop: '1px solid var(--ig-border-soft)', background: 'var(--ig-ink-50)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>1–12 di 487 schede · <a href="#">25 per pagina ▾</a></div>
            <div style={{ display: 'flex', gap: 4 }}>
              <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 30, width: 30, padding: 0, justifyContent: 'center' }}><I.ArrowL size={12}/></button>
              <button style={{ width: 30, height: 30, border: 'none', background: 'var(--ig-ink-900)', color: 'white', borderRadius: 6, fontWeight: 700, cursor: 'pointer', fontSize: 12 }}>1</button>
              <button style={{ width: 30, height: 30, border: 'none', background: 'transparent', borderRadius: 6, fontWeight: 600, cursor: 'pointer', fontSize: 12, color: 'var(--ig-ink-700)' }}>2</button>
              <button style={{ width: 30, height: 30, border: 'none', background: 'transparent', borderRadius: 6, fontWeight: 600, cursor: 'pointer', fontSize: 12, color: 'var(--ig-ink-700)' }}>3</button>
              <span style={{ padding: '0 6px', alignSelf: 'center', color: 'var(--ig-ink-400)' }}>…</span>
              <button style={{ width: 30, height: 30, border: 'none', background: 'transparent', borderRadius: 6, fontWeight: 600, cursor: 'pointer', fontSize: 12, color: 'var(--ig-ink-700)' }}>20</button>
              <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 30, width: 30, padding: 0, justifyContent: 'center' }}><I.ArrowR size={12}/></button>
            </div>
          </div>
        </div>
      </div>
    </BackendShell>
  );
}

window.BackendSchedeScreen = BackendSchedeScreen;
