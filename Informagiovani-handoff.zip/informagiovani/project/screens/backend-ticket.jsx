/* global React, IGIcons, BackendShell, PageHeader */
const I = IGIcons;

const cols = [
  {
    id: 'new', label: 'Nuovo', count: 4, accent: 'var(--ig-blue-700)',
    cards: [
      { id: 'R-2841', t: '12 min', area: 'impresa', areaLab: 'Impresa', subject: 'Domanda Resto al Sud · documentazione', user: 'Salvatore Catanzaro', avatar: 'SC', avatarBg: 'var(--ig-amber-500)', prio: 'media' },
      { id: 'R-2840', t: '34 min', area: 'concorso', areaLab: 'Concorsi', subject: 'Concorso Comune di Enna · scadenza?', user: 'Letizia Bonfiglio', avatar: 'LB', avatarBg: 'var(--ig-violet-600)', prio: 'media' },
      { id: 'R-2839', t: '1h', area: 'estero', areaLab: 'Estero', subject: 'Erasmus+ traineeship · Olanda', user: 'Marco Lo Curto', avatar: 'ML', avatarBg: 'var(--ig-teal-600)', prio: 'alta' },
      { id: 'R-2837', t: '3h', area: 'cultura', areaLab: 'Cultura', subject: 'Bonus cultura 18app · residui', user: 'Giuseppe Russo', avatar: 'GR', avatarBg: 'var(--ig-blue-600)', prio: 'bassa' },
    ],
  },
  {
    id: 'assign', label: 'Assegnato', count: 3, accent: 'var(--ig-violet-700)',
    cards: [
      { id: 'R-2838', t: '2h', area: 'lavoro', areaLab: 'Lavoro', subject: 'CV e lettera di presentazione', user: 'Anna Mineo', avatar: 'AM', avatarBg: 'var(--ig-pink-700)', op: 'P. Rizzo', prio: 'media', sla: '+18h' },
      { id: 'R-2835', t: '5h', area: 'estero', areaLab: 'Estero', subject: 'Visto studente · Canada', user: 'Federico Russo', avatar: 'FR', avatarBg: 'var(--ig-amber-700)', op: 'M. Greco', prio: 'bassa', sla: '+12h' },
      { id: 'R-2833', t: '8h', area: 'civile', areaLab: 'Civile', subject: 'Servizio civile · scelta progetto', user: 'Davide Pignato', avatar: 'DP', avatarBg: 'var(--ig-teal-700)', op: 'L. Marino', prio: 'media', sla: '+22h' },
    ],
  },
  {
    id: 'work', label: 'In lavorazione', count: 5, accent: 'var(--ig-amber-700)',
    cards: [
      { id: 'R-2840b', t: '40 min', area: 'concorso', areaLab: 'Concorsi', subject: 'Concorso Polizia Municipale · requisiti', user: 'Maria Lombardo', avatar: 'MA', avatarBg: 'var(--ig-violet-700)', op: 'L. Marino', prio: 'alta', notes: 3 },
      { id: 'R-2829', t: '1g', area: 'impresa', areaLab: 'Impresa', subject: 'Microcredito Sicilia · 2° step', user: 'Chiara La Rosa', avatar: 'CR', avatarBg: 'var(--ig-teal-600)', op: 'F. Bellomo', prio: 'media', notes: 5 },
      { id: 'R-2824', t: '2g', area: 'formazione', areaLab: 'Formazione', subject: 'Iscrizione ITS Digital Marketing', user: 'Andrea Costa', avatar: 'AC', avatarBg: 'var(--ig-blue-700)', op: 'P. Rizzo', prio: 'media', notes: 2 },
      { id: 'R-2820', t: '3g', area: 'diritti', areaLab: 'Diritti', subject: 'ISEE per bonus famiglia', user: 'Antonio Bianco', avatar: 'AB', avatarBg: 'var(--ig-pink-700)', op: 'L. Marino', prio: 'alta', sla: 'oggi', notes: 1 },
      { id: 'R-2815', t: '4g', area: 'lavoro', areaLab: 'Lavoro', subject: 'Garanzia Giovani · azienda hosting', user: 'Sara Cilluffo', avatar: 'SC', avatarBg: 'var(--ig-violet-600)', op: 'P. Rizzo', prio: 'media' },
    ],
  },
  {
    id: 'wait', label: 'In attesa utente', count: 3, accent: '#8a5d0a',
    cards: [
      { id: 'R-2836', t: '4h', area: 'impresa', areaLab: 'Impresa', subject: 'Idea impresa: serve documentazione', user: 'Chiara La Rosa', avatar: 'CR', avatarBg: 'var(--ig-teal-600)', op: 'F. Bellomo', prio: 'media', wait: '3 documenti' },
      { id: 'R-2818', t: '5g', area: 'estero', areaLab: 'Estero', subject: 'Erasmus+ · piano di studi', user: 'Sofia Pace', avatar: 'SP', avatarBg: 'var(--ig-amber-700)', op: 'M. Greco', prio: 'bassa', wait: 'Piano di studi' },
      { id: 'R-2810', t: '8g', area: 'lavoro', areaLab: 'Lavoro', subject: 'Tirocinio retribuito · scelta sede', user: 'Antonio Greco', avatar: 'AG', avatarBg: 'var(--ig-blue-700)', op: 'P. Rizzo', prio: 'media', wait: 'Conferma sede' },
    ],
  },
  {
    id: 'done', label: 'Evaso', count: 4, accent: 'var(--ig-green-700)',
    cards: [
      { id: 'R-2837e', t: '2h', area: 'cultura', areaLab: 'Cultura', subject: 'Bonus cultura 18app · risposta', user: 'Giuseppe Russo', avatar: 'GR', avatarBg: 'var(--ig-blue-600)', op: 'L. Marino', evasoIn: '6h' },
      { id: 'R-2828', t: '1g', area: 'concorso', areaLab: 'Concorsi', subject: 'Concorso Istruttore · esiti', user: 'Maria Lombardo', avatar: 'MA', avatarBg: 'var(--ig-violet-700)', op: 'L. Marino', evasoIn: '24h' },
      { id: 'R-2812', t: '3g', area: 'impresa', areaLab: 'Impresa', subject: 'Microcredito · prima info', user: 'Salvatore Catanzaro', avatar: 'SC', avatarBg: 'var(--ig-amber-500)', op: 'F. Bellomo', evasoIn: '4h' },
      { id: 'R-2805', t: '5g', area: 'civile', areaLab: 'Civile', subject: 'Servizio civile · graduatoria', user: 'Davide Pignato', avatar: 'DP', avatarBg: 'var(--ig-teal-700)', op: 'L. Marino', evasoIn: '12h' },
    ],
  },
  {
    id: 'closed', label: 'Chiuso', count: 8, accent: 'var(--ig-ink-500)',
    cards: [
      { id: 'R-2790', t: '7g', area: 'lavoro', areaLab: 'Lavoro', subject: 'CV revisione · feedback positivo', user: 'Anna Mineo', avatar: 'AM', avatarBg: 'var(--ig-pink-700)', op: 'P. Rizzo', closedAs: 'Risolto' },
      { id: 'R-2782', t: '10g', area: 'formazione', areaLab: 'Formazione', subject: 'Borsa studio universitaria', user: 'Andrea Costa', avatar: 'AC', avatarBg: 'var(--ig-blue-700)', op: 'P. Rizzo', closedAs: 'Risolto' },
      { id: 'R-2775', t: '12g', area: 'impresa', areaLab: 'Impresa', subject: 'Bando Cultura Crea Sicilia', user: 'Federico Russo', avatar: 'FR', avatarBg: 'var(--ig-amber-700)', op: 'F. Bellomo', closedAs: 'Non pertinente' },
    ],
  },
];

function TicketCard({ c, columnAccent, status }) {
  const prio = c.prio;
  const isClosed = status === 'closed';
  return (
    <div className="ig-card" style={{
      padding: 14, marginBottom: 10,
      borderTop: `3px solid ${columnAccent}`,
      cursor: 'grab',
      boxShadow: '0 1px 2px rgba(12,26,44,0.06)',
      opacity: isClosed ? 0.78 : 1,
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
        <span style={{ fontFamily: 'var(--ig-font-mono)', fontSize: 11, color: 'var(--ig-ink-500)', fontWeight: 600 }}>#{c.id.replace(/[a-z]$/,'')}</span>
        <span style={{ fontSize: 11, color: 'var(--ig-ink-400)' }}>{c.t}</span>
      </div>
      <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ig-ink-900)', lineHeight: 1.35, marginBottom: 10 }}>{c.subject}</div>

      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 10 }}>
        <span className={`ig-badge ig-badge--${c.area}`} style={{ height: 20, fontSize: 10, padding: '0 8px' }}>{c.areaLab}</span>
        {prio && (
          <span style={{
            height: 20, padding: '0 8px', borderRadius: 999,
            background: prio === 'alta' ? 'var(--ig-red-100)' : prio === 'media' ? 'var(--ig-amber-100)' : 'var(--ig-ink-100)',
            color: prio === 'alta' ? 'var(--ig-red-700)' : prio === 'media' ? 'var(--ig-amber-800)' : 'var(--ig-ink-700)',
            fontSize: 10, fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: 3,
          }}>
            <I.Flag size={10}/> {prio}
          </span>
        )}
        {c.sla && (
          <span style={{
            height: 20, padding: '0 8px', borderRadius: 999,
            background: c.sla === 'oggi' ? 'var(--ig-red-100)' : 'var(--ig-ink-75)',
            color: c.sla === 'oggi' ? 'var(--ig-red-700)' : 'var(--ig-ink-700)',
            fontSize: 10, fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: 3,
          }}>
            <I.Clock size={10}/> SLA {c.sla}
          </span>
        )}
        {c.evasoIn && (
          <span style={{ height: 20, padding: '0 8px', borderRadius: 999, background: 'var(--ig-green-100)', color: 'var(--ig-green-700)', fontSize: 10, fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: 3 }}>
            <I.Check size={10}/> {c.evasoIn}
          </span>
        )}
      </div>

      {c.wait && (
        <div style={{
          padding: '6px 10px', background: 'var(--ig-amber-50)', border: '1px solid var(--ig-amber-100)',
          borderRadius: 6, fontSize: 11, color: 'var(--ig-amber-800)', marginBottom: 10,
          display: 'flex', alignItems: 'center', gap: 6,
        }}>
          <I.Clock size={11}/> In attesa: {c.wait}
        </div>
      )}

      <div style={{ display: 'flex', alignItems: 'center', gap: 8, paddingTop: 10, borderTop: '1px solid var(--ig-border-soft)' }}>
        <div style={{
          width: 26, height: 26, borderRadius: '50%', background: c.avatarBg, color: 'white',
          display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 10,
        }}>{c.avatar}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--ig-ink-900)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{c.user}</div>
          {c.op && <div style={{ fontSize: 10, color: 'var(--ig-ink-500)' }}>→ {c.op}</div>}
        </div>
        <div style={{ display: 'flex', gap: 6, fontSize: 11, color: 'var(--ig-ink-400)' }}>
          {c.notes && <span style={{ display: 'flex', alignItems: 'center', gap: 2 }}><I.Chat size={11}/>{c.notes}</span>}
        </div>
      </div>
    </div>
  );
}

function BackendTicketScreen() {
  return (
    <BackendShell active="Ticket" breadcrumb={['Console', 'Sportello', 'Ticket / Richieste']} height={1450}>
      <PageHeader
        title="Ticket e richieste"
        subtitle="23 ticket aperti · 5 in lavorazione · tempo medio risposta 18h · SLA target 48h"
        actions={<>
          <div style={{ display: 'flex', border: '1px solid var(--ig-border)', borderRadius: 6, overflow: 'hidden' }}>
            <button style={{ background: 'var(--ig-ink-900)', color: 'white', border: 'none', padding: '8px 14px', cursor: 'pointer', fontSize: 13, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 6 }}><I.Kanban size={14}/> Kanban</button>
            <button style={{ background: 'white', border: 'none', padding: '8px 14px', cursor: 'pointer', fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-700)', display: 'flex', alignItems: 'center', gap: 6 }}><I.List size={14}/> Lista</button>
          </div>
          <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Download size={14}/> Esporta</button>
          <button className="ig-btn ig-btn--primary ig-btn--sm"><I.Plus size={14}/> Nuova richiesta</button>
        </>}
      />

      {/* Filters */}
      <div style={{ background: 'white', padding: '16px 32px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', gap: 10, alignItems: 'center' }}>
        <div style={{ flex: 1, maxWidth: 340, position: 'relative' }}>
          <input className="ig-input" placeholder="Cerca ticket…" style={{ height: 38, paddingLeft: 38, fontSize: 13 }}/>
          <div style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)' }}>
            <I.Search size={16} color="var(--ig-ink-400)"/>
          </div>
        </div>

        <button style={{ display: 'inline-flex', alignItems: 'center', gap: 8, height: 38, padding: '0 14px', borderRadius: 6, border: '1px solid var(--ig-blue-700)', background: 'var(--ig-blue-50)', color: 'var(--ig-blue-700)', fontSize: 13, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer' }}>
          Operatore: <strong>I miei (G. Fontana)</strong> <I.ChevD size={14}/>
        </button>
        <button style={{ display: 'inline-flex', alignItems: 'center', gap: 8, height: 38, padding: '0 14px', borderRadius: 6, border: '1px solid var(--ig-border)', background: 'white', color: 'var(--ig-ink-700)', fontSize: 13, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer' }}>
          Area: <span style={{ color: 'var(--ig-ink-500)' }}>Tutte</span> <I.ChevD size={14}/>
        </button>
        <button style={{ display: 'inline-flex', alignItems: 'center', gap: 8, height: 38, padding: '0 14px', borderRadius: 6, border: '1px solid var(--ig-border)', background: 'white', color: 'var(--ig-ink-700)', fontSize: 13, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer' }}>
          Priorità: <span style={{ color: 'var(--ig-ink-500)' }}>Tutte</span> <I.ChevD size={14}/>
        </button>
        <button style={{ display: 'inline-flex', alignItems: 'center', gap: 8, height: 38, padding: '0 14px', borderRadius: 6, border: '1px solid var(--ig-border)', background: 'white', color: 'var(--ig-ink-700)', fontSize: 13, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer' }}>
          Periodo: <span style={{ color: 'var(--ig-ink-500)' }}>Ultimi 30 giorni</span> <I.ChevD size={14}/>
        </button>

        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 14, fontSize: 12, color: 'var(--ig-ink-500)' }}>
          <span><strong style={{ color: 'var(--ig-ink-900)' }}>27</strong> visualizzati</span>
          <span>·</span>
          <span>tempo medio: <strong style={{ color: 'var(--ig-green-700)' }}>18h</strong></span>
          <span>·</span>
          <span style={{ color: 'var(--ig-red-700)' }}><strong>2</strong> oltre SLA</span>
        </div>
      </div>

      {/* KANBAN */}
      <div style={{ padding: '20px 32px 32px', overflowX: 'auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, minmax(0, 1fr))', gap: 14, alignItems: 'flex-start' }}>
          {cols.map((col) => (
            <div key={col.id} style={{
              background: 'var(--ig-ink-50)', borderRadius: 10, padding: 12,
              border: '1px solid var(--ig-border-soft)',
            }}>
              {/* Column header */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14, padding: '4px 6px' }}>
                <span style={{ width: 8, height: 8, borderRadius: '50%', background: col.accent }}/>
                <h3 style={{ fontSize: 13, fontWeight: 800, color: 'var(--ig-ink-900)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{col.label}</h3>
                <span style={{
                  marginLeft: 'auto',
                  fontSize: 11, fontWeight: 700, padding: '2px 8px',
                  background: 'white', border: '1px solid var(--ig-border)', borderRadius: 999, color: 'var(--ig-ink-700)',
                  fontFamily: 'var(--ig-font-mono)',
                }}>{col.count}</span>
                <button style={{ background: 'none', border: 'none', padding: 4, cursor: 'pointer', color: 'var(--ig-ink-400)' }}><I.Plus size={14}/></button>
              </div>

              {/* Cards */}
              <div>
                {col.cards.map((c, i) => <TicketCard key={i} c={c} columnAccent={col.accent} status={col.id}/>)}
              </div>

              {/* +N more */}
              {col.count > col.cards.length && (
                <button style={{
                  background: 'transparent', border: '1px dashed var(--ig-ink-300)', borderRadius: 8,
                  width: '100%', padding: '10px', fontSize: 12, fontWeight: 600, color: 'var(--ig-ink-500)',
                  cursor: 'pointer', fontFamily: 'inherit', marginTop: 4,
                }}>
                  + {col.count - col.cards.length} altri
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </BackendShell>
  );
}

window.BackendTicketScreen = BackendTicketScreen;
