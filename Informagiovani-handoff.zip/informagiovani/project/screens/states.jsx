/* global React, IGIcons */
const I = IGIcons;

function StatePanel({ title, subtitle, accent, children, width = 380 }) {
  return (
    <div style={{ width, display: 'flex', flexDirection: 'column' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
        <span style={{ width: 8, height: 8, borderRadius: '50%', background: accent }}/>
        <div style={{ fontSize: 12, fontWeight: 800, color: 'var(--ig-ink-900)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{title}</div>
      </div>
      <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginBottom: 12 }}>{subtitle}</div>
      <div className="ig-card" style={{ padding: 0, overflow: 'hidden', flex: 1 }}>
        {children}
      </div>
    </div>
  );
}

// Generic empty state
function Empty({ icon, title, msg, primary, secondary, height = 320 }) {
  return (
    <div style={{ padding: '36px 28px', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', height, justifyContent: 'center' }}>
      <div style={{
        width: 64, height: 64, borderRadius: 16,
        background: 'var(--ig-blue-50)', color: 'var(--ig-blue-700)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 18,
      }}>
        {icon}
      </div>
      <h3 style={{ fontSize: 16, fontWeight: 700, color: 'var(--ig-ink-900)', marginBottom: 6, maxWidth: 280 }}>{title}</h3>
      <p style={{ fontSize: 13, color: 'var(--ig-ink-500)', lineHeight: 1.55, marginBottom: 18, maxWidth: 280 }}>{msg}</p>
      <div style={{ display: 'flex', gap: 8 }}>
        {primary && <button className="ig-btn ig-btn--primary ig-btn--sm">{primary}</button>}
        {secondary && <button className="ig-btn ig-btn--secondary ig-btn--sm">{secondary}</button>}
      </div>
    </div>
  );
}

// Toast
function Toast({ kind, title, msg }) {
  const map = {
    success: { bg: 'var(--ig-green-100)', border: 'var(--ig-green-600)', fg: 'var(--ig-green-700)', icon: <I.Check size={20}/> },
    error:   { bg: 'var(--ig-red-100)', border: 'var(--ig-red-600)', fg: 'var(--ig-red-700)', icon: <I.Alert size={20}/> },
    warning: { bg: 'var(--ig-amber-100)', border: 'var(--ig-amber-600)', fg: 'var(--ig-amber-800)', icon: <I.Alert size={20}/> },
    info:    { bg: 'var(--ig-blue-100)', border: 'var(--ig-blue-700)', fg: 'var(--ig-blue-800)', icon: <I.Info size={20}/> },
  };
  const c = map[kind];
  return (
    <div style={{
      background: 'white', borderRadius: 10, padding: '14px 16px',
      display: 'flex', gap: 12, alignItems: 'flex-start',
      border: `1px solid ${c.bg}`, borderLeft: `4px solid ${c.border}`,
      boxShadow: '0 4px 12px rgba(12,26,44,0.08)',
    }}>
      <div style={{ color: c.fg, flex: '0 0 auto', marginTop: 1 }}>{c.icon}</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ig-ink-900)' }}>{title}</div>
        <div style={{ fontSize: 12, color: 'var(--ig-ink-700)', marginTop: 2, lineHeight: 1.5 }}>{msg}</div>
      </div>
      <button style={{ background: 'none', border: 'none', padding: 2, color: 'var(--ig-ink-400)', cursor: 'pointer' }}><I.X size={14}/></button>
    </div>
  );
}

// Skeleton loading
function SkeletonRow() {
  return (
    <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', gap: 12, alignItems: 'center' }}>
      <div style={{ width: 36, height: 36, borderRadius: 8, background: 'var(--ig-ink-100)' }}/>
      <div style={{ flex: 1 }}>
        <div style={{ height: 12, background: 'var(--ig-ink-100)', borderRadius: 4, width: '78%', marginBottom: 6 }}/>
        <div style={{ height: 9, background: 'var(--ig-ink-100)', borderRadius: 4, width: '52%' }}/>
      </div>
      <div style={{ width: 56, height: 22, borderRadius: 999, background: 'var(--ig-ink-100)' }}/>
    </div>
  );
}

function StatesScreen() {
  return (
    <div className="ig" style={{ width: 1440, background: 'var(--ig-bg)', padding: 32, minHeight: 1500 }}>
      <div style={{ marginBottom: 28 }}>
        <h2 style={{ fontSize: 26, fontWeight: 700, letterSpacing: '-0.02em' }}>Stati di sistema · feedback all'utente</h2>
        <p style={{ fontSize: 14, color: 'var(--ig-ink-500)', marginTop: 6, maxWidth: 720 }}>
          Pattern uniformi per i momenti in cui la piattaforma deve comunicare assenza di dati, errori, conferme, attese o suggerimenti. Sono riutilizzati identici tra frontend pubblico, area personale e backend gestionale.
        </p>
      </div>

      {/* ========================= EMPTY STATES ========================= */}
      <div style={{ marginBottom: 36 }}>
        <h3 style={{ fontSize: 13, fontWeight: 800, color: 'var(--ig-ink-700)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 16 }}>① Stati vuoti</h3>
        <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
          <StatePanel title="Ricerca senza risultati" subtitle="Frontend · /opportunita" accent="var(--ig-blue-700)">
            <Empty
              icon={<I.Search size={28}/>}
              title="Nessuna opportunità trovata"
              msg="Prova a modificare i filtri o a rimuovere alcune parole chiave. Puoi anche inviare una richiesta agli operatori."
              primary={<>Azzera filtri</>}
              secondary={<>Invia richiesta</>}
            />
          </StatePanel>

          <StatePanel title="Nessuna opportunità salvata" subtitle="Area personale · /salvate" accent="var(--ig-teal-700)">
            <Empty
              icon={<I.Bookmark size={28}/>}
              title="Non hai ancora salvato opportunità"
              msg="Tocca l'icona ❤︎ su una scheda per tenerla qui. Riceverai promemoria automatici prima della scadenza."
              primary={<>Esplora opportunità</>}
            />
          </StatePanel>

          <StatePanel title="Coda validazione vuota" subtitle="Backend · /schede/da-verificare" accent="var(--ig-green-700)">
            <Empty
              icon={<I.Check size={28} strokeWidth={2.5}/>}
              title="Tutto sotto controllo!"
              msg="Non ci sono schede in attesa di verifica. Le nuove proposte appariranno qui automaticamente."
              secondary={<>Filtri avanzati</>}
            />
          </StatePanel>
        </div>
      </div>

      {/* ========================= SUCCESS / CONFIRMATION ========================= */}
      <div style={{ marginBottom: 36 }}>
        <h3 style={{ fontSize: 13, fontWeight: 800, color: 'var(--ig-ink-700)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 16 }}>② Conferme e successo</h3>
        <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', alignItems: 'flex-start' }}>
          {/* Big success page */}
          <StatePanel width={540} title="Pagina di conferma · prenotazione" subtitle="Frontend · post-invio form colloquio" accent="var(--ig-green-700)">
            <div style={{ padding: '40px 32px 36px', textAlign: 'center' }}>
              <div style={{ width: 72, height: 72, borderRadius: '50%', background: 'var(--ig-green-100)', color: 'var(--ig-green-600)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 18px', border: '4px solid var(--ig-green-50)' }}>
                <I.Check size={36} strokeWidth={2.5}/>
              </div>
              <h3 style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.01em', marginBottom: 8 }}>Richiesta di colloquio inviata</h3>
              <p style={{ fontSize: 14, color: 'var(--ig-ink-500)', lineHeight: 1.55, marginBottom: 22, maxWidth: 400, margin: '0 auto 22px' }}>
                Riceverai una conferma dagli operatori entro 24 ore lavorative. Puoi seguire lo stato dalla tua area personale.
              </p>
              <div style={{ background: 'var(--ig-ink-50)', borderRadius: 10, padding: 14, marginBottom: 18, display: 'inline-flex', gap: 14, fontSize: 13 }}>
                <span>📌 ID richiesta: <strong className="ig-mono">#R-2841</strong></span>
                <span style={{ color: 'var(--ig-ink-400)' }}>·</span>
                <span>Risposta entro: <strong>16 marzo · 09:00</strong></span>
              </div>
              <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
                <button className="ig-btn ig-btn--primary">Vai all'area personale</button>
                <button className="ig-btn ig-btn--secondary">Torna alla home</button>
              </div>
            </div>
          </StatePanel>

          {/* Toasts column */}
          <StatePanel width={380} title="Toast di successo" subtitle="Bottom-right · auto-dismiss 4s" accent="var(--ig-green-700)">
            <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 10, background: 'var(--ig-ink-50)' }}>
              <Toast kind="success" title="Scheda pubblicata" msg="ERA-2026-117 è ora visibile nel catalogo pubblico."/>
              <Toast kind="success" title="Email inviata · 247 destinatari" msg="Newsletter settimana 11 inviata correttamente."/>
              <Toast kind="success" title="Profilo aggiornato" msg="Le tue preferenze di notifica sono state salvate."/>
            </div>
          </StatePanel>

          <StatePanel width={380} title="Toast informativo" subtitle="Inline · non bloccante" accent="var(--ig-blue-700)">
            <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 10, background: 'var(--ig-ink-50)' }}>
              <Toast kind="info" title="Salvataggio automatico attivo" msg="Le modifiche al colloquio vengono salvate ogni 30 secondi."/>
              <Toast kind="info" title="3 opportunità consigliate per te" msg="Sulla base dei tuoi interessi · NEET 22 anni · Impresa"/>
            </div>
          </StatePanel>
        </div>
      </div>

      {/* ========================= ERROR / WARNING ========================= */}
      <div style={{ marginBottom: 36 }}>
        <h3 style={{ fontSize: 13, fontWeight: 800, color: 'var(--ig-ink-700)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 16 }}>③ Errori e attenzione</h3>
        <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', alignItems: 'flex-start' }}>
          {/* 500 error */}
          <StatePanel width={420} title="Errore di sistema · 500" subtitle="Pagina full-screen" accent="var(--ig-red-700)">
            <div style={{ padding: '40px 32px', textAlign: 'center' }}>
              <div className="ig-num" style={{ fontSize: 64, fontWeight: 800, color: 'var(--ig-red-100)', letterSpacing: '-0.03em', lineHeight: 1, marginBottom: 4 }}>500</div>
              <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 8 }}>Qualcosa è andato storto</h3>
              <p style={{ fontSize: 13, color: 'var(--ig-ink-500)', lineHeight: 1.55, marginBottom: 16 }}>
                Stiamo già lavorando per risolvere il problema. Riprova tra qualche minuto. Se persiste, contatta lo sportello.
              </p>
              <div className="ig-mono" style={{ background: 'var(--ig-ink-50)', padding: 8, borderRadius: 6, fontSize: 11, color: 'var(--ig-ink-500)', marginBottom: 16 }}>
                Error ID: ENN-a4f2-19e8-c1
              </div>
              <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
                <button className="ig-btn ig-btn--primary ig-btn--sm">Riprova</button>
                <button className="ig-btn ig-btn--secondary ig-btn--sm">Vai allo sportello</button>
              </div>
            </div>
          </StatePanel>

          {/* Form validation errors */}
          <StatePanel width={460} title="Errori di validazione form" subtitle="Inline · sotto i campi non validi" accent="var(--ig-red-700)">
            <div style={{ padding: 20 }}>
              <div style={{ marginBottom: 14 }}>
                <label className="ig-label">Email <span style={{ color: 'var(--ig-red-700)' }}>*</span></label>
                <input className="ig-input" defaultValue="m.scalisi.email.it" style={{ borderColor: 'var(--ig-red-600)', background: 'var(--ig-red-50)' }}/>
                <div style={{ fontSize: 12, color: 'var(--ig-red-700)', marginTop: 6, display: 'flex', alignItems: 'center', gap: 4 }}>
                  <I.Alert size={12}/> L&apos;indirizzo email non sembra valido · manca @
                </div>
              </div>
              <div style={{ marginBottom: 14 }}>
                <label className="ig-label">Argomento del colloquio <span style={{ color: 'var(--ig-red-700)' }}>*</span></label>
                <div className="ig-input" style={{ borderColor: 'var(--ig-red-600)', background: 'var(--ig-red-50)', color: 'var(--ig-ink-400)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span>Seleziona un argomento</span>
                  <I.ChevD size={14}/>
                </div>
                <div style={{ fontSize: 12, color: 'var(--ig-red-700)', marginTop: 6, display: 'flex', alignItems: 'center', gap: 4 }}>
                  <I.Alert size={12}/> Campo obbligatorio
                </div>
              </div>
              <div style={{ padding: 12, background: 'var(--ig-red-50)', border: '1px solid var(--ig-red-100)', borderRadius: 8, display: 'flex', gap: 10, marginBottom: 14 }}>
                <I.Alert size={16} color="var(--ig-red-700)"/>
                <div style={{ fontSize: 13, color: 'var(--ig-ink-700)' }}>
                  <strong>2 campi da correggere</strong> prima di poter inviare la richiesta.
                </div>
              </div>
              <button className="ig-btn ig-btn--primary" style={{ width: '100%', justifyContent: 'center' }}>Invia richiesta</button>
            </div>
          </StatePanel>

          {/* Warning panel */}
          <StatePanel width={460} title="Scheda scaduta · avviso" subtitle="Banner sticky in cima al dettaglio" accent="var(--ig-amber-700)">
            <div style={{ padding: 0 }}>
              <div style={{ padding: '16px 22px', background: 'var(--ig-amber-50)', border: '1px solid var(--ig-amber-100)', borderRadius: 12, margin: 20, display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                <I.Alert size={20} color="var(--ig-amber-700)" style={{ flex: '0 0 auto', marginTop: 2 }}/>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ig-amber-800)', marginBottom: 4 }}>Questa opportunità risulta scaduta</div>
                  <p style={{ fontSize: 13, color: 'var(--ig-ink-700)', lineHeight: 1.5, marginBottom: 12 }}>
                    Puoi comunque consultarla come archivio o cercare opportunità simili attive.
                  </p>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button className="ig-btn ig-btn--primary ig-btn--sm">Cerca simili</button>
                    <button className="ig-btn ig-btn--secondary ig-btn--sm">Consulta archivio</button>
                  </div>
                </div>
              </div>
              <Toast kind="warning" title="Fonte non aggiornata da 60 giorni" msg="Cliclavoro Sicilia · controllo previsto 7 giorni fa. Verifica i dati."/>
            </div>
          </StatePanel>
        </div>
      </div>

      {/* ========================= LOADING / SKELETON ========================= */}
      <div style={{ marginBottom: 12 }}>
        <h3 style={{ fontSize: 13, fontWeight: 800, color: 'var(--ig-ink-700)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 16 }}>④ Caricamento e attesa</h3>
        <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', alignItems: 'flex-start' }}>
          <StatePanel width={460} title="Skeleton · lista in caricamento" subtitle="Mostra struttura senza i dati reali" accent="var(--ig-ink-500)">
            <div>
              <SkeletonRow/>
              <SkeletonRow/>
              <SkeletonRow/>
              <SkeletonRow/>
              <SkeletonRow/>
            </div>
          </StatePanel>

          <StatePanel width={380} title="Caricamento inline" subtitle="Pulsante in attesa" accent="var(--ig-ink-500)">
            <div style={{ padding: 24, display: 'flex', flexDirection: 'column', gap: 14 }}>
              <button className="ig-btn ig-btn--primary" style={{ width: '100%', justifyContent: 'center', opacity: 0.85 }} disabled>
                <span style={{ width: 14, height: 14, borderRadius: '50%', border: '2px solid white', borderTopColor: 'transparent', animation: 'spin 1s linear infinite' }}/>
                Invio in corso…
              </button>
              <button className="ig-btn ig-btn--secondary" style={{ width: '100%', justifyContent: 'center' }}>
                <I.Check size={14} color="var(--ig-green-600)" strokeWidth={3}/>
                Salvato
              </button>
              <div style={{ padding: 16, background: 'var(--ig-blue-50)', borderRadius: 10, fontSize: 13, color: 'var(--ig-blue-800)' }}>
                Stiamo verificando 247 schede sulla fonte ufficiale… <strong>62%</strong>
                <div style={{ height: 4, background: 'rgba(31,90,168,0.15)', borderRadius: 999, marginTop: 8, overflow: 'hidden' }}>
                  <div style={{ width: '62%', height: '100%', background: 'var(--ig-blue-700)' }}/>
                </div>
              </div>
            </div>
          </StatePanel>

          <StatePanel width={500} title="Offline · connessione assente" subtitle="Full-screen su mobile · banner su desktop" accent="var(--ig-red-700)">
            <div style={{ padding: '40px 32px', textAlign: 'center' }}>
              <div style={{ width: 64, height: 64, borderRadius: 16, background: 'var(--ig-ink-50)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 18px' }}>
                <I.Globe size={28} color="var(--ig-ink-400)"/>
              </div>
              <h3 style={{ fontSize: 17, fontWeight: 700, marginBottom: 8 }}>Sembra che tu sia offline</h3>
              <p style={{ fontSize: 13, color: 'var(--ig-ink-500)', lineHeight: 1.55, marginBottom: 16 }}>
                Verifica la tua connessione. Quando torni online, le opportunità salvate saranno comunque disponibili.
              </p>
              <button className="ig-btn ig-btn--primary ig-btn--sm">Riprova</button>
            </div>
          </StatePanel>
        </div>
      </div>

      <style>{`
        @keyframes spin { from { transform: rotate(0); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}

window.StatesScreen = StatesScreen;
