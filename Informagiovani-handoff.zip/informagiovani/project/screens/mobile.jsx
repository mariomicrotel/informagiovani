/* global React, IGIcons */
const I = IGIcons;

// ============================================================
// Mobile screens — 390 × 844 (iPhone 14)
// Includes status bar + bottom nav + content of each main view.
// ============================================================

function MobileStatusBar({ dark }) {
  return (
    <div style={{
      height: 44, padding: '14px 20px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start',
      color: dark ? 'white' : 'var(--ig-ink-900)',
      fontSize: 13, fontWeight: 700, fontFamily: '-apple-system, BlinkMacSystemFont, sans-serif',
      flex: '0 0 auto',
    }}>
      <span>9:41</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
        <span style={{ display: 'flex', gap: 1, alignItems: 'flex-end' }}>
          {[3, 5, 7, 9].map(h => <span key={h} style={{ width: 3, height: h, background: 'currentColor', borderRadius: 1 }}/>)}
        </span>
        <svg width="16" height="11" viewBox="0 0 16 11" fill="none">
          <path d="M2 4.5C4 2.5 6 1 8 1s4 1.5 6 3.5M4 6.5c1-1 2-2 4-2s3 1 4 2M6 8.5c.5-.5 1-1 2-1s1.5.5 2 1" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
          <circle cx="8" cy="10" r="1" fill="currentColor"/>
        </svg>
        <span style={{ width: 22, height: 11, border: '1px solid currentColor', borderRadius: 3, padding: 1, position: 'relative' }}>
          <span style={{ position: 'absolute', inset: 1, background: 'currentColor', width: 'calc(100% - 6px)', borderRadius: 1 }}/>
          <span style={{ position: 'absolute', right: -3, top: 3, width: 2, height: 4, background: 'currentColor', borderRadius: '0 1px 1px 0' }}/>
        </span>
      </div>
    </div>
  );
}

function MobileFrame({ dark, children, label, sublabel }) {
  return (
    <div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 2, marginBottom: 12 }}>
        <div style={{ fontSize: 12, fontWeight: 800, color: 'var(--ig-ink-900)', letterSpacing: '-0.005em' }}>{label}</div>
        <div style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>{sublabel}</div>
      </div>
      <div style={{
        width: 390, height: 844,
        background: dark ? 'var(--ig-blue-800)' : 'white',
        borderRadius: 44, overflow: 'hidden', position: 'relative',
        boxShadow: '0 18px 48px rgba(12,26,44,0.14), 0 0 0 8px #111 inset, 0 0 0 12px #1a1a1a',
        outline: '2px solid #2a2a2a', outlineOffset: 2,
        display: 'flex', flexDirection: 'column',
      }}>
        <MobileStatusBar dark={dark}/>
        {/* Notch */}
        <div style={{
          position: 'absolute', top: 12, left: '50%', transform: 'translateX(-50%)',
          width: 110, height: 32, background: '#0a0a0a', borderRadius: 999, zIndex: 10,
        }}/>
        <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
          {children}
        </div>
      </div>
    </div>
  );
}

function MobileBottomNav({ active }) {
  const items = [
    ['Home', <I.Home size={20}/>],
    ['Cerca', <I.Search size={20}/>],
    ['Salvate', <I.Bookmark size={20}/>],
    ['Eventi', <I.Calendar size={20}/>],
    ['Profilo', <I.User size={20}/>],
  ];
  return (
    <div style={{
      flex: '0 0 auto',
      background: 'white', borderTop: '1px solid var(--ig-border-soft)',
      padding: '8px 4px 18px', display: 'flex', justifyContent: 'space-around',
    }}>
      {items.map(([l, ico]) => {
        const a = l === active;
        return (
          <div key={l} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2, padding: '6px 12px', cursor: 'pointer' }}>
            <span style={{ color: a ? 'var(--ig-blue-700)' : 'var(--ig-ink-400)' }}>{ico}</span>
            <span style={{ fontSize: 10, fontWeight: 700, color: a ? 'var(--ig-blue-700)' : 'var(--ig-ink-500)' }}>{l}</span>
          </div>
        );
      })}
    </div>
  );
}

// ============================================================
// HOMEPAGE MOBILE
// ============================================================
function MobileHomepage() {
  return (
    <MobileFrame dark label="01 · Homepage" sublabel="iPhone 14 · 390 × 844 · navigazione tab fissa">
      <div className="ig" style={{ flex: 1, overflowY: 'auto', background: 'var(--ig-bg)' }}>
        {/* Hero */}
        <div style={{
          background: 'linear-gradient(160deg, var(--ig-blue-700) 0%, var(--ig-blue-800) 70%, #08213f 100%)',
          padding: '16px 20px 24px', color: 'white',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 22 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ width: 32, height: 32, borderRadius: 7, background: 'var(--ig-amber-500)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="18" height="18" viewBox="0 0 28 28" fill="none">
                  <path d="M4 22 L14 4 L24 22 Z" stroke="var(--ig-blue-900)" strokeWidth="2.4" strokeLinejoin="round"/>
                  <circle cx="14" cy="15" r="2.4" fill="var(--ig-blue-900)"/>
                </svg>
              </div>
              <div style={{ lineHeight: 1.1 }}>
                <div style={{ fontSize: 13, fontWeight: 800 }}>Informagiovani</div>
                <div style={{ fontSize: 10, color: 'var(--ig-amber-500)', fontWeight: 700, letterSpacing: '0.06em' }}>ENNA</div>
              </div>
            </div>
            <button style={{ background: 'rgba(255,255,255,0.1)', border: 'none', borderRadius: '50%', width: 36, height: 36, color: 'white', cursor: 'pointer', position: 'relative' }}>
              <I.Bell size={16}/>
              <span style={{ position: 'absolute', top: 8, right: 9, width: 7, height: 7, background: 'var(--ig-amber-500)', borderRadius: '50%' }}/>
            </button>
          </div>

          <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-amber-500)', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 8 }}>Servizio del Comune di Enna</div>
          <h1 style={{ fontSize: 26, fontWeight: 800, color: 'white', letterSpacing: '-0.02em', lineHeight: 1.15, marginBottom: 16 }}>
            Le opportunità per i giovani di Enna
          </h1>

          {/* Search */}
          <div style={{ background: 'white', borderRadius: 10, padding: '6px 6px 6px 14px', display: 'flex', alignItems: 'center', gap: 8 }}>
            <I.Search size={16} color="var(--ig-ink-400)"/>
            <input placeholder="Cerca opportunità…" style={{ flex: 1, border: 'none', outline: 'none', fontSize: 14, padding: '10px 0', color: 'var(--ig-ink-900)', background: 'transparent', fontFamily: 'inherit' }}/>
            <button style={{ background: 'var(--ig-blue-700)', border: 'none', borderRadius: 7, width: 36, height: 36, color: 'white' }}>
              <I.ArrowR size={16}/>
            </button>
          </div>
        </div>

        {/* Stats */}
        <div style={{ padding: '18px 20px', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
          {[['487','Opportunità'],['14','Eventi'],['2.140','Iscritti']].map(([v, l]) => (
            <div key={l} style={{ padding: 10, background: 'white', borderRadius: 10, border: '1px solid var(--ig-border-soft)', textAlign: 'center' }}>
              <div className="ig-num" style={{ fontSize: 18, fontWeight: 800, color: 'var(--ig-blue-700)' }}>{v}</div>
              <div style={{ fontSize: 10, color: 'var(--ig-ink-500)', fontWeight: 600 }}>{l}</div>
            </div>
          ))}
        </div>

        {/* Percorsi rapidi */}
        <div style={{ padding: '6px 20px 18px' }}>
          <h2 style={{ fontSize: 18, fontWeight: 700, marginBottom: 12, letterSpacing: '-0.01em' }}>Percorsi rapidi</h2>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {[
              [<I.Briefcase size={20}/>, 'Cerco lavoro', 'var(--ig-blue-700)', 'var(--ig-blue-50)'],
              [<I.GradCap size={20}/>, 'Formazione', 'var(--ig-violet-700)', '#f3eefc'],
              [<I.Bulb size={20}/>, 'Impresa', 'var(--ig-teal-700)', 'var(--ig-teal-50)'],
              [<I.Globe size={20}/>, 'Estero', 'var(--ig-amber-700)', 'var(--ig-amber-50)'],
            ].map(([ico, t, c, bg]) => (
              <div key={t} style={{ padding: 14, background: 'white', borderRadius: 12, border: '1px solid var(--ig-border-soft)' }}>
                <div style={{ width: 38, height: 38, borderRadius: 10, background: bg, color: c, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 10 }}>{ico}</div>
                <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ig-ink-900)' }}>{t}</div>
              </div>
            ))}
          </div>
        </div>

        {/* In scadenza */}
        <div style={{ padding: '0 20px 18px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <h2 style={{ fontSize: 18, fontWeight: 700, letterSpacing: '-0.01em' }}>In scadenza</h2>
            <a href="#" style={{ fontSize: 12, fontWeight: 600 }}>Tutte →</a>
          </div>
          {[
            ['Erasmus+ Traineeship 2026', 'estero', 'Estero', '3g', 'urgent'],
            ['Servizio Civile · 18 posti', 'civile', 'Civile', '7g', 'urgent'],
            ['Concorso Comune di Enna', 'concorso', 'Concorsi', '21g', 'soon'],
          ].map((o, i) => (
            <div key={i} style={{ padding: 14, background: 'white', borderRadius: 10, border: '1px solid var(--ig-border-soft)', marginBottom: 8, display: 'flex', gap: 12, alignItems: 'center' }}>
              <div style={{
                width: 46, padding: '8px 0', textAlign: 'center', borderRadius: 8,
                background: o[4] === 'urgent' ? 'var(--ig-red-100)' : 'var(--ig-amber-100)',
                color: o[4] === 'urgent' ? 'var(--ig-red-700)' : 'var(--ig-amber-800)',
              }}>
                <div className="ig-num" style={{ fontSize: 16, fontWeight: 800 }}>{o[3]}</div>
                <div style={{ fontSize: 9, fontWeight: 700 }}>RESTANO</div>
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 4 }}>{o[0]}</div>
                <span className={`ig-badge ig-badge--${o[1]}`} style={{ height: 18, fontSize: 10, padding: '0 6px' }}>{o[2]}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
      <MobileBottomNav active="Home"/>
    </MobileFrame>
  );
}

// ============================================================
// LIST MOBILE
// ============================================================
function MobileList() {
  return (
    <MobileFrame label="02 · Elenco opportunità" sublabel="Filtri drawer · card verticali">
      <div className="ig" style={{ flex: 1, overflowY: 'auto', background: 'var(--ig-bg)' }}>
        {/* Header */}
        <div style={{ background: 'white', padding: '4px 20px 14px', borderBottom: '1px solid var(--ig-border-soft)', position: 'sticky', top: 0, zIndex: 2 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
            <button style={{ background: 'var(--ig-ink-50)', border: 'none', width: 36, height: 36, borderRadius: 8 }}><I.ArrowL size={16}/></button>
            <h1 style={{ fontSize: 17, fontWeight: 700, flex: 1 }}>Opportunità</h1>
            <button style={{ background: 'var(--ig-ink-50)', border: 'none', width: 36, height: 36, borderRadius: 8 }}><I.Bookmark size={16}/></button>
          </div>
          {/* Search bar */}
          <div style={{ background: 'var(--ig-ink-50)', borderRadius: 10, padding: '0 12px', display: 'flex', alignItems: 'center', gap: 8 }}>
            <I.Search size={14} color="var(--ig-ink-400)"/>
            <input placeholder="Cerca lavoro, corsi…" defaultValue="tirocinio retribuito" style={{ flex: 1, border: 'none', outline: 'none', fontSize: 13, padding: '11px 0', color: 'var(--ig-ink-900)', background: 'transparent', fontFamily: 'inherit' }}/>
            <button style={{ background: 'none', border: 'none', padding: 4 }}><I.X size={14} color="var(--ig-ink-400)"/></button>
          </div>
          {/* Filters row */}
          <div style={{ display: 'flex', gap: 6, marginTop: 12, overflowX: 'auto', paddingBottom: 2 }}>
            <button style={{ height: 30, padding: '0 12px', borderRadius: 999, background: 'var(--ig-blue-700)', color: 'white', border: 'none', fontSize: 11, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 5, whiteSpace: 'nowrap' }}>
              <I.Filter size={11}/> 5 filtri
            </button>
            <button style={{ height: 30, padding: '0 12px', borderRadius: 999, background: 'var(--ig-blue-50)', color: 'var(--ig-blue-700)', border: '1px solid var(--ig-blue-300)', fontSize: 11, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 4, whiteSpace: 'nowrap' }}>
              Lavoro <I.X size={10}/>
            </button>
            <button style={{ height: 30, padding: '0 12px', borderRadius: 999, background: 'var(--ig-blue-50)', color: 'var(--ig-blue-700)', border: '1px solid var(--ig-blue-300)', fontSize: 11, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 4, whiteSpace: 'nowrap' }}>
              Estero <I.X size={10}/>
            </button>
            <button style={{ height: 30, padding: '0 12px', borderRadius: 999, background: 'white', color: 'var(--ig-ink-700)', border: '1px solid var(--ig-border)', fontSize: 11, fontWeight: 600, whiteSpace: 'nowrap' }}>18–25</button>
            <button style={{ height: 30, padding: '0 12px', borderRadius: 999, background: 'white', color: 'var(--ig-ink-700)', border: '1px solid var(--ig-border)', fontSize: 11, fontWeight: 600, whiteSpace: 'nowrap' }}>Sicilia</button>
          </div>
        </div>

        {/* Results count */}
        <div style={{ padding: '14px 20px 8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontSize: 12, color: 'var(--ig-ink-700)' }}><strong>247</strong> risultati</div>
          <button style={{ background: 'none', border: 'none', fontSize: 12, fontWeight: 600, color: 'var(--ig-blue-700)', display: 'flex', alignItems: 'center', gap: 4 }}>
            Consigliate <I.ChevD size={12}/>
          </button>
        </div>

        {/* Cards */}
        <div style={{ padding: '4px 20px 20px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          {[
            { area: 'Estero', ac: 'estero', t: 'Erasmus+ Traineeship 2026/27', d: 'Tirocini retribuiti 2-12 mesi presso enti pubblici e imprese in 33 paesi europei.', urg: 'urgent', when: '3 giorni', src: 'INDIRE · Ufficiale', tgt: 'Universitari' },
            { area: 'Lavoro', ac: 'lavoro', t: 'Garanzia Giovani Sicilia · 120 tirocini', d: 'Tirocini extracurriculari di 6 mesi con indennità di 500€/mese in aziende ennesi.', urg: 'soon', when: '12 giorni', src: 'Regione Sicilia', tgt: 'NEET' },
            { area: 'Impresa', ac: 'impresa', t: 'Resto al Sud · 200.000€', d: 'Contributo a fondo perduto per nuove attività imprenditoriali under 56.', urg: 'ok', when: 'Sempre aperta', src: 'Invitalia · Ufficiale', tgt: '18–55' },
          ].map((o, i) => (
            <article key={i} style={{ padding: 14, background: 'white', borderRadius: 12, border: '1px solid var(--ig-border-soft)' }}>
              <div style={{ display: 'flex', gap: 6, marginBottom: 10, flexWrap: 'wrap' }}>
                <span className={`ig-badge ig-badge--${o.ac}`} style={{ height: 20, fontSize: 10, padding: '0 7px' }}>{o.area}</span>
                <span className={`ig-badge ig-badge--scad-${o.urg}`} style={{ height: 20, fontSize: 10, padding: '0 7px' }}>
                  <I.Clock size={10}/> {o.when}
                </span>
                <button style={{ marginLeft: 'auto', background: 'none', border: 'none', padding: 0, color: 'var(--ig-ink-400)' }}><I.Bookmark size={18}/></button>
              </div>
              <h3 style={{ fontSize: 15, fontWeight: 700, lineHeight: 1.3, marginBottom: 6 }}>{o.t}</h3>
              <p style={{ fontSize: 12, color: 'var(--ig-ink-500)', lineHeight: 1.45, marginBottom: 10 }}>{o.d}</p>
              <div style={{ display: 'flex', gap: 12, fontSize: 11, color: 'var(--ig-ink-500)', marginBottom: 12 }}>
                <span><I.Users size={11} style={{ display: 'inline', verticalAlign: '-2px', marginRight: 3 }}/>{o.tgt}</span>
                <span><I.ShieldChk size={11} color="var(--ig-green-600)" style={{ display: 'inline', verticalAlign: '-2px', marginRight: 3 }}/>{o.src}</span>
              </div>
              <button style={{ width: '100%', height: 38, background: 'var(--ig-blue-700)', color: 'white', border: 'none', borderRadius: 6, fontSize: 13, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                Dettagli <I.ArrowR size={13}/>
              </button>
            </article>
          ))}
        </div>
      </div>
      {/* Sticky bottom filter button */}
      <div style={{
        position: 'absolute', bottom: 90, left: 0, right: 0, display: 'flex', justifyContent: 'center',
      }}>
        <button style={{ background: 'var(--ig-ink-900)', color: 'white', border: 'none', borderRadius: 999, padding: '12px 20px', fontSize: 13, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 8, boxShadow: '0 8px 20px rgba(12,26,44,0.25)' }}>
          <I.Sliders size={14}/> Filtri (5)
        </button>
      </div>
      <MobileBottomNav active="Cerca"/>
    </MobileFrame>
  );
}

// ============================================================
// SCHEDA DETAIL MOBILE
// ============================================================
function MobileScheda() {
  return (
    <MobileFrame label="03 · Dettaglio scheda" sublabel="CTA sticky in basso · countdown scadenza">
      <div className="ig" style={{ flex: 1, overflowY: 'auto', background: 'var(--ig-bg)', position: 'relative' }}>
        {/* Top bar */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 16px 12px', background: 'white' }}>
          <button style={{ background: 'var(--ig-ink-50)', border: 'none', width: 36, height: 36, borderRadius: 8 }}><I.ArrowL size={16}/></button>
          <div style={{ display: 'flex', gap: 6 }}>
            <button style={{ background: 'var(--ig-ink-50)', border: 'none', width: 36, height: 36, borderRadius: 8 }}><I.Share size={16}/></button>
            <button style={{ background: 'var(--ig-amber-500)', border: 'none', width: 36, height: 36, borderRadius: 8, color: 'var(--ig-blue-900)' }}><I.BookmarkF size={16}/></button>
          </div>
        </div>

        {/* Header */}
        <div style={{ padding: '4px 20px 16px', background: 'white', borderBottom: '1px solid var(--ig-border-soft)' }}>
          <div style={{ display: 'flex', gap: 6, marginBottom: 12, flexWrap: 'wrap' }}>
            <span className="ig-badge ig-badge--estero" style={{ height: 22, fontSize: 11 }}>Estero & Mobilità</span>
            <span className="ig-badge ig-badge--src-ufficiale" style={{ height: 22, fontSize: 11 }}><I.ShieldChk size={11}/>Ufficiale</span>
          </div>
          <h1 style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.02em', lineHeight: 1.15, marginBottom: 10 }}>
            Erasmus+ Traineeship 2026/27 · tirocini retribuiti in Europa
          </h1>
          <p style={{ fontSize: 13, color: 'var(--ig-ink-500)', lineHeight: 1.5 }}>
            Tirocini da 2 a 12 mesi presso aziende ed enti pubblici in 33 paesi europei.
          </p>
        </div>

        {/* Countdown */}
        <div style={{ margin: '14px 20px', padding: 16, background: 'var(--ig-red-50)', borderRadius: 12, border: '2px solid var(--ig-red-100)' }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-red-700)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4, display: 'flex', alignItems: 'center', gap: 5 }}>
            <I.Alert size={12}/> Scadenza imminente
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
            <span className="ig-num" style={{ fontSize: 38, fontWeight: 800, color: 'var(--ig-red-700)', letterSpacing: '-0.035em', lineHeight: 1 }}>3</span>
            <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--ig-red-700)' }}>giorni</span>
            <span style={{ marginLeft: 'auto', fontSize: 12, color: 'var(--ig-ink-700)' }}>17 marzo · 12:00</span>
          </div>
        </div>

        {/* Quick info */}
        <div style={{ padding: '0 20px 14px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            {[
              ['Contributo', '550-700€', 'al mese'],
              ['Durata', '2-12 mesi', 'consecutivi'],
              ['Età max', '35 anni', 'a candidatura'],
              ['Lingua', 'B1+', 'minimo richiesto'],
            ].map(([l, v, s]) => (
              <div key={l} style={{ padding: 12, background: 'white', borderRadius: 10, border: '1px solid var(--ig-border-soft)' }}>
                <div style={{ fontSize: 10, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{l}</div>
                <div className="ig-num" style={{ fontSize: 18, fontWeight: 800, color: 'var(--ig-blue-700)', letterSpacing: '-0.01em', marginTop: 4 }}>{v}</div>
                <div style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>{s}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Anchor tabs */}
        <div style={{ padding: '0 20px', overflowX: 'auto', whiteSpace: 'nowrap', borderBottom: '1px solid var(--ig-border-soft)', background: 'white' }}>
          {['Cosa offre', 'Chi può', 'Requisiti', 'Come fare', 'Documenti', 'Fonte'].map((t, i) => (
            <a key={t} href="#" style={{
              display: 'inline-block', padding: '14px 0', marginRight: 18,
              fontSize: 13, fontWeight: 600,
              color: i === 0 ? 'var(--ig-blue-700)' : 'var(--ig-ink-700)',
              borderBottom: i === 0 ? '2px solid var(--ig-blue-700)' : 'none',
              marginBottom: -1,
            }}>{t}</a>
          ))}
        </div>

        {/* Content */}
        <div style={{ padding: '18px 20px 100px', background: 'white' }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 10 }}>Cosa offre</h3>
          <p style={{ fontSize: 13, color: 'var(--ig-ink-700)', lineHeight: 1.6, marginBottom: 16 }}>
            Il programma Erasmus+ finanzia tirocini all&apos;estero della durata compresa tra 2 e 12 mesi presso imprese, enti pubblici, ONG e centri di ricerca attivi nell&apos;istruzione, formazione e gioventù.
          </p>
          <div style={{ padding: 14, background: 'var(--ig-green-50)', border: '1px solid var(--ig-green-100)', borderRadius: 10, display: 'flex', gap: 10, alignItems: 'flex-start' }}>
            <I.ShieldChk size={16} color="var(--ig-green-700)"/>
            <div>
              <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-ink-900)' }}>Verificata dagli operatori</div>
              <div style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>Ultimo controllo: 14 marzo 2026 · M. Greco</div>
            </div>
          </div>
        </div>
      </div>

      {/* Sticky CTA */}
      <div style={{
        position: 'absolute', bottom: 86, left: 0, right: 0,
        background: 'white', borderTop: '1px solid var(--ig-border-soft)',
        padding: '12px 20px', display: 'flex', gap: 8,
        boxShadow: '0 -8px 24px rgba(12,26,44,0.06)',
      }}>
        <button style={{ flex: 1, height: 44, background: 'var(--ig-blue-700)', color: 'white', border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
          <I.Send size={14}/> Vai al bando
        </button>
        <button style={{ width: 44, height: 44, background: 'var(--ig-teal-700)', color: 'white', border: 'none', borderRadius: 8 }}>
          <I.Calendar size={16}/>
        </button>
      </div>

      <MobileBottomNav active="Cerca"/>
    </MobileFrame>
  );
}

// ============================================================
// AREA PERSONALE MOBILE
// ============================================================
function MobileAreaPersonale() {
  return (
    <MobileFrame dark label="04 · Area personale" sublabel="Dashboard personale · KPI compatti">
      <div className="ig" style={{ flex: 1, overflowY: 'auto', background: 'var(--ig-bg)' }}>
        {/* Header */}
        <div style={{
          background: 'linear-gradient(160deg, var(--ig-blue-700), var(--ig-blue-800))',
          color: 'white', padding: '10px 20px 28px',
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
            <button style={{ background: 'rgba(255,255,255,0.1)', border: 'none', width: 36, height: 36, borderRadius: 8, color: 'white' }}><I.Menu size={16}/></button>
            <span style={{ fontSize: 13, fontWeight: 700 }}>Area personale</span>
            <button style={{ background: 'rgba(255,255,255,0.1)', border: 'none', width: 36, height: 36, borderRadius: 8, color: 'white', position: 'relative' }}>
              <I.Bell size={16}/>
              <span style={{ position: 'absolute', top: 8, right: 9, width: 7, height: 7, background: 'var(--ig-amber-500)', borderRadius: '50%' }}/>
            </button>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ width: 56, height: 56, borderRadius: '50%', background: 'var(--ig-amber-500)', color: 'var(--ig-blue-900)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 20, border: '3px solid white' }}>SC</div>
            <div>
              <div style={{ fontSize: 18, fontWeight: 800 }}>Ciao, Salvatore</div>
              <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)' }}>Iscritto da 14 mesi · NEET 22 anni</div>
            </div>
          </div>
          <div style={{ marginTop: 16, background: 'rgba(255,255,255,0.08)', borderRadius: 10, padding: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, marginBottom: 6 }}>
              <span style={{ color: 'rgba(255,255,255,0.7)' }}>Completa il profilo</span>
              <span className="ig-num" style={{ color: 'var(--ig-amber-500)', fontWeight: 800 }}>82%</span>
            </div>
            <div style={{ height: 5, background: 'rgba(255,255,255,0.15)', borderRadius: 999, overflow: 'hidden' }}>
              <div style={{ width: '82%', height: '100%', background: 'var(--ig-amber-500)' }}/>
            </div>
          </div>
        </div>

        {/* Next appointment */}
        <div style={{ margin: '-16px 20px 0' }}>
          <div style={{ padding: 14, background: 'var(--ig-amber-500)', borderRadius: 12, color: 'var(--ig-blue-900)', display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ width: 50, textAlign: 'center', padding: '8px 0', borderRadius: 8, background: 'rgba(255,255,255,0.4)' }}>
              <div style={{ fontSize: 11, fontWeight: 800 }}>OGGI</div>
              <div className="ig-num" style={{ fontSize: 14, fontWeight: 800, marginTop: 2 }}>09:30</div>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 700 }}>Appuntamento allo sportello</div>
              <div style={{ fontSize: 11, marginTop: 2 }}>Resto al Sud · con M. Greco</div>
            </div>
            <I.ChevR size={16}/>
          </div>
        </div>

        {/* KPI grid */}
        <div style={{ padding: '20px 20px 14px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {[
            ['14', 'Salvate', 'var(--ig-blue-700)'],
            ['2', 'Candidature', 'var(--ig-teal-700)'],
            ['3', 'Eventi', 'var(--ig-amber-700)'],
            ['1', 'Percorso', 'var(--ig-violet-700)'],
          ].map(([v, l, c]) => (
            <div key={l} style={{ padding: 12, background: 'white', borderRadius: 10, border: '1px solid var(--ig-border-soft)' }}>
              <div className="ig-num" style={{ fontSize: 22, fontWeight: 800, color: c, letterSpacing: '-0.02em' }}>{v}</div>
              <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--ig-ink-500)' }}>{l}</div>
            </div>
          ))}
        </div>

        {/* Section list */}
        <div style={{ padding: '0 20px 16px' }}>
          <h3 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)', marginBottom: 10 }}>Salvate in scadenza</h3>
          {[
            ['Erasmus+ Traineeship 2026', 'estero', 'Estero', '3g', 'urgent', 'Da valutare'],
            ['Servizio Civile · 18 posti', 'civile', 'Civile', '7g', 'urgent', 'Colloquio fissato'],
          ].map((s, i) => (
            <div key={i} style={{ padding: 14, background: 'white', borderRadius: 10, border: '1px solid var(--ig-border-soft)', marginBottom: 8 }}>
              <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
                <span className={`ig-badge ig-badge--${s[1]}`} style={{ height: 18, fontSize: 10, padding: '0 6px' }}>{s[2]}</span>
                <span className={`ig-badge ig-badge--scad-${s[4]}`} style={{ height: 18, fontSize: 10, padding: '0 6px' }}>{s[3]}</span>
              </div>
              <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 4 }}>{s[0]}</div>
              <div style={{ fontSize: 11, color: 'var(--ig-blue-700)', fontWeight: 600 }}>● {s[5]}</div>
            </div>
          ))}
        </div>

        <div style={{ padding: '0 20px 14px' }}>
          <h3 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)', marginBottom: 10 }}>Percorso impresa</h3>
          <div style={{ padding: 16, background: 'var(--ig-teal-50)', borderRadius: 12, border: '1px solid var(--ig-teal-100)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
              <I.Bulb size={18} color="var(--ig-teal-700)"/>
              <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ig-teal-800)' }}>Catering siciliano</div>
              <span style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--ig-teal-800)', fontWeight: 700 }}>3 / 7</span>
            </div>
            <div style={{ height: 5, background: 'white', borderRadius: 999, overflow: 'hidden' }}>
              <div style={{ width: '42%', height: '100%', background: 'var(--ig-teal-700)' }}/>
            </div>
            <div style={{ fontSize: 11, color: 'var(--ig-ink-700)', marginTop: 8 }}>Fase: <strong>Business Model Canvas</strong></div>
          </div>
        </div>
      </div>
      <MobileBottomNav active="Profilo"/>
    </MobileFrame>
  );
}

// ============================================================
// COMPOSITE — all 4 phones side by side
// ============================================================
function MobileScreens() {
  return (
    <div style={{ display: 'flex', gap: 56, padding: 24, fontFamily: 'var(--ig-font)' }}>
      <MobileHomepage/>
      <MobileList/>
      <MobileScheda/>
      <MobileAreaPersonale/>
    </div>
  );
}

window.MobileScreens = MobileScreens;
