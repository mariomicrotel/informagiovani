/* global React, IGIcons, BackendShell, PageHeader */
const I = IGIcons;

function BackendNewsletterScreen() {
  return (
    <BackendShell active="Newsletter" breadcrumb={['Console', 'Contenuti', 'Newsletter', 'Marzo 2026 · settimana 11']} height={1700}>
      <PageHeader
        title="Newsletter · Marzo 2026 · settimana 11"
        subtitle="Bozza salvata 2 minuti fa · destinatari stimati 1.847 · tasso apertura previsto 41%"
        actions={<>
          <button className="ig-btn ig-btn--ghost ig-btn--sm">Anteprima desktop</button>
          <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Send size={14}/> Invio test</button>
          <button className="ig-btn ig-btn--secondary ig-btn--sm">Programma invio</button>
          <button className="ig-btn ig-btn--primary ig-btn--sm"><I.Send size={14}/> Invio immediato</button>
        </>}
        tabs={['Dashboard', 'Compositore', 'Destinatari · 1.847', 'Anteprima', 'Programmazione', 'Storico']}
        activeTab="Compositore"
      />

      <div style={{ padding: '24px 32px 32px', display: 'grid', gridTemplateColumns: '1fr 480px', gap: 20 }}>
        {/* COMPOSER */}
        <div>
          {/* Recipients */}
          <div className="ig-card" style={{ padding: 22, marginBottom: 16 }}>
            <h3 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)', marginBottom: 14 }}>01 · Destinatari</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 14 }}>
              <div>
                <label className="ig-label">Segmento principale</label>
                <div className="ig-input" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', color: 'var(--ig-ink-900)' }}>
                  <span>Iscritti attivi · ultimi 6 mesi</span>
                  <I.ChevD size={16} color="var(--ig-ink-500)"/>
                </div>
              </div>
              <div>
                <label className="ig-label">Target</label>
                <div className="ig-input" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', color: 'var(--ig-ink-900)' }}>
                  <span>18–35 anni · provincia di Enna</span>
                  <I.ChevD size={16} color="var(--ig-ink-500)"/>
                </div>
              </div>
            </div>
            <div>
              <label className="ig-label">Interessi · filtri aggiuntivi</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {[
                  ['Lavoro', true],
                  ['Fare Impresa', true],
                  ['Formazione', false],
                  ['Estero', true],
                  ['Concorsi', true],
                  ['Cultura', false],
                  ['Sport', false],
                  ['Servizio Civile', true],
                  ['NEET', true],
                ].map(([label, on]) => (
                  <span key={label} style={{
                    display: 'inline-flex', alignItems: 'center', gap: 6, height: 30, padding: '0 10px', borderRadius: 6,
                    background: on ? 'var(--ig-blue-50)' : 'white', border: `1px solid ${on ? 'var(--ig-blue-700)' : 'var(--ig-border)'}`,
                    color: on ? 'var(--ig-blue-700)' : 'var(--ig-ink-700)', fontSize: 12, fontWeight: 600, cursor: 'pointer',
                  }}>
                    {on && <I.Check size={12}/>} {label}
                  </span>
                ))}
              </div>
            </div>
            <div style={{ marginTop: 14, padding: 14, background: 'var(--ig-blue-50)', borderRadius: 8, display: 'flex', alignItems: 'center', gap: 14 }}>
              <I.Users size={18} color="var(--ig-blue-700)"/>
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ig-blue-800)' }}>1.847 destinatari corrispondono ai filtri</div>
                <div style={{ fontSize: 12, color: 'var(--ig-ink-700)', marginTop: 2 }}>su 2.140 totali · 86% del database</div>
              </div>
              <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ marginLeft: 'auto', color: 'var(--ig-blue-700)' }}>Vedi elenco completo →</button>
            </div>
          </div>

          {/* Subject + content */}
          <div className="ig-card" style={{ padding: 22, marginBottom: 16 }}>
            <h3 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)', marginBottom: 14 }}>02 · Oggetto e testo introduttivo</h3>
            <div style={{ marginBottom: 14 }}>
              <label className="ig-label">Oggetto email <span style={{ color: 'var(--ig-ink-400)', fontWeight: 400 }}>(46/60 caratteri)</span></label>
              <input className="ig-input" defaultValue="🎯 Erasmus+ scade venerdì · 4 nuove opportunità"/>
              <div style={{ display: 'flex', gap: 10, marginTop: 6 }}>
                <span style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>Anteprima: <strong style={{ color: 'var(--ig-ink-700)' }}>Erasmus+, Resto al Sud e Servizio Civile · le scadenze di marzo da non perdere</strong></span>
              </div>
            </div>
            <div style={{ marginBottom: 14 }}>
              <label className="ig-label">Titolo principale</label>
              <input className="ig-input" defaultValue="Le opportunità in scadenza questa settimana"/>
            </div>
            <div>
              <label className="ig-label">Testo introduttivo</label>
              <textarea className="ig-textarea" style={{ minHeight: 90 }} defaultValue={`Ciao {nome},\n\nquesta settimana abbiamo selezionato per te 4 opportunità in scadenza imminente e 3 eventi gratuiti a Enna. Se hai bisogno di orientamento personalizzato, ricordati che lo sportello è aperto tutti i giorni dalle 9:00 alle 17:30.`}/>
            </div>
          </div>

          {/* Schede selezione */}
          <div className="ig-card" style={{ padding: 22, marginBottom: 16 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
              <h3 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)' }}>03 · Schede da includere</h3>
              <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ color: 'var(--ig-blue-700)' }}><I.Plus size={14}/> Aggiungi scheda</button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {[
                ['ERA-2026-117', 'Erasmus+ Traineeship 2026/27', 'estero', 'Estero', '17 mar · 3g', true],
                ['IMP-2026-085', 'Resto al Sud · fondo perduto 200k€', 'impresa', 'Impresa', 'Sempre aperta', true],
                ['SCN-2026-022', 'Servizio Civile Universale 2026', 'civile', 'Civile', '21 mar · 7g', true],
                ['CON-2026-046', 'Concorso 4 Istruttori Comune di Enna', 'concorso', 'Concorsi', '4 apr · 21g', true],
              ].map(([id, t, ac, area, when, sel]) => (
                <div key={id} style={{
                  display: 'flex', alignItems: 'center', gap: 14, padding: '12px 14px',
                  border: '1px solid var(--ig-blue-300)', background: 'var(--ig-blue-50)', borderRadius: 8,
                }}>
                  <span style={{ width: 18, height: 18, borderRadius: 4, background: 'var(--ig-blue-700)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flex: '0 0 auto' }}>
                    <I.Check size={12} color="white" strokeWidth={3}/>
                  </span>
                  <span style={{ width: 14, color: 'var(--ig-ink-400)', cursor: 'grab' }}>⋮⋮</span>
                  <span style={{ fontFamily: 'var(--ig-font-mono)', fontSize: 11, color: 'var(--ig-ink-500)' }}>{id}</span>
                  <span style={{ flex: 1, fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-900)' }}>{t}</span>
                  <span className={`ig-badge ig-badge--${ac}`} style={{ height: 22, fontSize: 11 }}>{area}</span>
                  <span style={{ fontSize: 12, color: 'var(--ig-ink-500)', minWidth: 100 }}>{when}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Eventi */}
          <div className="ig-card" style={{ padding: 22, marginBottom: 16 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
              <h3 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)' }}>04 · Eventi da includere</h3>
              <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ color: 'var(--ig-blue-700)' }}><I.Plus size={14}/> Aggiungi evento</button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {[
                [22, 'MAR', 'Workshop: scrivi il tuo curriculum', '8 / 12 posti', true],
                [26, 'MAR', 'Costruisci la tua idea di impresa', '32 / 50 posti', true],
                [3, 'APR', 'Resto al Sud · come candidarsi', '28 / 30 posti', false],
              ].map(([d, m, t, p, sel], i) => (
                <div key={i} style={{
                  display: 'flex', alignItems: 'center', gap: 14, padding: '12px 14px',
                  border: `1px solid ${sel ? 'var(--ig-teal-100)' : 'var(--ig-border-soft)'}`,
                  background: sel ? 'var(--ig-teal-50)' : 'white', borderRadius: 8,
                }}>
                  <span style={{
                    width: 18, height: 18, borderRadius: 4,
                    background: sel ? 'var(--ig-teal-700)' : 'white',
                    border: sel ? 'none' : '1.5px solid var(--ig-ink-300)',
                    display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flex: '0 0 auto',
                  }}>{sel && <I.Check size={12} color="white" strokeWidth={3}/>}</span>
                  <div style={{ width: 44, textAlign: 'center', padding: '4px 0', borderRadius: 6, background: 'white', color: 'var(--ig-teal-700)', border: '1px solid var(--ig-teal-100)', fontSize: 11, fontWeight: 700 }}>
                    <div className="ig-num" style={{ fontSize: 14, fontWeight: 800 }}>{d}</div>
                    {m}
                  </div>
                  <span style={{ flex: 1, fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-900)' }}>{t}</span>
                  <span style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}>{p}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* PREVIEW */}
        <aside>
          <div style={{ position: 'sticky', top: 24 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
              <I.Eye size={16} color="var(--ig-ink-700)"/>
              <h3 style={{ fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)' }}>Anteprima email</h3>
              <div style={{ marginLeft: 'auto', display: 'flex', border: '1px solid var(--ig-border)', borderRadius: 6, overflow: 'hidden' }}>
                <button style={{ background: 'var(--ig-ink-900)', color: 'white', border: 'none', padding: '4px 10px', fontSize: 11, fontWeight: 700, cursor: 'pointer' }}>Desktop</button>
                <button style={{ background: 'white', color: 'var(--ig-ink-700)', border: 'none', padding: '4px 10px', fontSize: 11, fontWeight: 600, cursor: 'pointer' }}>Mobile</button>
              </div>
            </div>
            <div style={{
              background: 'white', border: '1px solid var(--ig-border)', borderRadius: 10,
              overflow: 'hidden', boxShadow: '0 12px 32px rgba(12,26,44,0.10)',
            }}>
              {/* Email header */}
              <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--ig-border-soft)', background: 'var(--ig-ink-50)' }}>
                <div style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>da · <strong style={{ color: 'var(--ig-ink-700)' }}>Informagiovani Enna &lt;newsletter@informagiovani.enna.it&gt;</strong></div>
                <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', marginTop: 2 }}>a · Salvatore Catanzaro</div>
                <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ig-ink-900)', marginTop: 8 }}>🎯 Erasmus+ scade venerdì · 4 nuove opportunità</div>
              </div>
              {/* Email body */}
              <div style={{ padding: 0 }}>
                <div style={{ background: 'var(--ig-blue-700)', color: 'white', padding: '20px 24px' }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-amber-500)', letterSpacing: '0.1em', marginBottom: 6 }}>INFORMAGIOVANI ENNA</div>
                  <div style={{ fontSize: 20, fontWeight: 800, letterSpacing: '-0.01em', lineHeight: 1.2 }}>Le opportunità in scadenza questa settimana</div>
                </div>
                <div style={{ padding: '20px 24px', borderBottom: '1px solid var(--ig-border-soft)' }}>
                  <div style={{ fontSize: 13, color: 'var(--ig-ink-700)', lineHeight: 1.55 }}>
                    Ciao <strong>Salvatore</strong>,<br/><br/>
                    questa settimana abbiamo selezionato per te 4 opportunità in scadenza imminente e 3 eventi gratuiti a Enna.
                  </div>
                </div>
                <div style={{ padding: '16px 24px' }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 12 }}>Schede in scadenza</div>
                  {[
                    ['Erasmus+ Traineeship 2026/27', 'estero', 'Estero', '17 marzo · 3g', 'urgent'],
                    ['Resto al Sud · fondo perduto', 'impresa', 'Impresa', 'Sempre aperta', 'ok'],
                    ['Servizio Civile 2026', 'civile', 'Civile', '21 marzo · 7g', 'urgent'],
                    ['Concorso Istruttore Amm.vo', 'concorso', 'Concorsi', '4 aprile · 21g', 'soon'],
                  ].map((s, i) => (
                    <div key={i} style={{ padding: '12px 0', borderBottom: i < 3 ? '1px solid var(--ig-border-soft)' : 'none', display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-ink-900)', marginBottom: 4 }}>{s[0]}</div>
                        <div style={{ display: 'flex', gap: 6 }}>
                          <span className={`ig-badge ig-badge--${s[1]}`} style={{ height: 18, fontSize: 10, padding: '0 6px' }}>{s[2]}</span>
                          <span className={`ig-badge ig-badge--scad-${s[4]}`} style={{ height: 18, fontSize: 10, padding: '0 6px' }}>{s[3]}</span>
                        </div>
                      </div>
                      <I.ChevR size={14} color="var(--ig-ink-400)"/>
                    </div>
                  ))}
                </div>
                <div style={{ padding: 16, background: 'var(--ig-ink-50)', textAlign: 'center' }}>
                  <a href="#" style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'var(--ig-blue-700)', color: 'white', padding: '10px 18px', borderRadius: 6, fontSize: 12, fontWeight: 700, textDecoration: 'none' }}>
                    Vedi tutte le opportunità <I.ArrowR size={12}/>
                  </a>
                </div>
                <div style={{ padding: '12px 24px', fontSize: 10, color: 'var(--ig-ink-400)', textAlign: 'center', borderTop: '1px solid var(--ig-border-soft)' }}>
                  Hai ricevuto questa email come iscritto a Informagiovani Enna · <a href="#" style={{ color: 'var(--ig-ink-500)' }}>Disiscriviti</a> · <a href="#" style={{ color: 'var(--ig-ink-500)' }}>Modifica preferenze</a>
                </div>
              </div>
            </div>

            <div className="ig-card" style={{ padding: 18, marginTop: 16 }}>
              <h3 style={{ fontSize: 12, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)', marginBottom: 12 }}>Previsione invio</h3>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                {[
                  ['1.847', 'Destinatari', 'var(--ig-blue-700)'],
                  ['~41%', 'Tasso apertura', 'var(--ig-green-700)'],
                  ['~18%', 'Tasso click', 'var(--ig-teal-700)'],
                  ['< 1%', 'Bounce stimato', 'var(--ig-amber-700)'],
                ].map(([v, l, c]) => (
                  <div key={l}>
                    <div className="ig-num" style={{ fontSize: 18, fontWeight: 800, color: c, letterSpacing: '-0.02em' }}>{v}</div>
                    <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', marginTop: 2 }}>{l}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </aside>
      </div>
    </BackendShell>
  );
}

window.BackendNewsletterScreen = BackendNewsletterScreen;
