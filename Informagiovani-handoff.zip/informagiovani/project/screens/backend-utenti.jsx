/* global React, IGIcons, BackendShell, PageHeader */
const I = IGIcons;

// Dettaglio utente — vista più ricca della lista.
function ProfileField({ label, value, accent }) {
  return (
    <div>
      <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 14, fontWeight: 600, color: accent || 'var(--ig-ink-900)' }}>{value}</div>
    </div>
  );
}

function Chip({ label, color, bg }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', height: 26, padding: '0 10px', borderRadius: 999,
      background: bg || 'var(--ig-ink-100)', color: color || 'var(--ig-ink-700)',
      fontSize: 12, fontWeight: 600,
    }}>{label}</span>
  );
}

function TimelineEvent({ when, icon, color, title, desc, by }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '90px 40px 1fr', gap: 12, padding: '12px 0', borderBottom: '1px solid var(--ig-border-soft)' }}>
      <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', paddingTop: 8 }}>{when}</div>
      <div style={{
        width: 32, height: 32, borderRadius: '50%', background: color, color: 'white',
        display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: 4,
      }}>{icon}</div>
      <div>
        <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ig-ink-900)' }}>{title}</div>
        <div style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginTop: 2 }}>{desc}</div>
        {by && <div style={{ fontSize: 11, color: 'var(--ig-ink-400)', marginTop: 4 }}>{by}</div>}
      </div>
    </div>
  );
}

function BackendUtentiScreen() {
  return (
    <BackendShell active="Utenti giovani" breadcrumb={['Console', 'Sportello', 'Utenti giovani', 'Salvatore Catanzaro']} height={1800}>
      <PageHeader
        title="Salvatore Catanzaro"
        subtitle="ID utente · USR-001284 · iscritto da 14 mesi · ultimo accesso 12 minuti fa"
        actions={<>
          <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Mail size={14}/> Email</button>
          <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Calendar size={14}/> Nuovo appuntamento</button>
          <button className="ig-btn ig-btn--primary ig-btn--sm"><I.Chat size={14}/> Avvia colloquio</button>
          <button className="ig-btn ig-btn--ghost ig-btn--icon" style={{ width: 38 }}><I.ChevD size={16}/></button>
        </>}
        tabs={['Profilo', 'Colloqui · 4', 'Appuntamenti · 6', 'Ticket · 2', 'Opportunità salvate · 14', 'Eventi · 3', 'Percorso impresa', 'Privacy']}
        activeTab="Profilo"
      />

      <div style={{ padding: '24px 32px 32px', display: 'grid', gridTemplateColumns: '320px 1fr', gap: 24 }}>
        {/* SIDEBAR PROFILE CARD */}
        <aside>
          <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
            {/* Avatar header */}
            <div style={{
              background: 'linear-gradient(135deg, var(--ig-blue-700) 0%, var(--ig-blue-800) 100%)',
              padding: '28px 24px 50px', position: 'relative', textAlign: 'center',
            }}>
              <div style={{
                width: 88, height: 88, borderRadius: '50%',
                background: 'var(--ig-amber-500)', color: 'var(--ig-blue-900)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 30, fontWeight: 800, margin: '0 auto', border: '4px solid white',
                boxShadow: '0 6px 18px rgba(0,0,0,0.18)',
              }}>SC</div>
              <div style={{ position: 'absolute', bottom: 16, left: 0, right: 0, display: 'flex', justifyContent: 'center', gap: 8 }}>
                <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.65)' }}>22 anni · NEET · Enna</span>
              </div>
            </div>

            {/* Quick info */}
            <div style={{ padding: '20px 22px' }}>
              <div style={{ textAlign: 'center', marginBottom: 18 }}>
                <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 4 }}>Salvatore Catanzaro</h2>
                <div style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>s.catanzaro@email.it</div>
                <div style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>+39 320 412 8745</div>
              </div>

              <div style={{ display: 'flex', gap: 6, justifyContent: 'center', marginBottom: 20, flexWrap: 'wrap' }}>
                <Chip label="NEET" bg="var(--ig-amber-100)" color="var(--ig-amber-800)"/>
                <Chip label="Aspirante imprenditore" bg="var(--ig-teal-100)" color="var(--ig-teal-700)"/>
                <Chip label="Disoccupato" bg="var(--ig-ink-100)" color="var(--ig-ink-700)"/>
              </div>

              {/* Profile completion */}
              <div style={{ background: 'var(--ig-ink-50)', borderRadius: 10, padding: 14, marginBottom: 18 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, fontWeight: 700, color: 'var(--ig-ink-700)', marginBottom: 6 }}>
                  <span>Completamento profilo</span>
                  <span className="ig-num">82%</span>
                </div>
                <div style={{ height: 6, background: 'var(--ig-ink-150)', borderRadius: 999, overflow: 'hidden' }}>
                  <div style={{ width: '82%', height: '100%', background: 'linear-gradient(90deg, var(--ig-teal-600), var(--ig-teal-700))' }}/>
                </div>
                <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', marginTop: 8 }}>Manca: certificazione linguistica, foto profilo</div>
              </div>

              {/* Stats */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 18 }}>
                <div style={{ padding: '12px', background: 'var(--ig-ink-50)', borderRadius: 8, textAlign: 'center' }}>
                  <div className="ig-num" style={{ fontSize: 22, fontWeight: 800, color: 'var(--ig-blue-700)' }}>4</div>
                  <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', marginTop: 2 }}>Colloqui</div>
                </div>
                <div style={{ padding: '12px', background: 'var(--ig-ink-50)', borderRadius: 8, textAlign: 'center' }}>
                  <div className="ig-num" style={{ fontSize: 22, fontWeight: 800, color: 'var(--ig-teal-700)' }}>14</div>
                  <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', marginTop: 2 }}>Salvate</div>
                </div>
                <div style={{ padding: '12px', background: 'var(--ig-ink-50)', borderRadius: 8, textAlign: 'center' }}>
                  <div className="ig-num" style={{ fontSize: 22, fontWeight: 800, color: 'var(--ig-amber-700)' }}>2</div>
                  <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', marginTop: 2 }}>Candidature</div>
                </div>
                <div style={{ padding: '12px', background: 'var(--ig-ink-50)', borderRadius: 8, textAlign: 'center' }}>
                  <div className="ig-num" style={{ fontSize: 22, fontWeight: 800, color: 'var(--ig-violet-700)' }}>1</div>
                  <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', marginTop: 2 }}>Percorso</div>
                </div>
              </div>

              <button className="ig-btn ig-btn--secondary" style={{ width: '100%', justifyContent: 'center' }}>
                <I.Doc size={16}/> Scarica fascicolo PDF
              </button>
            </div>
          </div>
        </aside>

        {/* MAIN */}
        <div>
          {/* Banner active percorso */}
          <div style={{
            background: 'linear-gradient(120deg, var(--ig-teal-50) 0%, var(--ig-blue-50) 100%)',
            border: '1px solid var(--ig-teal-100)', borderRadius: 12,
            padding: '18px 22px', display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24,
          }}>
            <div style={{ width: 44, height: 44, borderRadius: 10, background: 'var(--ig-teal-700)', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <I.Bulb size={22}/>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ig-ink-900)' }}>Percorso impresa attivo · &quot;Catering siciliano per eventi&quot;</div>
              <div style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginTop: 2 }}>
                Fase: Business Model Canvas · Tutor: F. Bellomo · Prossimo incontro: 18 marzo 2026
              </div>
            </div>
            <button className="ig-btn ig-btn--secondary ig-btn--sm">Apri percorso →</button>
          </div>

          {/* SECTION: Dati personali */}
          <div className="ig-card" style={{ padding: 24, marginBottom: 20 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 8 }}>
                <I.User size={18} color="var(--ig-blue-700)"/> Dati personali e formazione
              </h3>
              <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ color: 'var(--ig-blue-700)' }}><I.Edit size={14}/> Modifica</button>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 18 }}>
              <ProfileField label="Data di nascita" value="14 marzo 2004"/>
              <ProfileField label="Età" value="22 anni"/>
              <ProfileField label="Comune" value="Enna"/>
              <ProfileField label="Codice fiscale" value="CTNSVT04C14C342K"/>
              <ProfileField label="Titolo di studio" value="Diploma tecnico"/>
              <ProfileField label="Anno conseguimento" value="2023"/>
              <ProfileField label="Istituto" value="ITT &quot;F. Brunelleschi&quot;"/>
              <ProfileField label="Voto" value="86/100"/>
              <ProfileField label="Stato occupazionale" value="Disoccupato" accent="var(--ig-amber-800)"/>
              <ProfileField label="Disponibilità" value="Immediata · full-time"/>
              <ProfileField label="Patente" value="B · automunito"/>
              <ProfileField label="Iscrizione CPI" value="Sì · 2024"/>
            </div>
          </div>

          {/* Two-column inner */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 20 }}>
            {/* Competenze e interessi */}
            <div className="ig-card" style={{ padding: 24 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 18, display: 'flex', alignItems: 'center', gap: 8 }}>
                <I.Sparkle size={18} color="var(--ig-teal-700)"/> Interessi e competenze
              </h3>
              <div style={{ marginBottom: 16 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>Aree di interesse</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  <Chip label="Fare Impresa" bg="var(--ig-teal-100)" color="var(--ig-teal-700)"/>
                  <Chip label="Lavoro" bg="var(--ig-blue-100)" color="var(--ig-blue-800)"/>
                  <Chip label="Formazione professionale" bg="var(--ig-violet-100)" color="var(--ig-violet-700)"/>
                  <Chip label="Estero" bg="var(--ig-amber-100)" color="var(--ig-amber-800)"/>
                </div>
              </div>
              <div style={{ marginBottom: 16 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>Competenze</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  {['Cucina · base', 'Servizio sala', 'HACCP', 'Excel · intermedio', 'Patente HACCP', 'Microsoft Office', 'Social media · base'].map(c => <Chip key={c} label={c}/>)}
                </div>
              </div>
              <div style={{ marginBottom: 16 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>Lingue</div>
                <div style={{ display: 'flex', gap: 14, fontSize: 13 }}>
                  <span><strong>Italiano</strong> · madrelingua</span>
                  <span><strong>Inglese</strong> · B1 (auto-dichiarato)</span>
                </div>
              </div>
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>Competenze digitali · DigComp</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, fontSize: 12 }}>
                  {[['Information literacy', 60], ['Comunicazione', 45], ['Creazione contenuti', 30], ['Sicurezza', 55], ['Problem solving', 50]].map(([l, p]) => (
                    <div key={l}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                        <span style={{ color: 'var(--ig-ink-700)' }}>{l}</span>
                        <span className="ig-num" style={{ color: 'var(--ig-ink-500)', fontWeight: 600 }}>{p}%</span>
                      </div>
                      <div style={{ height: 4, background: 'var(--ig-ink-150)', borderRadius: 2, overflow: 'hidden' }}>
                        <div style={{ width: `${p}%`, height: '100%', background: 'var(--ig-blue-700)' }}/>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* CV */}
            <div className="ig-card" style={{ padding: 24 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 18, display: 'flex', alignItems: 'center', gap: 8 }}>
                <I.Doc size={18} color="var(--ig-blue-700)"/> Documenti caricati
              </h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {[
                  ['CV Europass · ITA', 'PDF · 234 KB · v3', 'aggiornato 8 giorni fa', true],
                  ['CV · ENG', 'PDF · 198 KB · v1', 'aggiornato 21 giorni fa', false],
                  ['Diploma tecnico', 'PDF · 1.2 MB', 'caricato 14 mesi fa', false],
                  ['Carta d\u2019identità', 'PDF · 312 KB', 'in scadenza tra 3 mesi', false],
                  ['Lettera motivazionale · Resto al Sud', 'PDF · 145 KB · bozza', 'in revisione dal tutor', true],
                ].map(([n, m, w, fresh]) => (
                  <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 12, border: '1px solid var(--ig-border-soft)', borderRadius: 8, background: 'white' }}>
                    <div style={{ width: 32, height: 36, borderRadius: 4, background: 'var(--ig-blue-100)', color: 'var(--ig-blue-700)', display: 'flex', alignItems: 'center', justifyContent: 'center', flex: '0 0 auto' }}>
                      <I.Doc size={16}/>
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-900)' }}>{n}</div>
                      <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', marginTop: 2 }}>{m} · {w}</div>
                    </div>
                    {fresh && <span style={{ fontSize: 10, fontWeight: 700, background: 'var(--ig-green-100)', color: 'var(--ig-green-700)', padding: '2px 6px', borderRadius: 4, textTransform: 'uppercase', letterSpacing: '0.04em' }}>nuovo</span>}
                    <button className="ig-btn ig-btn--ghost ig-btn--sm ig-btn--icon" style={{ width: 28, height: 28 }}><I.Download size={14}/></button>
                  </div>
                ))}
              </div>
              <button className="ig-btn ig-btn--ghost" style={{ marginTop: 12, color: 'var(--ig-blue-700)', width: '100%', justifyContent: 'center' }}>
                <I.Plus size={14}/> Carica un nuovo documento
              </button>
            </div>
          </div>

          {/* TIMELINE */}
          <div className="ig-card" style={{ padding: 24 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 8 }}>
                <I.Clock size={18} color="var(--ig-blue-700)"/> Attività recente
              </h3>
              <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ color: 'var(--ig-blue-700)' }}>Vedi tutta la timeline →</button>
            </div>
            <div>
              <TimelineEvent
                when="oggi 12:14" icon={<I.Send size={14}/>} color="var(--ig-blue-700)"
                title="Richiesta #R-2841 inviata"
                desc="Documentazione Resto al Sud · ente promotore, allegati e timeline"
                by="da Salvatore Catanzaro"
              />
              <TimelineEvent
                when="ieri 16:30" icon={<I.Calendar size={14}/>} color="var(--ig-teal-700)"
                title="Appuntamento prenotato"
                desc="Sabato 14 marzo · 09:30 · in presenza con M. Greco · &quot;Resto al Sud: documentazione&quot;"
                by="da Area Personale"
              />
              <TimelineEvent
                when="3 giorni fa" icon={<I.Bookmark size={14}/>} color="var(--ig-amber-600)"
                title="3 nuove opportunità salvate"
                desc="Resto al Sud · Microcredito Sicilia · Concorso Istruttore Amm.vo Comune di Enna"
              />
              <TimelineEvent
                when="5 giorni fa" icon={<I.Chat size={14}/>} color="var(--ig-violet-600)"
                title="Colloquio completato"
                desc="Idea food truck · BMC redatto · obiettivi: ricerca microcredito, business plan entro 30 giorni"
                by="con F. Bellomo · Fare Impresa"
              />
              <TimelineEvent
                when="2 settimane fa" icon={<I.Edit size={14}/>} color="var(--ig-ink-500)"
                title="Profilo aggiornato"
                desc="Aggiunto stato occupazionale: disoccupato · iscritto al CPI"
              />
            </div>
          </div>
        </div>
      </div>
    </BackendShell>
  );
}

window.BackendUtentiScreen = BackendUtentiScreen;
