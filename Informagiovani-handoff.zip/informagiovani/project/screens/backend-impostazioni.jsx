/* global React, IGIcons, BackendShell, PageHeader */
const I = IGIcons;

function SettingsRow({ label, hint, children, action }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr 120px', gap: 24, padding: '20px 0', borderBottom: '1px solid var(--ig-border-soft)', alignItems: 'flex-start' }}>
      <div>
        <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ig-ink-900)' }}>{label}</div>
        {hint && <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginTop: 4 }}>{hint}</div>}
      </div>
      <div>{children}</div>
      <div style={{ textAlign: 'right' }}>{action}</div>
    </div>
  );
}

function Toggle({ on }) {
  return (
    <span style={{
      display: 'inline-flex', width: 38, height: 22, borderRadius: 999,
      background: on ? 'var(--ig-blue-700)' : 'var(--ig-ink-300)',
      padding: 2, transition: 'background .15s',
    }}>
      <span style={{ width: 18, height: 18, borderRadius: '50%', background: 'white', transform: on ? 'translateX(16px)' : 'translateX(0)', transition: 'transform .15s' }}/>
    </span>
  );
}

function VerticalTab({ icon, label, active }) {
  return (
    <a href="#" style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '11px 14px', borderRadius: 8,
      fontSize: 14, fontWeight: 600,
      color: active ? 'var(--ig-blue-700)' : 'var(--ig-ink-700)',
      background: active ? 'var(--ig-blue-50)' : 'transparent',
      borderLeft: active ? '3px solid var(--ig-blue-700)' : '3px solid transparent', marginLeft: -3,
      textDecoration: 'none',
    }}>
      <span style={{ color: active ? 'var(--ig-blue-700)' : 'var(--ig-ink-400)' }}>{icon}</span>
      {label}
    </a>
  );
}

function BackendImpostazioniScreen() {
  return (
    <BackendShell active="Impostazioni" breadcrumb={['Console', 'Ecosistema', 'Impostazioni', 'Appuntamenti']} height={1700}>
      <PageHeader
        title="Impostazioni"
        subtitle="Configura il servizio · sezione: Appuntamenti · ultimo aggiornamento 3 giorni fa da G. Fontana"
        actions={<>
          <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ color: 'var(--ig-red-700)' }}>Annulla modifiche</button>
          <button className="ig-btn ig-btn--primary ig-btn--sm"><I.Check size={14}/> Salva impostazioni</button>
        </>}
      />

      <div style={{ padding: '24px 32px 32px', display: 'grid', gridTemplateColumns: '260px 1fr', gap: 28 }}>
        {/* Vertical tabs */}
        <aside>
          <div className="ig-card" style={{ padding: 12 }}>
            <div style={{ fontSize: 11, fontWeight: 800, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.08em', padding: '0 14px 12px' }}>Generale</div>
            <VerticalTab icon={<I.Settings size={18}/>} label="Generale"/>
            <VerticalTab icon={<I.Shield size={18}/>} label="Privacy e GDPR"/>
            <VerticalTab icon={<I.Mail size={18}/>} label="Email & template"/>

            <div style={{ fontSize: 11, fontWeight: 800, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.08em', padding: '14px 14px 10px', marginTop: 10 }}>Operatività</div>
            <VerticalTab icon={<I.Calendar size={18}/>} label="Appuntamenti" active/>
            <VerticalTab icon={<I.Doc size={18}/>} label="Schede & validazione"/>
            <VerticalTab icon={<I.Flag size={18}/>} label="Ticket & SLA"/>

            <div style={{ fontSize: 11, fontWeight: 800, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.08em', padding: '14px 14px 10px', marginTop: 10 }}>Avanzate</div>
            <VerticalTab icon={<I.Sparkle size={18}/>} label="AI & suggerimenti"/>
            <VerticalTab icon={<I.Chart size={18}/>} label="Report & destinatari"/>
            <VerticalTab icon={<I.Users size={18}/>} label="Ruoli & permessi"/>
            <VerticalTab icon={<I.Link size={18}/>} label="Integrazioni"/>
          </div>
        </aside>

        {/* Settings content — Appuntamenti */}
        <div className="ig-card" style={{ padding: 28 }}>
          <div style={{ marginBottom: 14, paddingBottom: 16, borderBottom: '1px solid var(--ig-border-soft)' }}>
            <h2 style={{ fontSize: 22, fontWeight: 700, color: 'var(--ig-ink-900)', display: 'flex', alignItems: 'center', gap: 10 }}>
              <I.Calendar size={22} color="var(--ig-blue-700)"/> Appuntamenti
            </h2>
            <p style={{ fontSize: 13, color: 'var(--ig-ink-500)', marginTop: 6 }}>Definisci gli orari di sportello, gli slot disponibili e gli operatori abilitati alla gestione degli appuntamenti.</p>
          </div>

          <SettingsRow label="Stato sportello" hint="Quando lo sportello è chiuso, i form di prenotazione mostrano un avviso.">
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <Toggle on={true}/>
              <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--ig-green-700)' }}>Aperto · accetta prenotazioni</span>
            </div>
          </SettingsRow>

          <SettingsRow label="Giorni di apertura" hint="Imposta i giorni della settimana in cui sono disponibili gli slot.">
            <div style={{ display: 'flex', gap: 6 }}>
              {[['Lun', true], ['Mar', true], ['Mer', true], ['Gio', true], ['Ven', true], ['Sab', true], ['Dom', false]].map(([d, on]) => (
                <span key={d} style={{
                  width: 44, height: 44, borderRadius: 8,
                  background: on ? 'var(--ig-blue-700)' : 'white',
                  color: on ? 'white' : 'var(--ig-ink-500)',
                  border: `1px solid ${on ? 'var(--ig-blue-700)' : 'var(--ig-border)'}`,
                  display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 12, fontWeight: 700, cursor: 'pointer',
                }}>{d}</span>
              ))}
            </div>
          </SettingsRow>

          <SettingsRow label="Fasce orarie giornaliere" hint="Le fasce vengono applicate a tutti i giorni di apertura. La pausa pranzo non genera slot.">
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span className="ig-badge ig-badge--state-pub">Mattina</span>
                <div className="ig-input" style={{ width: 130, height: 38, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 10px', fontSize: 13 }}>09:00 <I.ChevD size={12} color="var(--ig-ink-400)"/></div>
                <span style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>→</span>
                <div className="ig-input" style={{ width: 130, height: 38, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 10px', fontSize: 13 }}>13:00 <I.ChevD size={12} color="var(--ig-ink-400)"/></div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span className="ig-badge" style={{ background: 'var(--ig-amber-100)', color: 'var(--ig-amber-800)' }}>Pausa</span>
                <div className="ig-input" style={{ width: 130, height: 38, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 10px', fontSize: 13 }}>13:00 <I.ChevD size={12} color="var(--ig-ink-400)"/></div>
                <span style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>→</span>
                <div className="ig-input" style={{ width: 130, height: 38, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 10px', fontSize: 13 }}>15:00 <I.ChevD size={12} color="var(--ig-ink-400)"/></div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span className="ig-badge ig-badge--state-pub">Pomeriggio</span>
                <div className="ig-input" style={{ width: 130, height: 38, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 10px', fontSize: 13 }}>15:00 <I.ChevD size={12} color="var(--ig-ink-400)"/></div>
                <span style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>→</span>
                <div className="ig-input" style={{ width: 130, height: 38, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 10px', fontSize: 13 }}>17:30 <I.ChevD size={12} color="var(--ig-ink-400)"/></div>
              </div>
              <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ color: 'var(--ig-blue-700)', alignSelf: 'flex-start', padding: 0 }}><I.Plus size={14}/> Aggiungi fascia</button>
            </div>
          </SettingsRow>

          <SettingsRow label="Durata slot" hint="Durata predefinita di ogni slot. Operatori possono comunque allungare o accorciare.">
            <div style={{ display: 'flex', gap: 6 }}>
              {['15 min', '30 min', '45 min', '60 min', '90 min'].map((s) => (
                <span key={s} style={{
                  height: 36, padding: '0 14px', borderRadius: 6,
                  background: s === '30 min' ? 'var(--ig-blue-50)' : 'white',
                  border: `1px solid ${s === '30 min' ? 'var(--ig-blue-700)' : 'var(--ig-border)'}`,
                  color: s === '30 min' ? 'var(--ig-blue-700)' : 'var(--ig-ink-700)',
                  fontSize: 13, fontWeight: 600, display: 'inline-flex', alignItems: 'center', cursor: 'pointer',
                }}>{s}</span>
              ))}
            </div>
          </SettingsRow>

          <SettingsRow label="Canali disponibili" hint="Determina i canali tra cui l'utente può scegliere in fase di prenotazione.">
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                [<I.User size={16}/>, 'In presenza', 'Sportello principale · Piazza Garibaldi 1', true],
                [<I.Video size={16}/>, 'Videochiamata', 'Google Meet · link generato automaticamente', true],
                [<I.Phone size={16}/>, 'Telefono', 'Risponde l\u2019operatore al numero indicato', true],
                [<I.Mail size={16}/>, 'Email', 'Risposta entro 48h lavorative', false],
              ].map(([ico, n, d, on]) => (
                <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 12, border: '1px solid var(--ig-border-soft)', borderRadius: 8 }}>
                  <div style={{ width: 36, height: 36, borderRadius: 8, background: 'var(--ig-blue-50)', color: 'var(--ig-blue-700)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{ico}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, fontWeight: 700 }}>{n}</div>
                    <div style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}>{d}</div>
                  </div>
                  <Toggle on={on}/>
                </div>
              ))}
            </div>
          </SettingsRow>

          <SettingsRow label="Operatori abilitati" hint="Solo gli operatori abilitati appaiono nei filtri di prenotazione.">
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {[
                ['MG', 'Martina Greco', 'Estero', true],
                ['FB', 'Francesco Bellomo', 'Impresa', true],
                ['PR', 'Paolo Rizzo', 'Lavoro', true],
                ['LM', 'Lorenzo Marino', 'Concorsi', true],
                ['GF', 'Giulia Fontana', 'Responsabile', false],
                ['AC', 'Alessandra Conti', 'Diritti', true],
              ].map(([i, n, r, on]) => (
                <div key={n} style={{
                  display: 'flex', alignItems: 'center', gap: 8, padding: '6px 10px 6px 6px',
                  border: `1px solid ${on ? 'var(--ig-blue-300)' : 'var(--ig-border)'}`,
                  background: on ? 'var(--ig-blue-50)' : 'white',
                  borderRadius: 999,
                }}>
                  <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'var(--ig-teal-600)', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 11 }}>{i}</div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-ink-900)' }}>{n}</div>
                    <div style={{ fontSize: 10, color: 'var(--ig-ink-500)' }}>{r}</div>
                  </div>
                  {on && <I.Check size={14} color="var(--ig-blue-700)" strokeWidth={3}/>}
                </div>
              ))}
            </div>
          </SettingsRow>

          <SettingsRow label="Promemoria automatici" hint="Notifiche automatiche inviate prima dell'appuntamento.">
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <Toggle on={true}/>
                <span style={{ fontSize: 13 }}>Email · 48 ore prima</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <Toggle on={true}/>
                <span style={{ fontSize: 13 }}>Email · 2 ore prima</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <Toggle on={false}/>
                <span style={{ fontSize: 13 }}>SMS · 24 ore prima <span style={{ color: 'var(--ig-ink-400)' }}>(richiede gateway SMS)</span></span>
              </div>
            </div>
          </SettingsRow>

          <SettingsRow label="Buffer tra appuntamenti" hint="Tempo libero garantito tra uno slot e l'altro, per gli operatori.">
            <div className="ig-input" style={{ width: 180, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 14px', fontSize: 14 }}>
              5 minuti <I.ChevD size={14} color="var(--ig-ink-500)"/>
            </div>
          </SettingsRow>

          <SettingsRow label="Limite prenotazioni per utente" hint="Quanti appuntamenti aperti contemporaneamente per utente.">
            <div className="ig-input" style={{ width: 180, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 14px', fontSize: 14 }}>
              2 prenotazioni attive <I.ChevD size={14} color="var(--ig-ink-500)"/>
            </div>
          </SettingsRow>

          <SettingsRow label="Cancellazione" hint="Tempi minimi per annullare senza incorrere in no-show.">
            <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
              <span style={{ fontSize: 13 }}>Cancellabile fino a</span>
              <div className="ig-input" style={{ width: 140, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 14px', fontSize: 14 }}>
                24 ore <I.ChevD size={14} color="var(--ig-ink-500)"/>
              </div>
              <span style={{ fontSize: 13 }}>prima · oltre, viene conteggiato come no-show</span>
            </div>
          </SettingsRow>
        </div>
      </div>
    </BackendShell>
  );
}

window.BackendImpostazioniScreen = BackendImpostazioniScreen;
