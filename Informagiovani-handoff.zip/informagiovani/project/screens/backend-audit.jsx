/* global React, IGIcons, BackendShell, PageHeader */
const I = IGIcons;

const auditRows = [
  ['2026-03-14 14:32:18', 'G. Fontana', 'Responsabile', 'pubblica', 'Scheda', 'ERA-2026-117 · Erasmus+ Traineeship', 'create', '93.42.18.221', 'Chrome 124 · macOS'],
  ['2026-03-14 14:28:04', 'M. Greco',   'Operatore',    'valida',   'Scheda', 'SCN-2026-022 · Servizio Civile 2026', 'edit',   '93.42.18.221', 'Firefox 125 · Windows'],
  ['2026-03-14 14:21:55', 'sistema',    'Sistema',      'controllo fonte', 'Fonte', 'INDIRE Erasmus+ · esito OK', 'system', '—', 'cron job · scheduler'],
  ['2026-03-14 14:18:42', 'F. Bellomo', 'Operatore',    'crea',     'Colloquio', 'COL-1209 · S. Catanzaro · BMC', 'create', '93.42.18.221', 'Chrome 124 · Windows'],
  ['2026-03-14 14:02:11', 'P. Rizzo',   'Operatore',    'risponde', 'Ticket', '#R-2837 · Bonus cultura · evaso',  'edit',   '93.42.18.221', 'Safari 17 · iPad'],
  ['2026-03-14 13:48:09', 'L. Marino',  'Operatore',    'modifica', 'Scheda', 'CON-2026-046 · Concorso Istruttore', 'edit', '93.42.18.221', 'Chrome 124 · Windows'],
  ['2026-03-14 13:30:00', 'sistema',    'Sistema',      'invio email', 'Newsletter', 'Promemoria scadenze · 247 destinatari', 'send', '—', 'cron job · scheduler'],
  ['2026-03-14 13:22:34', 'G. Fontana', 'Responsabile', 'esporta',  'Report', 'CSV utenti registrati gen-mar 2026', 'export','93.42.18.221', 'Chrome 124 · macOS'],
  ['2026-03-14 13:12:18', 'M. Greco',   'Operatore',    'login',    'Sessione', 'Sessione avviata · 2FA verificato', 'auth', '93.42.18.221', 'Firefox 125 · Windows'],
  ['2026-03-14 12:58:42', 'F. Bellomo', 'Operatore',    'crea',     'Appuntamento', 'APP-2418 · S. Catanzaro · 18 mar 10:00', 'create', '93.42.18.221', 'Chrome 124 · Windows'],
  ['2026-03-14 12:48:17', 'M. Greco',   'Operatore',    'aggiorna fonte', 'Fonte', 'EURES · esito OK · 22 nuove offerte', 'edit', '93.42.18.221', 'Firefox 125 · Windows'],
  ['2026-03-14 12:34:09', 'G. Fontana', 'Responsabile', 'modifica impostazioni', 'Impostazioni', 'Appuntamenti · buffer 5min', 'config', '93.42.18.221', 'Chrome 124 · macOS'],
  ['2026-03-14 12:15:50', 'S. Catanzaro', 'Utente',     'invia ticket', 'Ticket', '#R-2841 · Resto al Sud · documentazione', 'create', '78.16.92.44', 'Safari · iPhone iOS 18'],
  ['2026-03-14 12:02:18', 'sistema',    'Sistema',      'failed login', 'Sessione', '5 tentativi falliti per &quot;admin&quot; · IP bloccato', 'security', '185.99.12.34', '—'],
  ['2026-03-14 11:48:00', 'P. Rizzo',   'Operatore',    'invia email', 'Comunicazione', 'A 12 utenti · workshop CV', 'send', '93.42.18.221', 'Safari 17 · iPad'],
  ['2026-03-14 11:22:14', 'sistema',    'Sistema',      'export GDPR', 'Privacy', 'Export dati utente USR-001102 (richiesta utente)', 'system', '—', 'pipeline GDPR'],
];

const actionColors = {
  create:   { bg: 'var(--ig-green-100)',  fg: 'var(--ig-green-700)', label: 'CREATE' },
  edit:     { bg: 'var(--ig-blue-100)',   fg: 'var(--ig-blue-800)',  label: 'EDIT' },
  send:     { bg: 'var(--ig-teal-100)',   fg: 'var(--ig-teal-800)',  label: 'SEND' },
  export:   { bg: 'var(--ig-violet-100)', fg: 'var(--ig-violet-700)',label: 'EXPORT' },
  auth:     { bg: 'var(--ig-ink-100)',    fg: 'var(--ig-ink-700)',   label: 'AUTH' },
  system:   { bg: 'var(--ig-amber-100)',  fg: 'var(--ig-amber-800)', label: 'SYSTEM' },
  config:   { bg: '#f6e3d6',              fg: '#6e3d1a',             label: 'CONFIG' },
  security: { bg: 'var(--ig-red-100)',    fg: 'var(--ig-red-700)',   label: 'SECURITY' },
};

function BackendAuditScreen() {
  return (
    <BackendShell active="Audit log" breadcrumb={['Console', 'Panoramica', 'Audit log']} height={1500}>
      <PageHeader
        title="Audit log"
        subtitle="Registro immutabile delle azioni svolte sulla piattaforma · conformità GDPR e tracciabilità per il responsabile del servizio"
        actions={<>
          <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Download size={14}/> Esporta CSV</button>
          <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Doc size={14}/> Report PDF</button>
          <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Shield size={14}/> Verifica integrità</button>
        </>}
      />

      {/* Stats strip + alerts */}
      <div style={{ padding: '24px 32px 0' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 20 }}>
          {[
            ['Eventi oggi', '142', 'fino alle 14:32', 'var(--ig-blue-700)'],
            ['Utenti attivi', '12', 'operatori + sistema', 'var(--ig-teal-700)'],
            ['Eventi sicurezza', '1', 'tentativi falliti', 'var(--ig-red-700)'],
            ['Retention log', '24 mesi', 'da impostazioni privacy', 'var(--ig-ink-700)'],
          ].map(([l, v, h, c]) => (
            <div key={l} className="ig-card" style={{ padding: 16 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--ig-ink-500)' }}>{l}</div>
              <div className="ig-num" style={{ fontSize: 28, fontWeight: 800, color: c, letterSpacing: '-0.02em', lineHeight: 1.1, margin: '4px 0' }}>{v}</div>
              <div style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>{h}</div>
            </div>
          ))}
        </div>

        {/* Security alert */}
        <div style={{
          background: 'var(--ig-red-50)', border: '1px solid var(--ig-red-100)', borderRadius: 12,
          padding: '14px 20px', display: 'flex', alignItems: 'center', gap: 16, marginBottom: 20,
        }}>
          <div style={{ width: 40, height: 40, borderRadius: 10, background: 'var(--ig-red-600)', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <I.Alert size={20}/>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ig-red-700)' }}>Allerta sicurezza · 1 evento da rivedere</div>
            <div style={{ fontSize: 13, color: 'var(--ig-ink-700)', marginTop: 2 }}>5 tentativi di login falliti dall&apos;IP <strong>185.99.12.34</strong> per l&apos;utente &quot;admin&quot; · l&apos;IP è stato bloccato automaticamente alle 12:02.</div>
          </div>
          <button className="ig-btn ig-btn--danger ig-btn--sm">Apri dettaglio</button>
          <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ color: 'var(--ig-ink-500)' }}>Ignora</button>
        </div>
      </div>

      {/* Filters */}
      <div style={{ background: 'white', padding: '16px 32px', borderBottom: '1px solid var(--ig-border-soft)', borderTop: '1px solid var(--ig-border-soft)', display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
        <div style={{ flex: 1, maxWidth: 360, position: 'relative' }}>
          <input className="ig-input" placeholder="Cerca per utente, entità, ID record…" style={{ height: 36, paddingLeft: 36, fontSize: 13 }}/>
          <div style={{ position: 'absolute', left: 11, top: '50%', transform: 'translateY(-50%)' }}>
            <I.Search size={15} color="var(--ig-ink-400)"/>
          </div>
        </div>
        <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 36 }}>Periodo: <strong>Oggi</strong> <I.ChevD size={12}/></button>
        <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 36 }}>Utente: Tutti <I.ChevD size={12}/></button>
        <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 36 }}>Azione: Tutte <I.ChevD size={12}/></button>
        <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 36 }}>Entità: Tutte <I.ChevD size={12}/></button>
        <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 36, background: 'var(--ig-red-50)', borderColor: 'var(--ig-red-100)', color: 'var(--ig-red-700)' }}>⚑ Solo eventi sicurezza</button>
        <span style={{ marginLeft: 'auto', fontSize: 12, color: 'var(--ig-ink-500)' }}>1–16 di 142 eventi · ordinato per data ↓</span>
      </div>

      {/* TABLE */}
      <div style={{ padding: '20px 32px 32px' }}>
        <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{
            display: 'grid', gridTemplateColumns: '170px 140px 90px 110px 1fr 110px 110px 40px',
            gap: 12, padding: '10px 18px',
            background: 'var(--ig-ink-50)', borderBottom: '1px solid var(--ig-border-soft)',
            fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.05em',
          }}>
            <span>Data · ora</span>
            <span>Utente</span>
            <span>Ruolo</span>
            <span>Azione</span>
            <span>Dettaglio</span>
            <span>IP</span>
            <span>Dispositivo</span>
            <span></span>
          </div>
          {auditRows.map((r, i) => {
            const ac = actionColors[r[6]];
            return (
              <div key={i} style={{
                display: 'grid', gridTemplateColumns: '170px 140px 90px 110px 1fr 110px 110px 40px',
                gap: 12, padding: '12px 18px',
                borderBottom: i < auditRows.length - 1 ? '1px solid var(--ig-border-soft)' : 'none',
                alignItems: 'center', minHeight: 48,
                background: r[6] === 'security' ? 'var(--ig-red-50)' : 'white',
              }}>
                <span style={{ fontFamily: 'var(--ig-font-mono)', fontSize: 11, color: 'var(--ig-ink-700)' }}>{r[0]}</span>
                <span style={{ fontSize: 13, fontWeight: 600, color: r[1] === 'sistema' ? 'var(--ig-ink-500)' : 'var(--ig-ink-900)' }}>
                  {r[1] === 'sistema' ? '⚙ sistema' : r[1]}
                </span>
                <span style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>{r[2]}</span>
                <span style={{
                  height: 22, padding: '0 8px', borderRadius: 4,
                  background: ac.bg, color: ac.fg,
                  fontSize: 10, fontWeight: 800, letterSpacing: '0.05em',
                  display: 'inline-flex', alignItems: 'center', alignSelf: 'center', justifySelf: 'flex-start',
                }}>{ac.label}</span>
                <div>
                  <div style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}><strong style={{ color: 'var(--ig-ink-900)', fontWeight: 700 }}>{r[3]}</strong> · {r[4]}</div>
                  <div style={{ fontSize: 12, color: 'var(--ig-ink-700)' }}>{r[5]}</div>
                </div>
                <span style={{ fontFamily: 'var(--ig-font-mono)', fontSize: 11, color: 'var(--ig-ink-500)' }}>{r[7]}</span>
                <span style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>{r[8]}</span>
                <button className="ig-btn ig-btn--ghost ig-btn--icon" style={{ width: 28, height: 28 }}><I.ChevR size={14}/></button>
              </div>
            );
          })}
          <div style={{ padding: '14px 18px', background: 'var(--ig-ink-50)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 12, color: 'var(--ig-ink-500)' }}>
            <span>Log totali tracciabili: <strong style={{ color: 'var(--ig-ink-900)' }}>1.247.892</strong> · retention 24 mesi · firma SHA-256 <span className="ig-mono">a4f2..e8c1</span></span>
            <div style={{ display: 'flex', gap: 4 }}>
              <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 30 }}>← Precedenti</button>
              <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 30 }}>Successivi →</button>
            </div>
          </div>
        </div>
      </div>
    </BackendShell>
  );
}

window.BackendAuditScreen = BackendAuditScreen;
