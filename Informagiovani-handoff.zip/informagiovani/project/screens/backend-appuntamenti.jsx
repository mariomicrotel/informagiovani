/* global React, IGIcons, BackendShell, PageHeader */
const I = IGIcons;

// Weekly calendar view of appointments.
// Time slots from 09:00 to 18:00 in 30-min increments.
// Each appointment occupies a colored block.

const operatorColors = {
  'M. Greco':    { bg: 'var(--ig-blue-100)',   border: 'var(--ig-blue-700)',   fg: 'var(--ig-blue-800)' },
  'F. Bellomo':  { bg: 'var(--ig-teal-100)',   border: 'var(--ig-teal-700)',   fg: 'var(--ig-teal-800)' },
  'P. Rizzo':    { bg: 'var(--ig-violet-100)', border: 'var(--ig-violet-700)', fg: 'var(--ig-violet-700)' },
  'L. Marino':   { bg: 'var(--ig-amber-100)',  border: 'var(--ig-amber-700)',  fg: 'var(--ig-amber-800)' },
};

// Day: 0=mon..6=sun, start/end in slot indexes (each = 30 min, 0 = 09:00)
const apps = [
  // Lunedì 9 mar
  { day: 0, start: 1,  end: 3,  user: 'Letizia Bonfiglio', topic: 'Orientamento concorsi pubblici', op: 'L. Marino', ch: 'video',  status: 'done' },
  { day: 0, start: 4,  end: 6,  user: 'Andrea Costa',      topic: 'CV e portfolio',                 op: 'P. Rizzo',  ch: 'present', status: 'done' },
  { day: 0, start: 9,  end: 11, user: 'Marta Russo',       topic: 'Erasmus+ candidatura',           op: 'M. Greco',  ch: 'video',   status: 'done' },
  { day: 0, start: 12, end: 14, user: 'G. Castagna',       topic: 'Microcredito · idea',            op: 'F. Bellomo',ch: 'present', status: 'done' },
  // Martedì
  { day: 1, start: 0,  end: 2,  user: 'Davide Pignato',    topic: 'Servizio civile',                op: 'L. Marino', ch: 'phone',   status: 'done' },
  { day: 1, start: 3,  end: 5,  user: 'Anna Mineo',        topic: 'CV · lettera presentazione',     op: 'P. Rizzo',  ch: 'present', status: 'done' },
  { day: 1, start: 7,  end: 9,  user: 'Salvatore Catanzaro', topic: 'BMC · idea food truck',        op: 'F. Bellomo',ch: 'present', status: 'done' },
  { day: 1, start: 10, end: 12, user: 'Chiara La Rosa',    topic: 'Microcredito · primo',           op: 'F. Bellomo',ch: 'present', status: 'done' },
  // Mercoledì
  { day: 2, start: 2,  end: 4,  user: 'Marco Lo Curto',    topic: 'Erasmus+ Olanda',                op: 'M. Greco',  ch: 'video',   status: 'done' },
  { day: 2, start: 5,  end: 7,  user: 'Sara Cilluffo',     topic: 'Portfolio creativo',             op: 'P. Rizzo',  ch: 'present', status: 'done' },
  { day: 2, start: 11, end: 13, user: 'Federico Russo',    topic: 'Resto al Sud',                   op: 'F. Bellomo',ch: 'phone',   status: 'done' },
  // Giovedì
  { day: 3, start: 0,  end: 2,  user: 'Maria Lombardo',    topic: 'Concorso istruttore',            op: 'L. Marino', ch: 'present', status: 'done' },
  { day: 3, start: 3,  end: 5,  user: 'Antonio Greco',     topic: 'Tirocinio Garanzia Giovani',     op: 'P. Rizzo',  ch: 'present', status: 'done' },
  { day: 3, start: 7,  end: 8,  user: 'Sofia Pace',        topic: 'Quick · borsa studio',           op: 'M. Greco',  ch: 'phone',   status: 'done' },
  { day: 3, start: 11, end: 13, user: 'Luca Termini',      topic: 'Pratica microcredito',           op: 'F. Bellomo',ch: 'video',   status: 'done' },
  // Venerdì
  { day: 4, start: 1,  end: 3,  user: 'Giulia Bonfiglio',  topic: 'CV revisione',                   op: 'P. Rizzo',  ch: 'present', status: 'done' },
  // Sabato (oggi) — alcuni futuri
  { day: 5, start: 1,  end: 3,  user: 'Salvatore Catanzaro', topic: 'Resto al Sud · documentazione', op: 'M. Greco',  ch: 'present', status: 'today' },
  { day: 5, start: 3,  end: 5,  user: 'Letizia Bonfiglio', topic: 'Orientamento concorsi',          op: 'L. Marino', ch: 'video',   status: 'today' },
  { day: 5, start: 5,  end: 7,  user: 'Marco Lo Curto',    topic: 'Erasmus+ UE',                    op: 'M. Greco',  ch: 'present', status: 'pending' },
  { day: 5, start: 6,  end: 8,  user: 'Anna Mineo',        topic: 'Revisione CV',                   op: 'P. Rizzo',  ch: 'phone',   status: 'today' },
  { day: 5, start: 12, end: 14, user: 'Giuseppe Russo',    topic: 'Idea food truck · video',        op: 'F. Bellomo',ch: 'video',   status: 'today' },
  { day: 5, start: 13, end: 15, user: 'Chiara La Rosa',    topic: 'Microcredito · primo',           op: 'F. Bellomo',ch: 'present', status: 'pending' },
  { day: 5, start: 15, end: 17, user: 'Davide Pignato',    topic: 'Servizio civile · scelta',       op: 'L. Marino', ch: 'video',   status: 'today' },
  { day: 5, start: 16, end: 18, user: 'Sara Cilluffo',     topic: 'CV e portfolio',                 op: 'P. Rizzo',  ch: 'present', status: 'today' },
];

const TIMES = ['09:00','09:30','10:00','10:30','11:00','11:30','12:00','12:30','13:00','13:30','14:00','14:30','15:00','15:30','16:00','16:30','17:00','17:30'];
const DAYS = [
  { lbl: 'Lun', date: 9 },
  { lbl: 'Mar', date: 10 },
  { lbl: 'Mer', date: 11 },
  { lbl: 'Gio', date: 12 },
  { lbl: 'Ven', date: 13 },
  { lbl: 'Sab', date: 14, today: true },
  { lbl: 'Dom', date: 15, closed: true },
];

function ChIcon({ ch, size = 12 }) {
  if (ch === 'video')   return <I.Video size={size}/>;
  if (ch === 'phone')   return <I.Phone size={size}/>;
  if (ch === 'present') return <I.User size={size}/>;
  return null;
}

function AppBlock({ app }) {
  const colors = operatorColors[app.op];
  const height = (app.end - app.start) * 32;
  const top = app.start * 32;
  return (
    <div style={{
      position: 'absolute',
      left: 4, right: 4,
      top: top + 2, height: height - 4,
      background: app.status === 'pending' ? `repeating-linear-gradient(135deg, ${colors.bg} 0 8px, color-mix(in srgb, ${colors.bg} 50%, white) 8px 16px)` : colors.bg,
      borderLeft: `3px solid ${colors.border}`,
      borderRadius: 6, padding: '6px 8px',
      overflow: 'hidden',
      cursor: 'pointer',
    }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: colors.fg, marginBottom: 2, display: 'flex', alignItems: 'center', gap: 4 }}>
        <ChIcon ch={app.ch} size={11}/>
        {TIMES[app.start]} – {TIMES[app.end]}
        {app.status === 'pending' && <span style={{ marginLeft: 'auto', fontSize: 9, background: 'var(--ig-amber-600)', color: 'white', padding: '0 4px', borderRadius: 3 }}>?</span>}
      </div>
      <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-ink-900)', lineHeight: 1.25, marginBottom: 2 }}>{app.user}</div>
      {height > 50 && <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', lineHeight: 1.3 }}>{app.topic}</div>}
      {height > 70 && <div style={{ fontSize: 10, color: colors.fg, fontWeight: 600, marginTop: 4 }}>{app.op}</div>}
    </div>
  );
}

function BackendAppuntamentiScreen() {
  return (
    <BackendShell active="Appuntamenti" breadcrumb={['Console', 'Sportello', 'Appuntamenti']} height={1500}>
      <PageHeader
        title="Calendario appuntamenti"
        subtitle="Settimana 9 – 15 marzo 2026 · 23 appuntamenti programmati · 6 da confermare"
        actions={<>
          <div style={{ display: 'flex', border: '1px solid var(--ig-border)', borderRadius: 6, overflow: 'hidden' }}>
            <button style={{ background: 'white', border: 'none', padding: '8px 14px', cursor: 'pointer', fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-700)' }}>Giorno</button>
            <button style={{ background: 'var(--ig-ink-900)', color: 'white', border: 'none', padding: '8px 14px', cursor: 'pointer', fontSize: 13, fontWeight: 700 }}>Settimana</button>
            <button style={{ background: 'white', border: 'none', padding: '8px 14px', cursor: 'pointer', fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-700)' }}>Mese</button>
          </div>
          <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Download size={14}/> Esporta</button>
          <button className="ig-btn ig-btn--primary ig-btn--sm"><I.Plus size={14}/> Nuovo appuntamento</button>
        </>}
      />

      {/* Filters strip */}
      <div style={{ background: 'white', padding: '16px 32px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', alignItems: 'center', gap: 14 }}>
        {/* Week navigator */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <button className="ig-btn ig-btn--secondary ig-btn--sm ig-btn--icon" style={{ width: 32, height: 32 }}><I.ArrowL size={14}/></button>
          <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 32 }}>Oggi</button>
          <button className="ig-btn ig-btn--secondary ig-btn--sm ig-btn--icon" style={{ width: 32, height: 32 }}><I.ArrowR size={14}/></button>
          <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--ig-ink-900)', padding: '0 14px', letterSpacing: '-0.01em' }}>
            9 – 15 marzo 2026
          </div>
        </div>

        <div style={{ width: 1, height: 24, background: 'var(--ig-border-soft)' }}/>

        <div style={{ fontSize: 13, color: 'var(--ig-ink-500)', fontWeight: 600 }}>Operatori:</div>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {Object.entries(operatorColors).map(([name, c]) => (
            <span key={name} style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              height: 30, padding: '0 12px', borderRadius: 6,
              background: c.bg, color: c.fg, border: `1px solid ${c.border}`,
              fontSize: 12, fontWeight: 600,
            }}>
              <I.Check size={12}/> {name}
            </span>
          ))}
          <span style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            height: 30, padding: '0 12px', borderRadius: 6,
            background: 'white', color: 'var(--ig-ink-700)', border: '1px solid var(--ig-border)',
            fontSize: 12, fontWeight: 600,
          }}>
            <I.Plus size={12}/> Tutti gli 8 operatori
          </span>
        </div>

        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 14, fontSize: 12, color: 'var(--ig-ink-500)' }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
            <I.User size={12}/> In presenza
          </span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
            <I.Video size={12}/> Videochiamata
          </span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
            <I.Phone size={12}/> Telefono
          </span>
        </div>
      </div>

      {/* CALENDAR */}
      <div style={{ padding: '24px 32px 24px' }}>
        <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
          {/* Day headers */}
          <div style={{ display: 'grid', gridTemplateColumns: '70px repeat(7, 1fr)', borderBottom: '1px solid var(--ig-border-soft)', background: 'var(--ig-ink-50)' }}>
            <div style={{ padding: '14px 8px', borderRight: '1px solid var(--ig-border-soft)' }}/>
            {DAYS.map((d, i) => (
              <div key={i} style={{
                padding: '14px 16px',
                borderRight: i < 6 ? '1px solid var(--ig-border-soft)' : 'none',
                background: d.today ? 'var(--ig-blue-50)' : (d.closed ? 'var(--ig-ink-100)' : 'transparent'),
                opacity: d.closed ? 0.6 : 1,
              }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: d.today ? 'var(--ig-blue-700)' : 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>{d.lbl}</div>
                <div className="ig-num" style={{ fontSize: 22, fontWeight: 800, color: d.today ? 'var(--ig-blue-700)' : 'var(--ig-ink-900)', marginTop: 2, letterSpacing: '-0.02em' }}>{d.date}</div>
                {d.today && <div style={{ fontSize: 10, fontWeight: 700, color: 'var(--ig-blue-700)', marginTop: 2 }}>· OGGI ·</div>}
                {d.closed && <div style={{ fontSize: 10, color: 'var(--ig-ink-400)', marginTop: 2 }}>chiuso</div>}
              </div>
            ))}
          </div>

          {/* Grid body */}
          <div style={{ display: 'grid', gridTemplateColumns: '70px repeat(7, 1fr)', position: 'relative' }}>
            {/* Time column */}
            <div style={{ borderRight: '1px solid var(--ig-border-soft)' }}>
              {TIMES.map((t, i) => (
                <div key={t} style={{
                  height: 32, padding: '4px 8px', textAlign: 'right',
                  fontSize: 11, fontFamily: 'var(--ig-font-mono)', color: 'var(--ig-ink-500)',
                  borderBottom: i < TIMES.length - 1 ? '1px solid var(--ig-border-soft)' : 'none',
                }}>{t}</div>
              ))}
            </div>

            {/* Day columns */}
            {DAYS.map((d, di) => (
              <div key={di} style={{
                position: 'relative',
                borderRight: di < 6 ? '1px solid var(--ig-border-soft)' : 'none',
                background: d.closed ? 'repeating-linear-gradient(135deg, var(--ig-ink-50) 0 8px, var(--ig-ink-100) 8px 16px)' : (d.today ? 'rgba(31,90,168,0.02)' : 'white'),
              }}>
                {TIMES.map((_, i) => (
                  <div key={i} style={{
                    height: 32,
                    borderBottom: i < TIMES.length - 1 ? '1px solid var(--ig-border-soft)' : 'none',
                    background: i % 2 === 1 && !d.closed ? 'rgba(0,0,0,0.01)' : 'transparent',
                  }}/>
                ))}
                {/* Lunch break overlay */}
                {!d.closed && (
                  <div style={{
                    position: 'absolute', left: 0, right: 0,
                    top: 8 * 32, height: 2 * 32,
                    background: 'rgba(216, 220, 229, 0.45)',
                    backgroundImage: 'repeating-linear-gradient(135deg, transparent 0 6px, rgba(0,0,0,0.04) 6px 7px)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 10, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.08em',
                  }}>
                    Pausa
                  </div>
                )}
                {/* Now line - on today, around 11:30 (slot 5) */}
                {d.today && (
                  <div style={{ position: 'absolute', left: 0, right: 0, top: 5 * 32 + 16, height: 2, background: 'var(--ig-red-600)', zIndex: 4 }}>
                    <span style={{ position: 'absolute', left: -6, top: -4, width: 10, height: 10, borderRadius: '50%', background: 'var(--ig-red-600)' }}/>
                    <span style={{ position: 'absolute', right: 4, top: -16, fontSize: 10, fontWeight: 700, color: 'var(--ig-red-600)', background: 'white', padding: '0 6px', borderRadius: 4 }}>11:30</span>
                  </div>
                )}
                {/* Apps */}
                {apps.filter(a => a.day === di).map((app, ai) => (
                  <AppBlock key={ai} app={app}/>
                ))}
              </div>
            ))}
          </div>
        </div>

        {/* Bottom stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginTop: 20 }}>
          {[
            ['Programmati', '23', 'questa settimana', 'var(--ig-blue-700)'],
            ['Completati', '15', 'fino a ieri', 'var(--ig-green-700)'],
            ['Da confermare', '6', '3 contatti necessari', 'var(--ig-amber-800)'],
            ['No-show / annullati', '2', 'tasso 8% (media 11%)', 'var(--ig-red-700)'],
          ].map(([l, v, h, c]) => (
            <div key={l} className="ig-card" style={{ padding: 16, display: 'flex', alignItems: 'center', gap: 14 }}>
              <div className="ig-num" style={{ fontSize: 32, fontWeight: 800, color: c, letterSpacing: '-0.02em', lineHeight: 1 }}>{v}</div>
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ig-ink-900)' }}>{l}</div>
                <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginTop: 2 }}>{h}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </BackendShell>
  );
}

window.BackendAppuntamentiScreen = BackendAppuntamentiScreen;
