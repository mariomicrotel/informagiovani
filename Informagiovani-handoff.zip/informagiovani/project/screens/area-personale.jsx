/* global React, IGIcons, PublicHeader, PublicFooter */
const I = IGIcons;

function APNavItem({ icon, label, active, badge }) {
  return (
    <a href="#" style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '11px 14px', borderRadius: 8,
      fontSize: 14, fontWeight: 600,
      color: active ? 'var(--ig-blue-700)' : 'var(--ig-ink-700)',
      background: active ? 'var(--ig-blue-50)' : 'transparent',
      textDecoration: 'none', borderLeft: active ? '3px solid var(--ig-blue-700)' : '3px solid transparent', marginLeft: -3,
    }}>
      <span style={{ color: active ? 'var(--ig-blue-700)' : 'var(--ig-ink-400)' }}>{icon}</span>
      <span style={{ flex: 1 }}>{label}</span>
      {badge && <span style={{ fontSize: 11, fontWeight: 700, background: 'var(--ig-ink-100)', color: 'var(--ig-ink-700)', padding: '2px 8px', borderRadius: 999 }}>{badge}</span>}
    </a>
  );
}

function MiniCard({ label, value, sub, color }) {
  return (
    <div className="ig-card" style={{ padding: 16 }}>
      <div className="ig-num" style={{ fontSize: 28, fontWeight: 800, color: color || 'var(--ig-blue-700)', letterSpacing: '-0.02em', lineHeight: 1 }}>{value}</div>
      <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-900)', marginTop: 8 }}>{label}</div>
      {sub && <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', marginTop: 2 }}>{sub}</div>}
    </div>
  );
}

function AreaPersonaleScreen() {
  return (
    <div className="ig" style={{ width: 1440, background: 'var(--ig-bg)', minHeight: 1900 }}>
      <PublicHeader/>

      {/* Welcome strip */}
      <div style={{ background: 'linear-gradient(120deg, var(--ig-blue-700) 0%, var(--ig-blue-800) 100%)', color: 'white' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '40px 32px', display: 'flex', alignItems: 'center', gap: 24 }}>
          <div style={{ width: 78, height: 78, borderRadius: '50%', background: 'var(--ig-amber-500)', color: 'var(--ig-blue-900)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 28, border: '4px solid white' }}>SC</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.14em', color: 'var(--ig-amber-500)', textTransform: 'uppercase', marginBottom: 8 }}>Area personale</div>
            <h1 style={{ fontSize: 34, fontWeight: 800, color: 'white', letterSpacing: '-0.02em', marginBottom: 6 }}>Bentornato, Salvatore 👋</h1>
            <p style={{ fontSize: 15, color: 'rgba(255,255,255,0.78)' }}>Hai 1 appuntamento oggi alle 09:30 e 3 nuove opportunità in linea con il tuo profilo.</p>
          </div>
          <div style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.18)', borderRadius: 12, padding: 18, minWidth: 220 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: 'rgba(255,255,255,0.6)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6 }}>Completamento profilo</div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
              <span className="ig-num" style={{ fontSize: 36, fontWeight: 800, color: 'var(--ig-amber-500)', letterSpacing: '-0.02em', lineHeight: 1 }}>82</span>
              <span style={{ fontSize: 18, fontWeight: 600, color: 'rgba(255,255,255,0.78)' }}>%</span>
            </div>
            <div style={{ height: 5, background: 'rgba(255,255,255,0.15)', borderRadius: 999, marginTop: 10, overflow: 'hidden' }}>
              <div style={{ width: '82%', height: '100%', background: 'var(--ig-amber-500)' }}/>
            </div>
            <a href="#" style={{ fontSize: 12, color: 'white', marginTop: 8, display: 'block' }}>Completa il profilo →</a>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 1280, margin: '-30px auto 0', padding: '0 32px 60px', display: 'grid', gridTemplateColumns: '260px 1fr', gap: 28 }}>
        {/* SIDEBAR */}
        <aside>
          <div className="ig-card" style={{ padding: 12 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <APNavItem icon={<I.Home size={18}/>} label="Panoramica" active/>
              <APNavItem icon={<I.User size={18}/>} label="Il mio profilo"/>
              <APNavItem icon={<I.Bookmark size={18}/>} label="Opportunità salvate" badge="14"/>
              <APNavItem icon={<I.Calendar size={18}/>} label="Appuntamenti" badge="2"/>
              <APNavItem icon={<I.Chat size={18}/>} label="Richieste" badge="2"/>
              <APNavItem icon={<I.Calendar size={18}/>} label="Eventi" badge="3"/>
              <APNavItem icon={<I.Bulb size={18}/>} label="Percorso impresa" badge="●"/>
              <APNavItem icon={<I.Doc size={18}/>} label="Curriculum e documenti"/>
              <APNavItem icon={<I.Bell size={18}/>} label="Preferenze notifiche"/>
              <APNavItem icon={<I.Shield size={18}/>} label="Privacy e consensi"/>
            </div>
          </div>
          <div style={{ marginTop: 16, padding: 18, background: 'var(--ig-teal-50)', borderRadius: 12, border: '1px solid var(--ig-teal-100)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
              <I.Bulb size={18} color="var(--ig-teal-700)"/>
              <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ig-teal-800)' }}>Percorso impresa</div>
            </div>
            <div style={{ fontSize: 12, color: 'var(--ig-ink-700)', lineHeight: 1.5, marginBottom: 10 }}>
              Sei al <strong>step 3 di 7</strong> del tuo percorso &quot;Catering siciliano&quot;.
            </div>
            <div style={{ height: 5, background: 'white', borderRadius: 999, overflow: 'hidden' }}>
              <div style={{ width: '42%', height: '100%', background: 'var(--ig-teal-700)' }}/>
            </div>
            <a href="#" style={{ fontSize: 12, color: 'var(--ig-teal-800)', fontWeight: 700, marginTop: 10, display: 'block' }}>Continua →</a>
          </div>
        </aside>

        {/* MAIN */}
        <div>
          {/* KPI row */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 24 }}>
            <MiniCard label="Opportunità salvate" value="14" sub="3 in scadenza" color="var(--ig-blue-700)"/>
            <MiniCard label="Candidature inviate" value="2" sub="1 in valutazione" color="var(--ig-teal-700)"/>
            <MiniCard label="Appuntamenti" value="6" sub="prossimo: oggi 09:30" color="var(--ig-amber-700)"/>
            <MiniCard label="Richieste aperte" value="2" sub="ultima risposta: 12 min" color="var(--ig-violet-700)"/>
          </div>

          {/* Appointment + Recommended */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 24 }}>
            <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
              <div style={{ padding: '18px 22px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h3 style={{ fontSize: 16, fontWeight: 700 }}>Prossimi appuntamenti</h3>
                <a href="#" style={{ fontSize: 13, fontWeight: 600 }}>Tutti →</a>
              </div>
              {[
                ['OGGI', '09:30', 'In presenza · Sportello', 'Resto al Sud · documentazione', 'M. Greco', true],
                ['18 MAR', '10:00', 'In presenza · Sportello', 'BMC · idea food truck', 'F. Bellomo', false],
              ].map(([d, t, ch, top, op, today], i) => (
                <div key={i} style={{ display: 'flex', gap: 16, padding: '18px 22px', borderBottom: i === 0 ? '1px solid var(--ig-border-soft)' : 'none' }}>
                  <div style={{ width: 64, textAlign: 'center', padding: '8px 0', borderRadius: 8, background: today ? 'var(--ig-blue-700)' : 'var(--ig-ink-50)', color: today ? 'white' : 'var(--ig-ink-900)', flex: '0 0 auto' }}>
                    <div style={{ fontSize: 10, fontWeight: 800, letterSpacing: '0.08em' }}>{d}</div>
                    <div className="ig-num" style={{ fontSize: 18, fontWeight: 800, marginTop: 2 }}>{t}</div>
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ig-ink-900)' }}>{top}</div>
                    <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginTop: 4, display: 'flex', gap: 8, alignItems: 'center' }}>
                      <I.MapPin size={12}/> {ch} · con {op}
                    </div>
                    <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
                      <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 28, padding: '0 10px', fontSize: 12 }}>Aggiungi al calendario</button>
                      <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ height: 28, padding: '0 10px', fontSize: 12, color: 'var(--ig-red-700)' }}>Annulla</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
              <div style={{ padding: '18px 22px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', alignItems: 'center', gap: 10 }}>
                <I.Sparkle size={18} color="var(--ig-amber-700)"/>
                <h3 style={{ fontSize: 16, fontWeight: 700 }}>Consigliate per te</h3>
                <span style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginLeft: 'auto' }}>basate sui tuoi interessi</span>
              </div>
              {[
                ['Resto al Sud · fondo perduto 200k€', 'impresa', 'Impresa', 'Sempre aperta', 'ok'],
                ['Microcredito Sicilia per giovani', 'impresa', 'Impresa', '60 giorni', 'ok'],
                ['ITS Digital Marketing · Catania', 'formazione', 'Formazione', '14 giorni', 'soon'],
              ].map((o, i) => (
                <div key={i} style={{ padding: '14px 22px', borderBottom: i < 2 ? '1px solid var(--ig-border-soft)' : 'none', display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ig-ink-900)' }}>{o[0]}</div>
                    <div style={{ display: 'flex', gap: 6, marginTop: 6, alignItems: 'center' }}>
                      <span className={`ig-badge ig-badge--${o[1]}`} style={{ height: 20, fontSize: 11 }}>{o[2]}</span>
                      <span className={`ig-badge ig-badge--scad-${o[4]}`} style={{ height: 20, fontSize: 11 }}><I.Clock size={10}/>{o[3]}</span>
                    </div>
                  </div>
                  <button className="ig-btn ig-btn--ghost ig-btn--icon" style={{ width: 32, height: 32 }}><I.Bookmark size={16}/></button>
                </div>
              ))}
            </div>
          </div>

          {/* Saved opportunities */}
          <div className="ig-card" style={{ padding: 0, overflow: 'hidden', marginBottom: 24 }}>
            <div style={{ padding: '18px 22px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <h3 style={{ fontSize: 16, fontWeight: 700 }}>Opportunità salvate</h3>
                <span style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}>14 totali · 3 in scadenza</span>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                {['Tutte · 14', 'Da valutare · 8', 'Candidatura inviata · 2', 'Colloquio · 1', 'Non interessato · 3'].map((f, i) => (
                  <button key={f} style={{
                    height: 28, padding: '0 10px', borderRadius: 6,
                    background: i === 0 ? 'var(--ig-ink-900)' : 'transparent',
                    color: i === 0 ? 'white' : 'var(--ig-ink-700)',
                    fontSize: 11, fontWeight: 600, border: '1px solid', borderColor: i === 0 ? 'var(--ig-ink-900)' : 'var(--ig-border)', cursor: 'pointer',
                  }}>{f}</button>
                ))}
              </div>
            </div>
            <div>
              {[
                ['Erasmus+ Traineeship 2026/27 · tirocini in Europa', 'estero', 'Estero', '3 giorni', 'urgent', 'Da valutare', 'state-draft', 'Ricorda di completare il Learning Agreement entro la settimana.'],
                ['Resto al Sud · contributo a fondo perduto 200k€', 'impresa', 'Impresa', 'Sempre aperta', 'ok', 'Candidatura inviata', 'state-pub', 'Pratica in valutazione · esito previsto in 60 giorni.'],
                ['Concorso · 4 Istruttori Amm.vi Comune di Enna', 'concorso', 'Concorsi', '21 giorni', 'soon', 'Da valutare', 'state-draft', 'Hai segnato: serve aggiornare CV e simulare quiz.'],
                ['Servizio Civile Universale 2026', 'civile', 'Servizio Civile', '7 giorni', 'urgent', 'Colloquio fissato', 'state-valid', 'Colloquio con il referente progetto il 21 marzo.'],
              ].map((s, i) => (
                <div key={i} style={{ display: 'grid', gridTemplateColumns: '1fr 110px 130px 140px 80px', gap: 14, padding: '16px 22px', borderBottom: i < 3 ? '1px solid var(--ig-border-soft)' : 'none', alignItems: 'center' }}>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ig-ink-900)' }}>{s[0]}</div>
                    {s[7] && <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginTop: 4, fontStyle: 'italic' }}>📝 {s[7]}</div>}
                  </div>
                  <span className={`ig-badge ig-badge--${s[1]}`} style={{ height: 22, fontSize: 11 }}>{s[2]}</span>
                  <span className={`ig-badge ig-badge--scad-${s[4]}`} style={{ height: 22, fontSize: 11 }}><I.Clock size={11}/>{s[3]}</span>
                  <span className={`ig-badge ig-badge--${s[6]}`} style={{ height: 22, fontSize: 11 }}>{s[5]}</span>
                  <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                    <button className="ig-btn ig-btn--ghost ig-btn--icon" style={{ width: 28, height: 28 }}><I.Eye size={14}/></button>
                    <button className="ig-btn ig-btn--ghost ig-btn--icon" style={{ width: 28, height: 28, color: 'var(--ig-red-700)' }}><I.X size={14}/></button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Bottom row: requests + events */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
              <div style={{ padding: '18px 22px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h3 style={{ fontSize: 16, fontWeight: 700}}>Le mie richieste</h3>
                <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Plus size={14}/>Nuova</button>
              </div>
              {[
                ['#R-2841', 'Resto al Sud · documentazione', 'Nuovo', 'state-valid', '12 min'],
                ['#R-2812', 'Microcredito · prima info', 'Evaso', 'state-pub', '3 giorni'],
              ].map((r, i) => (
                <div key={r[0]} style={{ padding: '14px 22px', borderBottom: i === 0 ? '1px solid var(--ig-border-soft)' : 'none' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
                    <span style={{ fontFamily: 'var(--ig-font-mono)', fontSize: 11, color: 'var(--ig-ink-500)' }}>{r[0]}</span>
                    <span className={`ig-badge ig-badge--${r[3]}`} style={{ height: 20, fontSize: 10 }}>{r[2]}</span>
                    <span style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--ig-ink-400)' }}>{r[4]}</span>
                  </div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ig-ink-900)' }}>{r[1]}</div>
                </div>
              ))}
            </div>

            <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
              <div style={{ padding: '18px 22px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h3 style={{ fontSize: 16, fontWeight: 700 }}>Eventi a cui sono iscritto</h3>
                <a href="#" style={{ fontSize: 13, fontWeight: 600 }}>Esplora →</a>
              </div>
              {[
                [22, 'MAR', 'Workshop: scrivi il tuo CV', 'Sportello · 10:00 - 12:00', 'Confermato', 'var(--ig-green-700)'],
                [26, 'MAR', 'Costruisci la tua idea di impresa', 'Online · Zoom · 17:00', 'Confermato', 'var(--ig-green-700)'],
                [3, 'APR', 'Resto al Sud · come candidarsi', 'CCIAA Enna · 15:30', 'In lista d\u2019attesa', 'var(--ig-amber-700)'],
              ].map((e, i) => (
                <div key={i} style={{ display: 'flex', gap: 14, padding: '14px 22px', borderBottom: i < 2 ? '1px solid var(--ig-border-soft)' : 'none', alignItems: 'center' }}>
                  <div style={{ width: 50, textAlign: 'center', padding: '6px 0', borderRadius: 8, background: 'var(--ig-blue-50)', color: 'var(--ig-blue-700)', flex: '0 0 auto' }}>
                    <div className="ig-num" style={{ fontSize: 18, fontWeight: 800, lineHeight: 1 }}>{e[0]}</div>
                    <div style={{ fontSize: 10, fontWeight: 700, marginTop: 2 }}>{e[1]}</div>
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ig-ink-900)' }}>{e[2]}</div>
                    <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', marginTop: 2 }}>{e[3]}</div>
                  </div>
                  <span style={{ fontSize: 11, fontWeight: 700, color: e[5] }}>● {e[4]}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <PublicFooter/>
    </div>
  );
}

window.AreaPersonaleScreen = AreaPersonaleScreen;
