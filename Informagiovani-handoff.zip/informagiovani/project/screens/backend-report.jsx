/* global React, IGIcons, BackendShell, PageHeader */
const I = IGIcons;

// Line chart inline
function LineChart({ series, labels, color, height = 180 }) {
  const w = 600;
  const h = height;
  const padding = { left: 36, right: 12, top: 16, bottom: 26 };
  const max = Math.max(...series.flat()) * 1.1;
  const min = 0;
  const xStep = (w - padding.left - padding.right) / (labels.length - 1);

  const toPath = (data) => data.map((v, i) => {
    const x = padding.left + i * xStep;
    const y = h - padding.bottom - ((v - min) / (max - min)) * (h - padding.top - padding.bottom);
    return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
  }).join(' ');

  return (
    <svg width="100%" height={h} viewBox={`0 0 ${w} ${h}`} style={{ display: 'block' }}>
      {/* Grid */}
      {[0, 0.25, 0.5, 0.75, 1].map((p, i) => {
        const y = padding.top + (h - padding.top - padding.bottom) * p;
        const val = Math.round((max - (max - min) * p));
        return (
          <g key={i}>
            <line x1={padding.left} y1={y} x2={w - padding.right} y2={y} stroke="var(--ig-border-soft)" strokeDasharray="2 4"/>
            <text x={padding.left - 6} y={y + 3} textAnchor="end" fontSize="10" fill="var(--ig-ink-400)" fontFamily="var(--ig-font-mono)">{val}</text>
          </g>
        );
      })}
      {/* X labels */}
      {labels.map((l, i) => (
        <text key={l} x={padding.left + i * xStep} y={h - 8} textAnchor="middle" fontSize="10" fill="var(--ig-ink-500)">{l}</text>
      ))}
      {/* Series */}
      {series.map((data, si) => (
        <g key={si}>
          <path d={`${toPath(data)} L ${padding.left + (data.length-1) * xStep} ${h - padding.bottom} L ${padding.left} ${h - padding.bottom} Z`} fill={color[si]} fillOpacity="0.10"/>
          <path d={toPath(data)} fill="none" stroke={color[si]} strokeWidth="2"/>
          {data.map((v, i) => {
            const x = padding.left + i * xStep;
            const y = h - padding.bottom - ((v - min) / (max - min)) * (h - padding.top - padding.bottom);
            return <circle key={i} cx={x} cy={y} r="3" fill="white" stroke={color[si]} strokeWidth="1.6"/>;
          })}
        </g>
      ))}
    </svg>
  );
}

function StackedBar({ data, height = 200 }) {
  const max = Math.max(...data.map(d => d.values.reduce((a, b) => a + b, 0)));
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 14, height, padding: '0 4px' }}>
      {data.map((row) => {
        const total = row.values.reduce((a, b) => a + b, 0);
        const h = (total / max) * (height - 28);
        return (
          <div key={row.label} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
            <div className="ig-num" style={{ fontSize: 10, color: 'var(--ig-ink-700)', fontWeight: 700 }}>{total}</div>
            <div style={{ width: '100%', height: h, display: 'flex', flexDirection: 'column', borderRadius: '3px 3px 0 0', overflow: 'hidden' }}>
              {row.values.map((v, i) => (
                <div key={i} style={{ height: `${(v/total)*100}%`, background: row.colors[i] }}/>
              ))}
            </div>
            <div style={{ fontSize: 10, color: 'var(--ig-ink-500)', fontWeight: 600 }}>{row.label}</div>
          </div>
        );
      })}
    </div>
  );
}

function ReportCard({ title, subtitle, children, action, height }) {
  return (
    <div className="ig-card" style={{ padding: 22, height: height || 'auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
        <div>
          <h3 style={{ fontSize: 15, fontWeight: 700, color: 'var(--ig-ink-900)' }}>{title}</h3>
          {subtitle && <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginTop: 2 }}>{subtitle}</div>}
        </div>
        <div style={{ display: 'flex', gap: 4 }}>
          {action}
          <button className="ig-btn ig-btn--ghost ig-btn--icon" style={{ width: 28, height: 28, color: 'var(--ig-ink-500)' }} title="Esporta CSV"><I.Download size={14}/></button>
          <button className="ig-btn ig-btn--ghost ig-btn--icon" style={{ width: 28, height: 28, color: 'var(--ig-ink-500)' }} title="Esporta PDF"><I.Doc size={14}/></button>
        </div>
      </div>
      {children}
    </div>
  );
}

function BackendReportScreen() {
  return (
    <BackendShell active="Report" breadcrumb={['Console', 'Panoramica', 'Report']} height={2000}>
      <PageHeader
        title="Report e analisi"
        subtitle="Periodo: 1 gennaio 2026 – 14 marzo 2026 · 73 giorni · ultimo aggiornamento dati 12 minuti fa"
        actions={<>
          <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Download size={14}/> Esporta tutto (CSV)</button>
          <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Doc size={14}/> Report PDF</button>
          <button className="ig-btn ig-btn--primary ig-btn--sm"><I.Send size={14}/> Invia ai destinatari</button>
        </>}
      />

      {/* Filters */}
      <div style={{ background: 'white', padding: '16px 32px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
        <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginRight: 6 }}>Filtri:</span>
        <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 34, background: 'var(--ig-blue-50)', borderColor: 'var(--ig-blue-700)', color: 'var(--ig-blue-700)' }}>Periodo: <strong>Anno 2026</strong> <I.ChevD size={12}/></button>
        <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 34 }}>Area: Tutte <I.ChevD size={12}/></button>
        <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 34 }}>Target: Tutti <I.ChevD size={12}/></button>
        <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 34 }}>Territorio: Tutto <I.ChevD size={12}/></button>
        <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 34 }}>Operatore: Tutti <I.ChevD size={12}/></button>
        <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ height: 34 }}>Stato: Tutti <I.ChevD size={12}/></button>
        <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ height: 34, color: 'var(--ig-blue-700)' }}>+ Filtro avanzato</button>
        <span style={{ marginLeft: 'auto', fontSize: 12, color: 'var(--ig-ink-500)' }}>Visualizzati: <strong style={{ color: 'var(--ig-ink-900)' }}>2.140</strong> utenti · <strong style={{ color: 'var(--ig-ink-900)' }}>487</strong> schede · <strong style={{ color: 'var(--ig-ink-900)' }}>352</strong> richieste</span>
      </div>

      <div style={{ padding: '24px 32px 32px' }}>
        {/* KPI summary */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 14, marginBottom: 20 }}>
          {[
            ['Utenti registrati', '2.140', '+18%', 'var(--ig-blue-700)'],
            ['Schede pubblicate', '487', '+12%', 'var(--ig-teal-700)'],
            ['Colloqui erogati', '356', '+24%', 'var(--ig-violet-700)'],
            ['Ticket evasi', '294', 'tempo medio 18h', 'var(--ig-amber-700)'],
            ['Eventi · partecipanti', '247', '14 eventi', 'var(--ig-pink-700)'],
            ['Percorsi impresa', '17', '6 conclusi 2026', 'var(--ig-green-700)'],
          ].map(([l, v, d, c]) => (
            <div key={l} className="ig-card" style={{ padding: 14 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--ig-ink-500)' }}>{l}</div>
              <div className="ig-num" style={{ fontSize: 24, fontWeight: 800, color: c, letterSpacing: '-0.02em', lineHeight: 1.1, margin: '4px 0' }}>{v}</div>
              <div style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>{d}</div>
            </div>
          ))}
        </div>

        {/* TWO COLUMN */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 16, marginBottom: 16 }}>
          {/* Linea utenti */}
          <ReportCard title="Utenti registrati · andamento 2026" subtitle="Confronto con stesso periodo anno precedente">
            <div style={{ display: 'flex', gap: 18, fontSize: 11, marginBottom: 8 }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}><span style={{ width: 12, height: 3, background: 'var(--ig-blue-700)', borderRadius: 2 }}/><strong style={{ color: 'var(--ig-ink-900)' }}>2026</strong> · 2.140 totali</span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}><span style={{ width: 12, height: 3, background: 'var(--ig-ink-300)', borderRadius: 2 }}/>2025 · 1.812 totali</span>
              <span style={{ marginLeft: 'auto', color: 'var(--ig-green-700)', fontWeight: 700 }}>▲ +18.1%</span>
            </div>
            <LineChart
              labels={['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic']}
              series={[
                [1820, 1928, 2140, null, null, null, null, null, null, null, null, null].filter(v => v !== null),
                [1340, 1490, 1620, 1735, 1812, 1830, 1860, 1888, 1920, 1960, 1985, 2020],
              ]}
              color={['var(--ig-blue-700)', 'var(--ig-ink-400)']}
              height={200}
            />
          </ReportCard>

          {/* Donut occupazionale */}
          <ReportCard title="Utenti per stato occupazionale" subtitle="su 2.140 utenti registrati">
            <div style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
              <svg width="160" height="160" viewBox="0 0 160 160" style={{ transform: 'rotate(-90deg)' }}>
                {(() => {
                  const segs = [
                    [38, 'var(--ig-amber-600)', 'Disoccupato', '813'],
                    [29, 'var(--ig-blue-700)', 'Studente', '620'],
                    [14, 'var(--ig-green-600)', 'Lavoratore', '300'],
                    [12, 'var(--ig-violet-600)', 'NEET', '257'],
                    [7,  'var(--ig-teal-700)', 'Altro', '150'],
                  ];
                  const r = 56, c = 2 * Math.PI * r;
                  let off = 0;
                  return segs.map(([p, color], i) => {
                    const l = (p/100)*c;
                    const el = <circle key={i} cx="80" cy="80" r={r} fill="none" stroke={color} strokeWidth="20" strokeDasharray={`${l} ${c - l}`} strokeDashoffset={-off}/>;
                    off += l;
                    return el;
                  });
                })()}
              </svg>
              <div style={{ flex: 1, fontSize: 12 }}>
                {[
                  ['Disoccupato', 'var(--ig-amber-600)', '813', '38%'],
                  ['Studente', 'var(--ig-blue-700)', '620', '29%'],
                  ['Lavoratore', 'var(--ig-green-600)', '300', '14%'],
                  ['NEET', 'var(--ig-violet-600)', '257', '12%'],
                  ['Altro', 'var(--ig-teal-700)', '150', '7%'],
                ].map(([l, c, n, p]) => (
                  <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '5px 0' }}>
                    <span style={{ width: 10, height: 10, background: c, borderRadius: 2 }}/>
                    <span style={{ flex: 1, color: 'var(--ig-ink-700)' }}>{l}</span>
                    <span className="ig-num" style={{ color: 'var(--ig-ink-500)' }}>{n}</span>
                    <span style={{ fontWeight: 700, color: 'var(--ig-ink-900)', minWidth: 32, textAlign: 'right' }}>{p}</span>
                  </div>
                ))}
              </div>
            </div>
          </ReportCard>
        </div>

        {/* Row: Operator + topics */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
          <ReportCard title="Colloqui per operatore" subtitle="distribuzione argomenti · ultimi 73 giorni">
            <StackedBar
              data={[
                { label: 'M. Greco',    values: [42, 18, 28, 12], colors: ['var(--ig-blue-700)', 'var(--ig-teal-700)', 'var(--ig-amber-700)', 'var(--ig-violet-700)'] },
                { label: 'F. Bellomo',  values: [12, 56, 10, 8],  colors: ['var(--ig-blue-700)', 'var(--ig-teal-700)', 'var(--ig-amber-700)', 'var(--ig-violet-700)'] },
                { label: 'P. Rizzo',    values: [48, 14, 22, 10], colors: ['var(--ig-blue-700)', 'var(--ig-teal-700)', 'var(--ig-amber-700)', 'var(--ig-violet-700)'] },
                { label: 'L. Marino',   values: [28, 6, 38, 14],  colors: ['var(--ig-blue-700)', 'var(--ig-teal-700)', 'var(--ig-amber-700)', 'var(--ig-violet-700)'] },
              ]}
              height={180}
            />
            <div style={{ display: 'flex', gap: 18, fontSize: 11, marginTop: 14, flexWrap: 'wrap' }}>
              {[
                ['Lavoro', 'var(--ig-blue-700)'],
                ['Impresa', 'var(--ig-teal-700)'],
                ['Concorsi', 'var(--ig-amber-700)'],
                ['Altri', 'var(--ig-violet-700)'],
              ].map(([l, c]) => (
                <span key={l} style={{ display: 'flex', alignItems: 'center', gap: 5 }}><span style={{ width: 10, height: 10, background: c, borderRadius: 2 }}/>{l}</span>
              ))}
            </div>
          </ReportCard>

          <ReportCard title="Schede più consultate" subtitle="top 6 · ultimi 73 giorni · 24.182 visualizzazioni totali">
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                ['ITS Academy · Digital Marketing', 'formazione', 'Formazione', 3128],
                ['Erasmus+ Traineeship 2026/27', 'estero', 'Estero', 2841],
                ['Servizio Civile 2026 · 18 posti Enna', 'civile', 'Civile', 2104],
                ['Resto al Sud · fondo perduto 200k€', 'impresa', 'Impresa', 1972],
                ['Concorso Comune di Enna', 'concorso', 'Concorsi', 1654],
                ['Garanzia Giovani Sicilia', 'lavoro', 'Lavoro', 1289],
              ].map(([t, ac, area, n], i) => {
                const max = 3128;
                const pct = (n / max) * 100;
                return (
                  <div key={i}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 12, marginBottom: 4 }}>
                      <span style={{ fontWeight: 700, color: 'var(--ig-ink-500)', width: 18 }}>{i+1}</span>
                      <span style={{ flex: 1, fontWeight: 600, color: 'var(--ig-ink-900)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t}</span>
                      <span className={`ig-badge ig-badge--${ac}`} style={{ height: 18, fontSize: 10, padding: '0 6px' }}>{area}</span>
                      <span className="ig-num" style={{ fontWeight: 700, color: 'var(--ig-ink-900)', minWidth: 50, textAlign: 'right' }}>{n.toLocaleString('it')}</span>
                    </div>
                    <div style={{ height: 4, background: 'var(--ig-ink-100)', borderRadius: 999, overflow: 'hidden', marginLeft: 28 }}>
                      <div style={{ width: `${pct}%`, height: '100%', background: 'var(--ig-blue-700)' }}/>
                    </div>
                  </div>
                );
              })}
            </div>
          </ReportCard>
        </div>

        {/* Bottom row · 3 cards */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16, marginBottom: 16 }}>
          <ReportCard title="Tempi medi di risposta" subtitle="ticket · giorni feriali">
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {[
                ['Lavoro', 'var(--ig-blue-700)', '12h', 85],
                ['Impresa', 'var(--ig-teal-700)', '22h', 65],
                ['Concorsi', 'var(--ig-amber-700)', '9h', 92],
                ['Estero', 'var(--ig-amber-700)', '28h', 55],
                ['Diritti', 'var(--ig-pink-700)', '18h', 72],
                ['Civile', '#6e3d1a', '6h', 96],
              ].map(([l, c, t, p]) => (
                <div key={l}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 4 }}>
                    <span style={{ color: 'var(--ig-ink-700)', fontWeight: 600 }}>{l}</span>
                    <span className="ig-num" style={{ color: c, fontWeight: 700 }}>{t}</span>
                  </div>
                  <div style={{ height: 5, background: 'var(--ig-ink-150)', borderRadius: 999, overflow: 'hidden' }}>
                    <div style={{ width: `${p}%`, height: '100%', background: c }}/>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ marginTop: 14, padding: 10, background: 'var(--ig-green-50)', borderRadius: 6, fontSize: 12, color: 'var(--ig-green-700)', display: 'flex', alignItems: 'center', gap: 6 }}>
              <I.Check size={12} strokeWidth={3}/> Media generale 18h · sotto SLA target di 48h
            </div>
          </ReportCard>

          <ReportCard title="Fonti · stato controlli" subtitle="76 fonti monitorate">
            <div style={{ display: 'flex', alignItems: 'center', gap: 18, marginBottom: 14 }}>
              <svg width="110" height="110" viewBox="0 0 110 110" style={{ transform: 'rotate(-90deg)' }}>
                {(() => {
                  const segs = [
                    [84, 'var(--ig-green-600)'],
                    [10, 'var(--ig-amber-600)'],
                    [4,  'var(--ig-amber-700)'],
                    [2,  'var(--ig-red-600)'],
                  ];
                  const r = 38, c = 2 * Math.PI * r;
                  let off = 0;
                  return segs.map(([p, color], i) => {
                    const l = (p/100)*c;
                    const el = <circle key={i} cx="55" cy="55" r={r} fill="none" stroke={color} strokeWidth="16" strokeDasharray={`${l} ${c-l}`} strokeDashoffset={-off}/>;
                    off += l;
                    return el;
                  });
                })()}
              </svg>
              <div style={{ flex: 1 }}>
                <div className="ig-num" style={{ fontSize: 28, fontWeight: 800, color: 'var(--ig-green-700)', letterSpacing: '-0.02em' }}>84%</div>
                <div style={{ fontSize: 11, color: 'var(--ig-ink-500)' }}>fonti aggiornate</div>
              </div>
            </div>
            <div style={{ fontSize: 12 }}>
              {[
                ['Aggiornate', 'var(--ig-green-600)', 64],
                ['Da controllare', 'var(--ig-amber-600)', 8],
                ['In ritardo', 'var(--ig-amber-700)', 3],
                ['Non raggiungibili', 'var(--ig-red-600)', 2],
              ].map(([l, c, n]) => (
                <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', borderBottom: '1px solid var(--ig-border-soft)' }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 6, color: 'var(--ig-ink-700)' }}>
                    <span style={{ width: 8, height: 8, borderRadius: '50%', background: c }}/> {l}
                  </span>
                  <span className="ig-num" style={{ fontWeight: 700, color: 'var(--ig-ink-900)' }}>{n}</span>
                </div>
              ))}
            </div>
          </ReportCard>

          <ReportCard title="Percorsi impresa · esiti" subtitle="su 23 percorsi conclusi nel 2026">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              {[
                ['Candidati a bando', '8', 'var(--ig-blue-700)', '35%'],
                ['Avviati', '6', 'var(--ig-green-700)', '26%'],
                ['Ancora in lavorazione', '5', 'var(--ig-amber-700)', '22%'],
                ['Rinunciati', '4', 'var(--ig-red-600)', '17%'],
              ].map(([l, v, c, p]) => (
                <div key={l} style={{ padding: 12, background: 'var(--ig-ink-50)', borderRadius: 8, borderLeft: `3px solid ${c}` }}>
                  <div className="ig-num" style={{ fontSize: 22, fontWeight: 800, color: c, letterSpacing: '-0.02em' }}>{v}</div>
                  <div style={{ fontSize: 11, color: 'var(--ig-ink-700)', marginTop: 2 }}>{l}</div>
                  <div style={{ fontSize: 10, color: 'var(--ig-ink-500)' }}>{p}</div>
                </div>
              ))}
            </div>
            <div style={{ marginTop: 14, padding: 10, background: 'var(--ig-blue-50)', borderRadius: 6, fontSize: 12, color: 'var(--ig-blue-800)', display: 'flex', alignItems: 'start', gap: 6 }}>
              <I.Info size={14}/> Tasso di candidatura 61%, tra i migliori della Regione Sicilia.
            </div>
          </ReportCard>
        </div>
      </div>
    </BackendShell>
  );
}

window.BackendReportScreen = BackendReportScreen;
