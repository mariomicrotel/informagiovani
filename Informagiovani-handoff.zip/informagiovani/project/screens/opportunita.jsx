/* global React, IGIcons, PublicHeader, PublicFooter */
const I = IGIcons;

const listOpps = [
  {
    area: 'Lavoro', areaClass: 'lavoro',
    title: 'Garanzia Giovani Sicilia · 120 tirocini extracurriculari retribuiti',
    desc: 'Tirocini di 6 mesi con indennità mensile di 500€ in aziende del territorio ennese. Possibilità di trasformazione in contratto di apprendistato al termine del percorso.',
    target: '18–29 anni · NEET', territory: 'Provincia di Enna',
    type: 'Tirocinio',
    source: 'Regione Siciliana', sourceClass: 'ufficiale', sourceLabel: 'Ufficiale',
    scadenza: '12 giorni', urg: 'soon', scadDate: '28 marzo 2026',
    updated: 'oggi alle 09:14',
    views: 412,
  },
  {
    area: 'Estero & Mobilità', areaClass: 'estero',
    title: 'Erasmus+ Traineeship 2026/27 · tirocini in Europa',
    desc: 'Tirocini retribuiti da 2 a 12 mesi presso enti pubblici, imprese e centri di ricerca in 33 paesi europei con borsa mensile fino a 700€.',
    target: 'Universitari · Neolaureati', territory: 'Europa',
    type: 'Tirocinio',
    source: 'Agenzia Nazionale INDIRE', sourceClass: 'ufficiale', sourceLabel: 'Ufficiale',
    scadenza: '3 giorni', urg: 'urgent', scadDate: '17 marzo 2026',
    updated: 'ieri alle 17:22',
    views: 1289,
  },
  {
    area: 'Fare Impresa', areaClass: 'impresa',
    title: 'Resto al Sud · contributo a fondo perduto fino a 200.000€',
    desc: 'Agevolazioni per nuove attività imprenditoriali e libere professioni di under 56 nelle regioni del Mezzogiorno. Coperture fino al 100% delle spese ammissibili.',
    target: '18–55 anni · Aspiranti imprenditori', territory: 'Italia · Sud',
    type: 'Bando impresa',
    source: 'Invitalia', sourceClass: 'ufficiale', sourceLabel: 'Ufficiale',
    scadenza: 'Sempre aperta', urg: 'ok', scadDate: 'fino esaurimento fondi',
    updated: '3 giorni fa',
    views: 2104,
  },
  {
    area: 'Concorsi', areaClass: 'concorso',
    title: 'Concorso pubblico · 4 Istruttori Amm.vi categoria C · Comune di Enna',
    desc: 'Selezione pubblica per esami per la copertura di 4 posti a tempo indeterminato presso il Comune di Enna. Riserva del 50% per i giovani under 36.',
    target: 'Diplomati/Laureati', territory: 'Enna città',
    type: 'Concorso',
    source: 'Comune di Enna', sourceClass: 'ufficiale', sourceLabel: 'Ufficiale',
    scadenza: '21 giorni', urg: 'soon', scadDate: '4 aprile 2026',
    updated: '5 giorni fa',
    views: 832,
  },
  {
    area: 'Formazione', areaClass: 'formazione',
    title: 'ITS Academy Sicilia · Tecnico superiore Digital Marketing',
    desc: 'Corso biennale post-diploma con 800 ore di stage in aziende. Sede di Catania con sessioni a Enna. Quota di partecipazione gratuita, borsa di studio per 10 posti.',
    target: '18–35 anni · Diplomati', territory: 'Sicilia',
    type: 'Corso',
    source: 'Fondazione ITS Steve Jobs', sourceClass: 'partner', sourceLabel: 'Partner',
    scadenza: '14 giorni', urg: 'soon', scadDate: '30 marzo 2026',
    updated: '1 settimana fa',
    views: 547,
  },
  {
    area: 'Servizio Civile', areaClass: 'civile',
    title: 'Servizio Civile Universale 2026 · 18 posti a Enna',
    desc: 'Progetti annuali nei settori educazione, ambiente, patrimonio culturale e inclusione con assegno mensile di 507,30€. Riconoscimento crediti universitari.',
    target: '18–28 anni', territory: 'Enna città',
    type: 'Servizio',
    source: 'Dipartimento Politiche Giovanili', sourceClass: 'ufficiale', sourceLabel: 'Ufficiale',
    scadenza: '7 giorni', urg: 'urgent', scadDate: '21 marzo 2026',
    updated: 'oggi alle 11:02',
    views: 1842,
  },
];

function ListCard({ data }) {
  return (
    <article className="ig-card" style={{ padding: 24, display: 'grid', gridTemplateColumns: '1fr 220px', gap: 28, transition: 'all .2s' }}>
      <div style={{ minWidth: 0 }}>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 14 }}>
          <span className={`ig-badge ig-badge--${data.areaClass}`}>{data.area}</span>
          <span className="ig-badge ig-badge--state-pub" style={{ background: 'var(--ig-ink-75)', color: 'var(--ig-ink-700)' }}>{data.type}</span>
          <span className={`ig-badge ig-badge--src-${data.sourceClass}`}><I.ShieldChk size={12}/>{data.sourceLabel}</span>
        </div>
        <h3 style={{ fontSize: 21, fontWeight: 700, lineHeight: 1.25, color: 'var(--ig-ink-900)', marginBottom: 10, letterSpacing: '-0.01em' }}>{data.title}</h3>
        <p style={{ fontSize: 15, color: 'var(--ig-ink-500)', lineHeight: 1.55, marginBottom: 16 }}>{data.desc}</p>

        <div style={{ display: 'flex', gap: 22, fontSize: 13, color: 'var(--ig-ink-500)', flexWrap: 'wrap', alignItems: 'center', marginBottom: 16 }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <I.Users size={14} color="var(--ig-ink-400)"/>
            <strong style={{ color: 'var(--ig-ink-700)', fontWeight: 600 }}>{data.target}</strong>
          </span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <I.MapPin size={14} color="var(--ig-ink-400)"/>{data.territory}
          </span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <I.Building size={14} color="var(--ig-ink-400)"/>{data.source}
          </span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <I.Eye size={14} color="var(--ig-ink-400)"/>{data.views} visualizzazioni
          </span>
        </div>

        <div style={{ fontSize: 12, color: 'var(--ig-ink-400)' }}>Aggiornato {data.updated}</div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, paddingLeft: 24, borderLeft: '1px solid var(--ig-border-soft)' }}>
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6 }}>Scadenza</div>
          {data.urg === 'ok' ? (
            <div>
              <div style={{ fontSize: 18, fontWeight: 700, color: 'var(--ig-green-700)' }}>Sempre aperta</div>
              <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginTop: 2 }}>{data.scadDate}</div>
            </div>
          ) : (
            <div>
              <div className="ig-num" style={{
                fontSize: 24, fontWeight: 800, letterSpacing: '-0.02em',
                color: data.urg === 'urgent' ? 'var(--ig-red-700)' : 'var(--ig-amber-800)',
              }}>
                {data.scadenza}
              </div>
              <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginTop: 2 }}>Entro il {data.scadDate}</div>
            </div>
          )}
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 'auto' }}>
          <button className="ig-btn ig-btn--primary" style={{ width: '100%', justifyContent: 'center' }}>Dettagli <I.ArrowR size={14}/></button>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ flex: 1, justifyContent: 'center' }}><I.Bookmark size={14}/> Salva</button>
            <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ flex: 1, justifyContent: 'center' }}><I.Chat size={14}/> Info</button>
          </div>
        </div>
      </div>
    </article>
  );
}

function FilterGroup({ title, options, defaultOpen = true }) {
  return (
    <div style={{ padding: '20px 0', borderBottom: '1px solid var(--ig-border-soft)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: defaultOpen ? 14 : 0, cursor: 'pointer' }}>
        <h4 style={{ fontSize: 14, fontWeight: 700, color: 'var(--ig-ink-900)' }}>{title}</h4>
        <I.ChevU size={16} color="var(--ig-ink-500)"/>
      </div>
      {defaultOpen && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {options.map(([label, count, checked]) => (
            <label key={label} style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', fontSize: 14 }}>
              <span style={{
                width: 18, height: 18, borderRadius: 4,
                border: checked ? 'none' : '1.5px solid var(--ig-ink-300)',
                background: checked ? 'var(--ig-primary)' : 'white',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flex: '0 0 auto',
              }}>
                {checked && <I.Check size={12} color="white" strokeWidth={2.5}/>}
              </span>
              <span style={{ color: checked ? 'var(--ig-ink-900)' : 'var(--ig-ink-700)', fontWeight: checked ? 600 : 500, flex: 1 }}>{label}</span>
              <span style={{ fontSize: 12, color: 'var(--ig-ink-400)', fontFamily: 'var(--ig-font-mono)' }}>{count}</span>
            </label>
          ))}
        </div>
      )}
    </div>
  );
}

function OpportunitaScreen() {
  return (
    <div className="ig" style={{ width: 1440, background: 'var(--ig-bg)', minHeight: 1600 }}>
      <PublicHeader active="Opportunità"/>

      {/* Breadcrumb + title */}
      <div style={{ background: 'white', borderBottom: '1px solid var(--ig-border-soft)' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '20px 32px 28px' }}>
          <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', display: 'flex', alignItems: 'center', gap: 6, marginBottom: 16 }}>
            <a href="#" style={{ color: 'var(--ig-ink-500)' }}>Home</a>
            <I.ChevR size={12}/>
            <span style={{ color: 'var(--ig-ink-900)', fontWeight: 600 }}>Opportunità e servizi</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
            <div>
              <h1 style={{ fontSize: 38, fontWeight: 700, letterSpacing: '-0.025em', marginBottom: 8 }}>Opportunità e servizi</h1>
              <p style={{ fontSize: 16, color: 'var(--ig-ink-500)', maxWidth: 720 }}>
                487 schede informative aggiornate dagli operatori. Filtra per area, target, territorio o scadenza per trovare l&apos;opportunità giusta per te.
              </p>
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button className="ig-btn ig-btn--secondary">
                <I.Download size={16}/> Esporta lista
              </button>
              <button className="ig-btn ig-btn--accent">
                <I.Bell size={16}/> Avvisami su nuove
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Search bar */}
      <div style={{ maxWidth: 1280, margin: '24px auto 0', padding: '0 32px' }}>
        <div className="ig-card" style={{ padding: 14, display: 'flex', gap: 10, alignItems: 'center' }}>
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 10, padding: '0 16px' }}>
            <I.Search size={20} color="var(--ig-ink-400)"/>
            <input
              style={{ flex: 1, border: 'none', outline: 'none', fontSize: 16, padding: '14px 0', color: 'var(--ig-ink-900)', background: 'transparent', fontFamily: 'inherit' }}
              placeholder="Cerca tra opportunità, corsi, concorsi, servizi ed eventi..."
              defaultValue="tirocinio retribuito"
            />
            <button style={{ background: 'none', border: 'none', padding: 4, color: 'var(--ig-ink-400)', cursor: 'pointer' }}><I.X size={18}/></button>
          </div>
          <button className="ig-btn ig-btn--primary">Cerca <I.ArrowR size={14}/></button>
        </div>

        {/* Active filters */}
        <div style={{ marginTop: 18, display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <span style={{ fontSize: 13, color: 'var(--ig-ink-500)', fontWeight: 600 }}>Filtri attivi:</span>
          {[
            ['Lavoro', 'var(--ig-blue-100)', 'var(--ig-blue-800)'],
            ['Estero & Mobilità', 'var(--ig-amber-100)', 'var(--ig-amber-800)'],
            ['18-25 anni', 'var(--ig-ink-100)', 'var(--ig-ink-700)'],
            ['Provincia di Enna', 'var(--ig-ink-100)', 'var(--ig-ink-700)'],
            ['Entro 30 giorni', 'var(--ig-ink-100)', 'var(--ig-ink-700)'],
          ].map(([label, bg, fg]) => (
            <span key={label} style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              height: 28, padding: '0 10px', borderRadius: 6,
              background: bg, color: fg,
              fontSize: 13, fontWeight: 600,
            }}>
              {label} <I.X size={12}/>
            </span>
          ))}
          <button style={{ background: 'none', border: 'none', color: 'var(--ig-blue-700)', fontSize: 13, fontWeight: 600, cursor: 'pointer', textDecoration: 'underline' }}>Azzera tutti</button>
        </div>
      </div>

      {/* Main layout */}
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '28px 32px 80px', display: 'grid', gridTemplateColumns: '280px 1fr', gap: 32 }}>
        {/* SIDEBAR FILTERS */}
        <aside style={{ position: 'relative' }}>
          <div className="ig-card" style={{ padding: '8px 22px', position: 'sticky', top: 24 }}>
            <div style={{ padding: '16px 0', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h3 style={{ fontSize: 16, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 8 }}>
                <I.Sliders size={16}/> Filtri
              </h3>
              <span style={{ fontSize: 12, color: 'var(--ig-ink-500)', background: 'var(--ig-ink-75)', padding: '2px 8px', borderRadius: 999, fontWeight: 600 }}>5 attivi</span>
            </div>
            <FilterGroup title="Area tematica" options={[
              ['Lavoro', 142, true],
              ['Formazione', 98, false],
              ['Fare Impresa', 47, false],
              ['Estero & Mobilità', 56, true],
              ['Diritti e Cittadinanza', 31, false],
              ['Cultura', 24, false],
              ['Servizio Civile', 8, false],
              ['Concorsi', 81, false],
            ]}/>
            <FilterGroup title="Target" options={[
              ['14–18 anni', 34, false],
              ['18–25 anni', 287, true],
              ['26–35 anni', 156, false],
              ['Studenti', 124, false],
              ['Universitari', 102, false],
              ['NEET', 89, false],
              ['Disoccupati', 167, false],
            ]}/>
            <FilterGroup title="Territorio" defaultOpen={true} options={[
              ['Enna città', 87, false],
              ['Provincia di Enna', 134, true],
              ['Sicilia', 98, false],
              ['Italia', 78, false],
              ['Europa', 56, false],
              ['Online', 34, false],
            ]}/>
            <FilterGroup title="Scadenza" defaultOpen={true} options={[
              ['Sempre aperte', 87, false],
              ['Entro 7 giorni', 14, false],
              ['Entro 30 giorni', 78, true],
              ['Questo trimestre', 156, false],
            ]}/>
            <FilterGroup title="Affidabilità fonte" defaultOpen={false} options={[]}/>
          </div>
        </aside>

        {/* RESULTS */}
        <div>
          {/* Toolbar */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
            <div style={{ fontSize: 15, color: 'var(--ig-ink-700)' }}>
              <strong style={{ color: 'var(--ig-ink-900)', fontWeight: 700 }}>247 risultati</strong> per &quot;tirocinio retribuito&quot;
            </div>
            <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>Ordina:</span>
                <div className="ig-input" style={{ height: 38, padding: '0 12px', display: 'flex', alignItems: 'center', gap: 8, width: 'auto', fontSize: 14, fontWeight: 600, color: 'var(--ig-ink-900)' }}>
                  Consigliate per me <I.ChevD size={14} color="var(--ig-ink-500)"/>
                </div>
              </div>
              <div style={{ display: 'flex', border: '1px solid var(--ig-border)', borderRadius: 6, overflow: 'hidden' }}>
                <button style={{ background: 'var(--ig-ink-900)', color: 'white', border: 'none', padding: '9px 12px', cursor: 'pointer' }}><I.List size={16}/></button>
                <button style={{ background: 'white', color: 'var(--ig-ink-500)', border: 'none', padding: '9px 12px', cursor: 'pointer' }}><I.Grid size={16}/></button>
              </div>
            </div>
          </div>

          {/* Suggestion banner */}
          <div style={{
            background: 'linear-gradient(120deg, var(--ig-teal-50) 0%, var(--ig-blue-50) 100%)',
            border: '1px solid var(--ig-teal-100)',
            borderRadius: 12, padding: '16px 22px',
            display: 'flex', alignItems: 'center', gap: 16, marginBottom: 20,
          }}>
            <div style={{ width: 40, height: 40, borderRadius: 10, background: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--ig-teal-700)' }}>
              <I.Sparkle size={20}/>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ig-ink-900)' }}>3 opportunità sembrano in linea con il tuo profilo</div>
              <div style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>Sulla base dei tuoi interessi: lavoro, formazione tecnica, NEET 22 anni</div>
            </div>
            <button className="ig-btn ig-btn--secondary ig-btn--sm">Vedi solo consigliate</button>
          </div>

          {/* Result cards */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {listOpps.map((o, i) => <ListCard key={i} data={o}/>)}
          </div>

          {/* Pagination */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 32 }}>
            <div style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>Risultati 1–6 di 247</div>
            <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
              <button className="ig-btn ig-btn--secondary ig-btn--sm ig-btn--icon"><I.ArrowL size={14}/></button>
              <button style={{ width: 36, height: 36, border: 'none', background: 'var(--ig-ink-900)', color: 'white', borderRadius: 6, fontWeight: 700, cursor: 'pointer' }}>1</button>
              <button style={{ width: 36, height: 36, border: 'none', background: 'transparent', color: 'var(--ig-ink-700)', borderRadius: 6, fontWeight: 600, cursor: 'pointer' }}>2</button>
              <button style={{ width: 36, height: 36, border: 'none', background: 'transparent', color: 'var(--ig-ink-700)', borderRadius: 6, fontWeight: 600, cursor: 'pointer' }}>3</button>
              <span style={{ color: 'var(--ig-ink-400)', padding: '0 8px' }}>…</span>
              <button style={{ width: 36, height: 36, border: 'none', background: 'transparent', color: 'var(--ig-ink-700)', borderRadius: 6, fontWeight: 600, cursor: 'pointer' }}>42</button>
              <button className="ig-btn ig-btn--secondary ig-btn--sm ig-btn--icon"><I.ArrowR size={14}/></button>
            </div>
          </div>
        </div>
      </div>

      <PublicFooter/>
    </div>
  );
}

window.OpportunitaScreen = OpportunitaScreen;
