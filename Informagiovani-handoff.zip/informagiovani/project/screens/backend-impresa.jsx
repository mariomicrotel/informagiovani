/* global React, IGIcons, BackendShell, PageHeader */
const I = IGIcons;

function StepperItem({ num, label, status }) {
  const colors = {
    done: { ring: 'var(--ig-green-600)', bg: 'var(--ig-green-600)', fg: 'white' },
    active: { ring: 'var(--ig-blue-700)', bg: 'var(--ig-blue-700)', fg: 'white' },
    pending: { ring: 'var(--ig-ink-200)', bg: 'white', fg: 'var(--ig-ink-400)' },
  };
  const c = colors[status];
  return (
    <div style={{ flex: 1, position: 'relative', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
      <div style={{
        width: 32, height: 32, borderRadius: '50%',
        background: c.bg, color: c.fg, border: `2px solid ${c.ring}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontWeight: 800, fontSize: 12, fontFamily: 'var(--ig-font-mono)',
        zIndex: 2,
      }}>
        {status === 'done' ? <I.Check size={14} strokeWidth={3}/> : num}
      </div>
      <div style={{ fontSize: 11, color: status === 'pending' ? 'var(--ig-ink-400)' : 'var(--ig-ink-900)', fontWeight: status === 'active' ? 700 : 500, textAlign: 'center', maxWidth: 100, lineHeight: 1.3 }}>{label}</div>
    </div>
  );
}

function BMCCard({ title, color, items }) {
  return (
    <div style={{ background: 'white', border: '1px solid var(--ig-border-soft)', borderRadius: 8, padding: 14, display: 'flex', flexDirection: 'column' }}>
      <div style={{ fontSize: 11, fontWeight: 800, color, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>{title}</div>
      <ul style={{ paddingLeft: 0, listStyle: 'none', margin: 0, fontSize: 12, color: 'var(--ig-ink-700)', lineHeight: 1.5, flex: 1 }}>
        {items.map((it, i) => (
          <li key={i} style={{ display: 'flex', gap: 6, marginBottom: 6 }}>
            <span style={{ color, flex: '0 0 auto' }}>•</span>
            <span>{it}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function BackendImpresaScreen() {
  return (
    <BackendShell active="Percorsi impresa" breadcrumb={['Console', 'Sportello', 'Percorsi impresa', 'Catering siciliano per eventi']} height={1900}>
      <PageHeader
        title="Catering siciliano per eventi"
        subtitle="Salvatore Catanzaro · USR-001284 · percorso avviato il 5 marzo 2026 · tutor F. Bellomo · settore Food & Beverage"
        actions={<>
          <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Doc size={14}/> Genera dossier PDF</button>
          <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Mail size={14}/> Invia aggiornamento</button>
          <button className="ig-btn ig-btn--primary ig-btn--sm"><I.Plus size={14}/> Nuovo incontro</button>
        </>}
        tabs={['Candidatura', 'Valutazione', 'BMC · Business Model', 'SWOT', 'Business Plan', 'Tutoraggio', 'Dossier finale']}
        activeTab="BMC · Business Model"
      />

      <div style={{ padding: '24px 32px 32px' }}>
        {/* Stepper */}
        <div className="ig-card" style={{ padding: '22px 32px', marginBottom: 20 }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', position: 'relative', gap: 0 }}>
            <div style={{ position: 'absolute', top: 16, left: '7%', right: '7%', height: 2, background: 'var(--ig-ink-150)', zIndex: 1 }}>
              <div style={{ width: '40%', height: '100%', background: 'var(--ig-green-600)' }}/>
            </div>
            <StepperItem num="1" label="Candidatura" status="done"/>
            <StepperItem num="2" label="Colloquio orientamento" status="done"/>
            <StepperItem num="3" label="Analisi idea" status="done"/>
            <StepperItem num="4" label="Business Model Canvas" status="active"/>
            <StepperItem num="5" label="Business Plan" status="pending"/>
            <StepperItem num="6" label="Ricerca incentivi" status="pending"/>
            <StepperItem num="7" label="Accompagnamento bando" status="pending"/>
          </div>
        </div>

        {/* Status strip */}
        <div style={{
          display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24,
        }}>
          <div className="ig-card" style={{ padding: 16 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>Stato percorso</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: 'var(--ig-blue-700)' }}>● Step 4 di 7</div>
            <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginTop: 4 }}>Business Model Canvas</div>
          </div>
          <div className="ig-card" style={{ padding: 16 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>Tutor</div>
            <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ig-ink-900)' }}>F. Bellomo</div>
            <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginTop: 4 }}>4 incontri · prossimo 18 mar</div>
          </div>
          <div className="ig-card" style={{ padding: 16 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>Punteggio valutazione</div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
              <span className="ig-num" style={{ fontSize: 22, fontWeight: 800, color: 'var(--ig-green-700)' }}>78</span>
              <span style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>/100</span>
            </div>
            <div style={{ fontSize: 12, color: 'var(--ig-green-700)', marginTop: 4 }}>Ammesso al percorso</div>
          </div>
          <div className="ig-card" style={{ padding: 16 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-500)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>Incentivi target</div>
            <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ig-ink-900)' }}>Resto al Sud · Microcredito</div>
            <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginTop: 4 }}>Stima richiesta 65k€</div>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 20 }}>
          {/* BMC GRID */}
          <div className="ig-card" style={{ padding: 20 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 8 }}>
                <I.Grid size={18} color="var(--ig-teal-700)"/> Business Model Canvas
              </h3>
              <div style={{ display: 'flex', gap: 8 }}>
                <span className="ig-badge ig-badge--state-review">Bozza · 60% completo</span>
                <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ color: 'var(--ig-blue-700)' }}><I.Edit size={14}/> Modifica</button>
              </div>
            </div>

            {/* Canvas 5x4 grid */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gridTemplateRows: '1fr 1fr 0.7fr', gap: 8, minHeight: 480 }}>
              <div style={{ gridColumn: '1', gridRow: '1 / 3' }}>
                <BMCCard title="Partner chiave" color="var(--ig-violet-700)" items={[
                  'Produttori locali siciliani (formaggi, salumi)',
                  'Cantine territorio ennese',
                  'Wedding planner provincia',
                  'Camera di Commercio Enna',
                ]}/>
              </div>
              <div style={{ gridColumn: '2', gridRow: '1' }}>
                <BMCCard title="Attività chiave" color="var(--ig-blue-700)" items={[
                  'Preparazione menu personalizzati',
                  'Logistica e trasporto',
                  'Servizio evento',
                ]}/>
              </div>
              <div style={{ gridColumn: '3', gridRow: '1 / 3' }}>
                <BMCCard title="Proposta di valore" color="var(--ig-teal-700)" items={[
                  'Catering 100% siciliano con materie prime a km 0',
                  'Menu modulari personalizzabili per evento',
                  'Servizio &quot;chiavi in mano&quot;: dalla pianificazione al servizio',
                  'Prezzo competitivo per eventi 30-150 persone',
                ]}/>
              </div>
              <div style={{ gridColumn: '4', gridRow: '1' }}>
                <BMCCard title="Relazioni clienti" color="var(--ig-amber-700)" items={[
                  'Consulenza pre-evento dedicata',
                  'Followup post-evento',
                  'Programma fedeltà ricorrenze',
                ]}/>
              </div>
              <div style={{ gridColumn: '5', gridRow: '1 / 3' }}>
                <BMCCard title="Segmenti clientela" color="var(--ig-pink-700)" items={[
                  'Coppie 25-40 per matrimoni',
                  'PMI per eventi aziendali',
                  'Enti pubblici per ricorrenze',
                  'Privati per ricorrenze familiari',
                ]}/>
              </div>
              <div style={{ gridColumn: '2', gridRow: '2' }}>
                <BMCCard title="Risorse chiave" color="var(--ig-blue-700)" items={[
                  'Food truck attrezzato',
                  'Cucina di base con cella frigo',
                  'Brigata 4-6 persone freelance',
                ]}/>
              </div>
              <div style={{ gridColumn: '4', gridRow: '2' }}>
                <BMCCard title="Canali" color="var(--ig-amber-700)" items={[
                  'Sito web + booking online',
                  'Instagram & Facebook locali',
                  'Passaparola wedding planner',
                  'Partecipazione fiere',
                ]}/>
              </div>
              <div style={{ gridColumn: '1 / 4', gridRow: '3' }}>
                <BMCCard title="Struttura costi" color="var(--ig-red-700)" items={[
                  'Investimento iniziale food truck e attrezzature: 38k€',
                  'Costi operativi mensili (materie prime variabili + freelance): 4-8k€',
                  'Marketing e digital: 600€/mese',
                ]}/>
              </div>
              <div style={{ gridColumn: '4 / 6', gridRow: '3' }}>
                <BMCCard title="Flussi di ricavi" color="var(--ig-green-700)" items={[
                  'Servizio catering per evento: 2.5–8k€',
                  'Margine medio stimato 28% per evento',
                  'Target: 30-40 eventi/anno → 140-200k€ fatturato',
                ]}/>
              </div>
            </div>
          </div>

          {/* SIDEBAR · tutor + activities */}
          <aside>
            <div className="ig-card" style={{ padding: 20, marginBottom: 16 }}>
              <h3 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)', marginBottom: 14 }}>Tutor del percorso</h3>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
                <div style={{ width: 44, height: 44, borderRadius: '50%', background: 'var(--ig-teal-600)', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 14 }}>FB</div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700 }}>Francesco Bellomo</div>
                  <div style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}>Tutor Fare Impresa</div>
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6, fontSize: 12, color: 'var(--ig-ink-700)' }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><I.Mail size={12}/> impresa@informagiovani.enna.it</span>
                <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><I.Phone size={12}/> 0935 40 04 11</span>
              </div>
            </div>

            <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
              <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--ig-border-soft)' }}>
                <h3 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--ig-ink-700)' }}>Prossime attività</h3>
              </div>
              <div>
                {[
                  ['18 mar', '10:00', 'Incontro tutor', 'Revisione BMC · canvas e ipotesi mercato', 'var(--ig-blue-700)'],
                  ['25 mar', '10:00', 'Incontro tutor', 'Avvio business plan · sezione finanziaria', 'var(--ig-blue-700)'],
                  ['3 apr', '15:30', 'Workshop esterno', 'Resto al Sud · come candidarsi', 'var(--ig-amber-700)'],
                  ['10 apr', '—', 'Deliverable', 'Consegna prima bozza business plan', 'var(--ig-teal-700)'],
                  ['—', '—', 'Milestone', 'Candidatura Resto al Sud entro fine aprile', 'var(--ig-green-700)'],
                ].map(([d, t, type, desc, c], i) => (
                  <div key={i} style={{ padding: '14px 20px', borderBottom: i < 4 ? '1px solid var(--ig-border-soft)' : 'none' }}>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 4 }}>
                      <span style={{ fontSize: 11, fontWeight: 700, color: c, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{type}</span>
                      <span style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--ig-ink-500)', fontFamily: 'var(--ig-font-mono)' }}>{d} {t !== '—' && `· ${t}`}</span>
                    </div>
                    <div style={{ fontSize: 13, color: 'var(--ig-ink-900)' }}>{desc}</div>
                  </div>
                ))}
              </div>
            </div>

            <div style={{ marginTop: 16, padding: 16, background: 'var(--ig-amber-50)', border: '1px solid var(--ig-amber-100)', borderRadius: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <I.Alert size={16} color="var(--ig-amber-700)"/>
                <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ig-amber-800)' }}>Note responsabile</div>
              </div>
              <p style={{ fontSize: 12, color: 'var(--ig-ink-700)', lineHeight: 1.5 }}>
                BMC ben strutturato, manca quantificazione dei costi variabili. Importante chiarire con il tutor i numeri prima di passare al business plan.
              </p>
            </div>
          </aside>
        </div>
      </div>
    </BackendShell>
  );
}

window.BackendImpresaScreen = BackendImpresaScreen;
