/* global React, IGIcons */
const I = IGIcons;

function NavItem({ icon, label, active, badge, group }) {
  return (
    <a href="#" style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '9px 12px', borderRadius: 6,
      fontSize: 14, fontWeight: 600,
      color: active ? 'white' : 'rgba(255,255,255,0.7)',
      background: active ? 'rgba(255,255,255,0.12)' : 'transparent',
      borderLeft: active ? '3px solid var(--ig-amber-500)' : '3px solid transparent',
      marginLeft: -3,
      transition: 'all .15s',
    }}>
      <span style={{ color: active ? 'var(--ig-amber-500)' : 'rgba(255,255,255,0.45)' }}>{icon}</span>
      <span style={{ flex: 1 }}>{label}</span>
      {badge && (
        <span style={{
          background: typeof badge === 'string' ? 'var(--ig-amber-500)' : 'var(--ig-red-600)',
          color: 'white', fontSize: 11, fontWeight: 700,
          padding: '2px 7px', borderRadius: 999, minWidth: 22, textAlign: 'center',
        }}>{badge}</span>
      )}
    </a>
  );
}

function NavGroup({ title, children }) {
  return (
    <div style={{ marginBottom: 22 }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', letterSpacing: '0.1em', padding: '0 12px 10px' }}>{title}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>{children}</div>
    </div>
  );
}

// KPI card
function KpiCard({ label, value, delta, deltaPositive, hint, accent, icon, sparkline }) {
  return (
    <div className="ig-card" style={{ padding: 22 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
        <div style={{
          width: 38, height: 38, borderRadius: 8,
          background: accent.bg, color: accent.fg,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{icon}</div>
        {delta && (
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 3,
            fontSize: 12, fontWeight: 700,
            color: deltaPositive ? 'var(--ig-green-700)' : 'var(--ig-red-700)',
            background: deltaPositive ? 'var(--ig-green-100)' : 'var(--ig-red-100)',
            padding: '3px 8px', borderRadius: 999,
          }}>
            {deltaPositive ? '▲' : '▼'} {delta}
          </div>
        )}
      </div>
      <div style={{ fontSize: 13, color: 'var(--ig-ink-500)', fontWeight: 600, marginBottom: 2 }}>{label}</div>
      <div className="ig-num" style={{ fontSize: 32, fontWeight: 800, color: 'var(--ig-ink-900)', letterSpacing: '-0.025em', lineHeight: 1.1, marginBottom: 6 }}>{value}</div>
      <div style={{ fontSize: 12, color: 'var(--ig-ink-500)' }}>{hint}</div>
      {sparkline && (
        <div style={{ marginTop: 10, height: 32 }}>{sparkline}</div>
      )}
    </div>
  );
}

function Sparkline({ data, color }) {
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const w = 200, h = 32;
  const step = w / (data.length - 1);
  const points = data.map((v, i) => `${i * step},${h - ((v - min) / range) * (h - 4) - 2}`).join(' ');
  return (
    <svg width="100%" height={h} viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none">
      <defs>
        <linearGradient id={`sp-${color.slice(1)}`} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.25"/>
          <stop offset="100%" stopColor={color} stopOpacity="0"/>
        </linearGradient>
      </defs>
      <polygon points={`0,${h} ${points} ${w},${h}`} fill={`url(#sp-${color.slice(1)})`}/>
      <polyline points={points} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

// Bar chart
function BarChart() {
  const data = [
    ['Lavoro', 86, 'var(--ig-blue-700)'],
    ['Formazione', 62, 'var(--ig-violet-600)'],
    ['Impresa', 41, 'var(--ig-teal-700)'],
    ['Estero', 38, 'var(--ig-amber-600)'],
    ['Diritti', 29, 'var(--ig-pink-700)'],
    ['Civile', 22, '#6e3d1a'],
    ['Cultura', 18, '#93421b'],
    ['Concorsi', 56, '#1b3a8a'],
  ];
  const max = Math.max(...data.map(d => d[1]));
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 14, height: 200, padding: '0 4px' }}>
      {data.map(([label, value, color]) => (
        <div key={label} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--ig-ink-700)', fontFamily: 'var(--ig-font-mono)' }}>{value}</div>
          <div style={{ width: '100%', height: (value / max) * 150, background: color, borderRadius: '4px 4px 0 0', position: 'relative' }}>
            <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: '40%', background: 'rgba(255,255,255,0.15)' }}/>
          </div>
          <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', textAlign: 'center', whiteSpace: 'nowrap' }}>{label}</div>
        </div>
      ))}
    </div>
  );
}

// Donut
function Donut() {
  const segments = [
    [38, 'var(--ig-blue-700)', '18–25', '38%'],
    [27, 'var(--ig-teal-700)', '26–35', '27%'],
    [18, 'var(--ig-amber-600)', '14–18', '18%'],
    [12, 'var(--ig-violet-600)', 'Universitari', '12%'],
    [5, 'var(--ig-pink-700)', 'Altri', '5%'],
  ];
  const r = 64;
  const c = 2 * Math.PI * r;
  let offset = 0;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 28 }}>
      <svg width="180" height="180" viewBox="0 0 180 180" style={{ transform: 'rotate(-90deg)' }}>
        {segments.map(([pct, color], i) => {
          const len = (pct / 100) * c;
          const el = (
            <circle key={i} cx="90" cy="90" r={r} fill="none"
              stroke={color} strokeWidth="24"
              strokeDasharray={`${len} ${c - len}`}
              strokeDashoffset={-offset}
            />
          );
          offset += len;
          return el;
        })}
      </svg>
      <div style={{ flex: 1 }}>
        {segments.map(([pct, color, label, p]) => (
          <div key={label} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '6px 0', borderBottom: '1px solid var(--ig-border-soft)' }}>
            <div style={{ width: 10, height: 10, borderRadius: 2, background: color }}/>
            <span style={{ fontSize: 13, color: 'var(--ig-ink-700)', flex: 1 }}>{label}</span>
            <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--ig-ink-900)' }}>{p}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function BackendScreen() {
  return (
    <div className="ig" style={{ width: 1440, background: 'var(--ig-bg)', minHeight: 1900, display: 'flex' }}>
      {/* ===== SIDEBAR ===== */}
      <aside style={{
        width: 256, background: 'var(--ig-blue-900)', color: 'white',
        flex: '0 0 auto', display: 'flex', flexDirection: 'column',
        position: 'sticky', top: 0, height: '100vh', maxHeight: 1900,
      }}>
        {/* Brand */}
        <div style={{ padding: '22px 18px 22px', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 38, height: 38, borderRadius: 8, background: 'var(--ig-amber-500)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <svg width="22" height="22" viewBox="0 0 28 28" fill="none">
                <path d="M4 22 L14 4 L24 22 Z" stroke="var(--ig-blue-900)" strokeWidth="2.4" strokeLinejoin="round"/>
                <circle cx="14" cy="15" r="2.4" fill="var(--ig-blue-900)"/>
              </svg>
            </div>
            <div style={{ lineHeight: 1.1 }}>
              <div style={{ fontSize: 14, fontWeight: 800, color: 'white' }}>Informagiovani</div>
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)', marginTop: 3 }}>Console operatori · Enna</div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: '20px 10px', overflowY: 'auto' }}>
          <NavGroup title="Panoramica">
            <NavItem icon={<I.Home size={18}/>} label="Dashboard" active/>
            <NavItem icon={<I.Chart size={18}/>} label="Report"/>
            <NavItem icon={<I.Sparkle size={18}/>} label="Audit log"/>
          </NavGroup>

          <NavGroup title="Contenuti">
            <NavItem icon={<I.Doc size={18}/>} label="Schede informative" badge="12"/>
            <NavItem icon={<I.Link size={18}/>} label="Fonti" badge="4"/>
            <NavItem icon={<I.Calendar size={18}/>} label="Eventi"/>
            <NavItem icon={<I.Send size={18}/>} label="Newsletter"/>
          </NavGroup>

          <NavGroup title="Sportello">
            <NavItem icon={<I.Users size={18}/>} label="Utenti giovani"/>
            <NavItem icon={<I.Chat size={18}/>} label="Colloqui"/>
            <NavItem icon={<I.Calendar size={18}/>} label="Appuntamenti" badge="8"/>
            <NavItem icon={<I.Flag size={18}/>} label="Ticket / Richieste" badge="23"/>
            <NavItem icon={<I.Bulb size={18}/>} label="Percorsi impresa"/>
          </NavGroup>

          <NavGroup title="Ecosistema">
            <NavItem icon={<I.Building size={18}/>} label="Partner"/>
            <NavItem icon={<I.Download size={18}/>} label="Import / Export"/>
            <NavItem icon={<I.Settings size={18}/>} label="Impostazioni"/>
          </NavGroup>
        </nav>

        {/* User box */}
        <div style={{ padding: 14, borderTop: '1px solid rgba(255,255,255,0.08)', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'var(--ig-teal-600)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 13, color: 'white' }}>GF</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: 'white' }}>Giulia Fontana</div>
            <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.55)' }}>Responsabile servizio</div>
          </div>
          <I.ChevR size={14} color="rgba(255,255,255,0.5)"/>
        </div>
      </aside>

      {/* ===== MAIN ===== */}
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        {/* Topbar */}
        <div style={{ background: 'white', borderBottom: '1px solid var(--ig-border-soft)', padding: '14px 32px', display: 'flex', alignItems: 'center', gap: 20 }}>
          <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', display: 'flex', alignItems: 'center', gap: 6 }}>
            <span>Console</span>
            <I.ChevR size={12}/>
            <span style={{ color: 'var(--ig-ink-900)', fontWeight: 600 }}>Dashboard</span>
          </div>

          <div style={{ flex: 1, maxWidth: 520, position: 'relative' }}>
            <I.Search size={16} color="var(--ig-ink-400)" />
            <input
              className="ig-input"
              placeholder="Cerca schede, utenti, fonti, ticket, eventi… (Ctrl K)"
              style={{ paddingLeft: 40, height: 38, fontSize: 14 }}
            />
            <div style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }}>
              <I.Search size={16} color="var(--ig-ink-400)"/>
            </div>
          </div>

          <div style={{ display: 'flex', gap: 4, alignItems: 'center', marginLeft: 'auto' }}>
            <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Plus size={14}/> Nuova scheda</button>
            <button className="ig-btn ig-btn--ghost ig-btn--icon" style={{ width: 38, height: 38, position: 'relative' }}>
              <I.Bell size={18}/>
              <span style={{ position: 'absolute', top: 7, right: 7, width: 8, height: 8, background: 'var(--ig-red-600)', borderRadius: '50%', border: '2px solid white' }}/>
            </button>
            <button className="ig-btn ig-btn--ghost ig-btn--icon" style={{ width: 38, height: 38 }}><I.Mail size={18}/></button>
            <div style={{ width: 1, height: 24, background: 'var(--ig-border-soft)', margin: '0 8px' }}/>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}>
              <div style={{ width: 34, height: 34, borderRadius: '50%', background: 'var(--ig-teal-600)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 13, color: 'white' }}>GF</div>
              <I.ChevD size={14} color="var(--ig-ink-500)"/>
            </div>
          </div>
        </div>

        {/* Page header */}
        <div style={{ padding: '28px 32px 22px', borderBottom: '1px solid var(--ig-border-soft)', background: 'white' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
            <div>
              <h1 style={{ fontSize: 28, fontWeight: 700, letterSpacing: '-0.02em' }}>Buongiorno, Giulia 👋</h1>
              <p style={{ fontSize: 14, color: 'var(--ig-ink-500)', marginTop: 6 }}>Sabato 14 marzo 2026 · Sintesi dell&apos;attività dello sportello e dei contenuti pubblicati</p>
            </div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <div className="ig-input" style={{ height: 36, padding: '0 12px', display: 'flex', alignItems: 'center', gap: 8, width: 'auto', fontSize: 13, fontWeight: 600 }}>
                <I.Calendar size={14}/> Ultimi 30 giorni <I.ChevD size={14} color="var(--ig-ink-500)"/>
              </div>
              <button className="ig-btn ig-btn--secondary ig-btn--sm"><I.Download size={14}/> Esporta</button>
              <button className="ig-btn ig-btn--primary ig-btn--sm"><I.Plus size={14}/> Nuovo elemento</button>
            </div>
          </div>
        </div>

        <div style={{ padding: '24px 32px 48px', flex: 1 }}>
          {/* ROW 1: KPI primary 4 */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 14 }}>
            <KpiCard
              label="Schede pubblicate"
              value="487"
              delta="+12"
              deltaPositive
              hint="14 pubblicate negli ultimi 7 giorni"
              accent={{ bg: 'var(--ig-blue-50)', fg: 'var(--ig-blue-700)' }}
              icon={<I.Doc size={18}/>}
              sparkline={<Sparkline data={[40, 42, 45, 44, 48, 52, 50, 56, 58, 60, 62]} color="#1f5aa8"/>}
            />
            <KpiCard
              label="Schede da verificare"
              value="12"
              delta="+5"
              deltaPositive={false}
              hint="3 ferme da oltre 7 giorni"
              accent={{ bg: 'var(--ig-amber-100)', fg: 'var(--ig-amber-800)' }}
              icon={<I.Alert size={18}/>}
              sparkline={<Sparkline data={[6, 7, 5, 8, 9, 10, 12, 11, 12]} color="#d28a1c"/>}
            />
            <KpiCard
              label="Schede in scadenza"
              value="24"
              hint="Nei prossimi 14 giorni"
              accent={{ bg: 'var(--ig-red-100)', fg: 'var(--ig-red-700)' }}
              icon={<I.Clock size={18}/>}
              sparkline={<Sparkline data={[18, 20, 21, 19, 22, 24, 22, 24]} color="#c2362b"/>}
            />
            <KpiCard
              label="Ticket aperti"
              value="23"
              delta="−4"
              deltaPositive
              hint="Tempo medio risposta: 18h"
              accent={{ bg: 'var(--ig-teal-100)', fg: 'var(--ig-teal-700)' }}
              icon={<I.Chat size={18}/>}
              sparkline={<Sparkline data={[34, 30, 28, 32, 30, 25, 23]} color="#0f8077"/>}
            />
          </div>

          {/* ROW 2: KPI secondary 4 */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 14 }}>
            <KpiCard
              label="Utenti registrati"
              value="2.140"
              delta="+87"
              deltaPositive
              hint="Negli ultimi 30 giorni"
              accent={{ bg: 'var(--ig-violet-100)', fg: 'var(--ig-violet-700)' }}
              icon={<I.Users size={18}/>}
            />
            <KpiCard
              label="Appuntamenti oggi"
              value="8"
              hint="3 in presenza · 5 in remoto"
              accent={{ bg: 'var(--ig-blue-50)', fg: 'var(--ig-blue-700)' }}
              icon={<I.Calendar size={18}/>}
            />
            <KpiCard
              label="Colloqui del mese"
              value="142"
              delta="+18"
              deltaPositive
              hint="Distribuiti su 12 operatori"
              accent={{ bg: 'var(--ig-teal-100)', fg: 'var(--ig-teal-700)' }}
              icon={<I.Chat size={18}/>}
            />
            <KpiCard
              label="Eventi prossimi"
              value="14"
              hint="247 iscritti complessivi"
              accent={{ bg: 'var(--ig-amber-100)', fg: 'var(--ig-amber-800)' }}
              icon={<I.Calendar size={18}/>}
            />
          </div>

          {/* ROW 3: KPI thirds 4 */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 28 }}>
            <KpiCard
              label="Percorsi impresa attivi"
              value="17"
              hint="6 nella fase Business Plan"
              accent={{ bg: 'var(--ig-teal-100)', fg: 'var(--ig-teal-700)' }}
              icon={<I.Bulb size={18}/>}
            />
            <KpiCard
              label="Fonti da controllare"
              value="6"
              hint="Soglia controllo: 30 giorni"
              accent={{ bg: 'var(--ig-amber-100)', fg: 'var(--ig-amber-800)' }}
              icon={<I.Link size={18}/>}
            />
            <KpiCard
              label="Partner attivi"
              value="42"
              delta="+3"
              deltaPositive
              hint="3 in attesa di accreditamento"
              accent={{ bg: 'var(--ig-blue-50)', fg: 'var(--ig-blue-700)' }}
              icon={<I.Building size={18}/>}
            />
            <KpiCard
              label="Newsletter inviate"
              value="32"
              hint="Tasso apertura medio 41%"
              accent={{ bg: 'var(--ig-violet-100)', fg: 'var(--ig-violet-700)' }}
              icon={<I.Send size={18}/>}
            />
          </div>

          {/* CHARTS ROW */}
          <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 16, marginBottom: 28 }}>
            <div className="ig-card" style={{ padding: 24 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18 }}>
                <div>
                  <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 4 }}>Richieste per area tematica</h3>
                  <div style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>352 richieste · ultimi 30 giorni · +23% vs mese precedente</div>
                </div>
                <div style={{ display: 'flex', gap: 4 }}>
                  <button className="ig-btn ig-btn--secondary ig-btn--sm" style={{ background: 'var(--ig-ink-900)', color: 'white', borderColor: 'var(--ig-ink-900)' }}>30g</button>
                  <button className="ig-btn ig-btn--ghost ig-btn--sm">3m</button>
                  <button className="ig-btn ig-btn--ghost ig-btn--sm">12m</button>
                </div>
              </div>
              <BarChart/>
            </div>

            <div className="ig-card" style={{ padding: 24 }}>
              <div style={{ marginBottom: 18 }}>
                <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 4 }}>Utenti per fascia età</h3>
                <div style={{ fontSize: 13, color: 'var(--ig-ink-500)' }}>2.140 registrati totali</div>
              </div>
              <Donut/>
            </div>
          </div>

          {/* LISTS ROW */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            {/* Recent requests */}
            <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
              <div style={{ padding: '18px 22px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h3 style={{ fontSize: 16, fontWeight: 700 }}>Ultime richieste</h3>
                <a href="#" style={{ fontSize: 13, fontWeight: 600 }}>Tutte →</a>
              </div>
              <div>
                {[
                  ['#R-2841', 'Salvatore Catanzaro', 'Domanda Resto al Sud · documentazione', 'Impresa', 'impresa', 'Nuovo', 'state-valid', '12 min'],
                  ['#R-2840', 'Letizia Bonfiglio', 'Concorso Comune di Enna: scadenza', 'Concorsi', 'concorso', 'In lavorazione', 'state-review', '34 min'],
                  ['#R-2839', 'Marco Lo Curto', 'Erasmus+ traineeship Olanda', 'Estero', 'estero', 'Nuovo', 'state-valid', '1h'],
                  ['#R-2838', 'Anna Mineo', 'CV e lettera di presentazione', 'Lavoro', 'lavoro', 'Assegnato', 'state-update', '2h'],
                  ['#R-2837', 'Giuseppe Russo', 'Bonus cultura 18app residui', 'Cultura', 'cultura', 'Evaso', 'state-pub', '3h'],
                  ['#R-2836', 'Chiara La Rosa', 'Microcredito imprenditoriale', 'Impresa', 'impresa', 'In attesa utente', 'state-review', '4h'],
                ].map((r) => (
                  <div key={r[0]} style={{ display: 'grid', gridTemplateColumns: '70px 1fr 110px 110px 50px', gap: 12, padding: '14px 22px', borderBottom: '1px solid var(--ig-border-soft)', alignItems: 'center' }}>
                    <span style={{ fontSize: 12, fontFamily: 'var(--ig-font-mono)', color: 'var(--ig-ink-500)' }}>{r[0]}</span>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-900)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{r[2]}</div>
                      <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginTop: 2 }}>{r[1]}</div>
                    </div>
                    <span className={`ig-badge ig-badge--${r[4]}`} style={{ height: 22, fontSize: 11 }}>{r[3]}</span>
                    <span className={`ig-badge ig-badge--${r[6]}`} style={{ height: 22, fontSize: 11 }}>{r[5]}</span>
                    <span style={{ fontSize: 11, color: 'var(--ig-ink-400)', textAlign: 'right' }}>{r[7]}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Schede da validare */}
            <div className="ig-card" style={{ padding: 0, overflow: 'hidden' }}>
              <div style={{ padding: '18px 22px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <h3 style={{ fontSize: 16, fontWeight: 700 }}>Schede da validare</h3>
                  <span className="ig-badge ig-badge--state-review">12 in coda</span>
                </div>
                <a href="#" style={{ fontSize: 13, fontWeight: 600 }}>Apri coda →</a>
              </div>
              <div>
                {[
                  ['Servizio Civile Universale 2026 — bandi territoriali', 'civile', 'Servizio Civile', 'M. Greco', 'state-review', 'Da verificare'],
                  ['Bando Cultura Crea Sicilia 2026', 'cultura', 'Cultura', 'L. Marino', 'state-update', 'Da aggiornare'],
                  ['Tirocini Garanzia Giovani II ciclo', 'lavoro', 'Lavoro', 'P. Rizzo', 'state-review', 'Da verificare'],
                  ['Concorso Polizia Municipale Enna', 'concorso', 'Concorsi', 'F. Bellomo', 'state-valid', 'Validata'],
                  ['Microcredito Sicilia per giovani', 'impresa', 'Impresa', 'M. Greco', 'state-review', 'Da verificare'],
                  ['ITS digital marketing Catania', 'formazione', 'Formazione', 'P. Rizzo', 'state-draft', 'Bozza'],
                ].map((s, i) => (
                  <div key={i} style={{ display: 'grid', gridTemplateColumns: '1fr 110px 100px 110px', gap: 12, padding: '14px 22px', borderBottom: '1px solid var(--ig-border-soft)', alignItems: 'center' }}>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ig-ink-900)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{s[0]}</div>
                      <div style={{ fontSize: 11, color: 'var(--ig-ink-500)', marginTop: 2 }}>Autore: {s[3]}</div>
                    </div>
                    <span className={`ig-badge ig-badge--${s[1]}`} style={{ height: 22, fontSize: 11 }}>{s[2]}</span>
                    <span className={`ig-badge ig-badge--${s[4]}`} style={{ height: 22, fontSize: 11 }}>{s[5]}</span>
                    <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end' }}>
                      <button className="ig-btn ig-btn--ghost ig-btn--sm" style={{ height: 28, padding: '0 8px' }}><I.Eye size={14}/></button>
                      <button className="ig-btn ig-btn--primary ig-btn--sm" style={{ height: 28, padding: '0 10px', fontSize: 12 }}>Apri</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Appuntamenti oggi */}
          <div className="ig-card" style={{ padding: 0, overflow: 'hidden', marginTop: 16 }}>
            <div style={{ padding: '18px 22px', borderBottom: '1px solid var(--ig-border-soft)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h3 style={{ fontSize: 16, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 10 }}>
                <I.Calendar size={18} color="var(--ig-blue-700)"/>
                Appuntamenti di oggi · 14 marzo 2026
              </h3>
              <div style={{ display: 'flex', gap: 8 }}>
                <a href="#" style={{ fontSize: 13, fontWeight: 600 }}>Apri calendario →</a>
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 0 }}>
              {[
                ['09:30', 'in presenza', 'Salvatore Catanzaro', 'Resto al Sud · documentazione', 'M. Greco', 'var(--ig-green-600)', 'Confermato'],
                ['10:30', 'videochiamata', 'Letizia Bonfiglio', 'Orientamento concorsi pubblici', 'L. Marino', 'var(--ig-green-600)', 'Confermato'],
                ['11:30', 'in presenza', 'Marco Lo Curto', 'Erasmus+ traineeship UE', 'M. Greco', 'var(--ig-amber-600)', 'Da confermare'],
                ['12:00', 'telefono', 'Anna Mineo', 'Revisione CV e lettera', 'P. Rizzo', 'var(--ig-green-600)', 'Confermato'],
                ['15:00', 'videochiamata', 'Giuseppe Russo', 'Idea impresa: food truck', 'F. Bellomo', 'var(--ig-green-600)', 'Confermato'],
                ['15:45', 'in presenza', 'Chiara La Rosa', 'Microcredito · primo colloquio', 'F. Bellomo', 'var(--ig-amber-600)', 'Da confermare'],
                ['16:30', 'videochiamata', 'Davide Pignato', 'Servizio civile · scelta progetto', 'L. Marino', 'var(--ig-green-600)', 'Confermato'],
                ['17:00', 'in presenza', 'Sara Cilluffo', 'CV e portfolio creativo', 'P. Rizzo', 'var(--ig-ink-400)', 'Tentativo'],
              ].map((a, i) => (
                <div key={i} style={{
                  padding: '16px 18px',
                  borderRight: i % 4 !== 3 ? '1px solid var(--ig-border-soft)' : 'none',
                  borderBottom: i < 4 ? '1px solid var(--ig-border-soft)' : 'none',
                  position: 'relative',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                    <div className="ig-num" style={{ fontSize: 18, fontWeight: 800, color: 'var(--ig-ink-900)', letterSpacing: '-0.01em' }}>{a[0]}</div>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, fontWeight: 600, color: a[5] }}>
                      <I.Dot size={8} color={a[5]}/> {a[6]}
                    </span>
                  </div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ig-ink-900)', marginBottom: 2 }}>{a[2]}</div>
                  <div style={{ fontSize: 12, color: 'var(--ig-ink-500)', marginBottom: 8, lineHeight: 1.35 }}>{a[3]}</div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: 11, color: 'var(--ig-ink-400)' }}>
                      {a[1] === 'in presenza' && <I.User size={11} style={{ display: 'inline', verticalAlign: '-2px', marginRight: 4 }}/>}
                      {a[1] === 'videochiamata' && <I.Video size={11} style={{ display: 'inline', verticalAlign: '-2px', marginRight: 4 }}/>}
                      {a[1] === 'telefono' && <I.Phone size={11} style={{ display: 'inline', verticalAlign: '-2px', marginRight: 4 }}/>}
                      {a[1]} · {a[4]}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

window.BackendScreen = BackendScreen;
