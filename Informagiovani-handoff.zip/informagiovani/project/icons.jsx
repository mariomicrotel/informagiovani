/* global React */

// Icon library — line icons, 1.6px stroke, 20px default.
// All take optional { size, className, color }.

const Icon = ({ children, size = 20, color = 'currentColor', strokeWidth = 1.6, className, fill }) => (
  <svg
    width={size} height={size} viewBox="0 0 24 24"
    fill={fill || 'none'} stroke={color}
    strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round"
    className={className} aria-hidden="true"
  >
    {children}
  </svg>
);

const I = {
  Search:    (p) => <Icon {...p}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></Icon>,
  Calendar:  (p) => <Icon {...p}><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 9h18M8 3v4M16 3v4"/></Icon>,
  Clock:     (p) => <Icon {...p}><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></Icon>,
  MapPin:    (p) => <Icon {...p}><path d="M12 21s-7-6-7-12a7 7 0 0 1 14 0c0 6-7 12-7 12Z"/><circle cx="12" cy="9" r="2.5"/></Icon>,
  Briefcase: (p) => <Icon {...p}><rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 13h18"/></Icon>,
  GradCap:   (p) => <Icon {...p}><path d="M2 9 12 4l10 5-10 5L2 9Z"/><path d="M6 11v4c0 1.5 3 3 6 3s6-1.5 6-3v-4M21 10v5"/></Icon>,
  Bulb:      (p) => <Icon {...p}><path d="M9 18h6M10 21h4M12 3a6 6 0 0 1 4 10.5c-.7.7-1 1.4-1 2.5H9c0-1.1-.3-1.8-1-2.5A6 6 0 0 1 12 3Z"/></Icon>,
  Globe:     (p) => <Icon {...p}><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></Icon>,
  Award:     (p) => <Icon {...p}><circle cx="12" cy="9" r="6"/><path d="m8.5 13.5-2 7L12 18l5.5 2.5-2-7"/></Icon>,
  Heart:     (p) => <Icon {...p}><path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.5-7 10-7 10Z"/></Icon>,
  Bookmark:  (p) => <Icon {...p}><path d="M6 4h12v17l-6-4-6 4V4Z"/></Icon>,
  BookmarkF: (p) => <Icon {...p} fill="currentColor"><path d="M6 4h12v17l-6-4-6 4V4Z"/></Icon>,
  User:      (p) => <Icon {...p}><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.5 3.5-7 8-7s8 2.5 8 7"/></Icon>,
  Users:     (p) => <Icon {...p}><circle cx="9" cy="8" r="3.5"/><path d="M2 20c.5-3.5 3-6 7-6s6.5 2.5 7 6"/><path d="M16 10a3 3 0 1 0 0-6M22 20c-.3-3-2-5-5-5.5"/></Icon>,
  Bell:      (p) => <Icon {...p}><path d="M6 17V11a6 6 0 0 1 12 0v6l2 2H4l2-2Z"/><path d="M10 21a2 2 0 0 0 4 0"/></Icon>,
  Chat:      (p) => <Icon {...p}><path d="M21 12a8 8 0 0 1-12 6.9L4 20l1.1-5A8 8 0 1 1 21 12Z"/></Icon>,
  Doc:       (p) => <Icon {...p}><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8l-5-5Z"/><path d="M14 3v5h5M8 13h8M8 17h6"/></Icon>,
  Send:      (p) => <Icon {...p}><path d="M3 11 21 3l-7 18-2-8-9-2Z"/></Icon>,
  ArrowR:    (p) => <Icon {...p}><path d="M5 12h14m-5-5 5 5-5 5"/></Icon>,
  ArrowL:    (p) => <Icon {...p}><path d="M19 12H5m5 5-5-5 5-5"/></Icon>,
  ChevR:     (p) => <Icon {...p}><path d="m9 6 6 6-6 6"/></Icon>,
  ChevD:     (p) => <Icon {...p}><path d="m6 9 6 6 6-6"/></Icon>,
  ChevU:     (p) => <Icon {...p}><path d="m6 15 6-6 6 6"/></Icon>,
  Plus:      (p) => <Icon {...p}><path d="M12 5v14M5 12h14"/></Icon>,
  X:         (p) => <Icon {...p}><path d="M6 6l12 12M18 6 6 18"/></Icon>,
  Check:     (p) => <Icon {...p}><path d="m5 12 5 5L20 7"/></Icon>,
  Sliders:   (p) => <Icon {...p}><path d="M4 7h12M4 12h8M4 17h14"/><circle cx="18" cy="7" r="2"/><circle cx="14" cy="12" r="2"/><circle cx="20" cy="17" r="2"/></Icon>,
  Grid:      (p) => <Icon {...p}><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></Icon>,
  List:      (p) => <Icon {...p}><path d="M4 6h16M4 12h16M4 18h16"/></Icon>,
  Home:      (p) => <Icon {...p}><path d="M3 11 12 4l9 7v9a1 1 0 0 1-1 1h-5v-7h-6v7H4a1 1 0 0 1-1-1v-9Z"/></Icon>,
  Folder:    (p) => <Icon {...p}><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/></Icon>,
  Settings:  (p) => <Icon {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1A2 2 0 1 1 4.3 17l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8L4.2 7a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/></Icon>,
  Chart:     (p) => <Icon {...p}><path d="M4 20V8M10 20V4M16 20v-8M22 20H2"/></Icon>,
  Pie:       (p) => <Icon {...p}><path d="M21 12A9 9 0 1 1 12 3v9h9Z"/></Icon>,
  Tag:       (p) => <Icon {...p}><path d="M3 12V4h8l10 10-8 8L3 12Z"/><circle cx="7.5" cy="7.5" r="1.5"/></Icon>,
  Eye:       (p) => <Icon {...p}><path d="M2 12s4-8 10-8 10 8 10 8-4 8-10 8S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></Icon>,
  Edit:      (p) => <Icon {...p}><path d="M4 20h4l11-11-4-4L4 16v4Z"/><path d="m13 5 4 4"/></Icon>,
  Print:     (p) => <Icon {...p}><path d="M6 9V3h12v6M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2M6 14h12v7H6v-7Z"/></Icon>,
  Share:     (p) => <Icon {...p}><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 10.5 6.8-4M8.6 13.5l6.8 4"/></Icon>,
  Download:  (p) => <Icon {...p}><path d="M12 4v12m-5-5 5 5 5-5M4 20h16"/></Icon>,
  Link:      (p) => <Icon {...p}><path d="M10 14a4 4 0 0 0 5.6 0l3-3a4 4 0 0 0-5.6-5.6l-1 1M14 10a4 4 0 0 0-5.6 0l-3 3a4 4 0 0 0 5.6 5.6l1-1"/></Icon>,
  Phone:     (p) => <Icon {...p}><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3-8.7A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.6a2 2 0 0 1-.5 2.1L8 9.6a16 16 0 0 0 6 6l1.2-1.2a2 2 0 0 1 2.1-.5 13 13 0 0 0 2.6.6 2 2 0 0 1 1.7 2Z"/></Icon>,
  Mail:      (p) => <Icon {...p}><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 7 9-7"/></Icon>,
  Video:     (p) => <Icon {...p}><rect x="3" y="6" width="14" height="12" rx="2"/><path d="m17 10 5-3v10l-5-3v-4Z"/></Icon>,
  Building:  (p) => <Icon {...p}><path d="M3 21V7a2 2 0 0 1 2-2h6v16M11 21V3h8a2 2 0 0 1 2 2v16M7 9h0M7 13h0M7 17h0M15 9h0M15 13h0M15 17h0"/></Icon>,
  Shield:    (p) => <Icon {...p}><path d="M12 3 4 6v6c0 4.5 3.5 8.5 8 9 4.5-.5 8-4.5 8-9V6l-8-3Z"/></Icon>,
  ShieldChk: (p) => <Icon {...p}><path d="M12 3 4 6v6c0 4.5 3.5 8.5 8 9 4.5-.5 8-4.5 8-9V6l-8-3Z"/><path d="m9 12 2 2 4-4"/></Icon>,
  Alert:     (p) => <Icon {...p}><path d="M12 9v4M12 17h0M3.5 19h17a1 1 0 0 0 .9-1.5L12.9 4a1 1 0 0 0-1.8 0L2.6 17.5a1 1 0 0 0 .9 1.5Z"/></Icon>,
  Info:      (p) => <Icon {...p}><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h0"/></Icon>,
  Menu:      (p) => <Icon {...p}><path d="M3 6h18M3 12h18M3 18h18"/></Icon>,
  Filter:    (p) => <Icon {...p}><path d="M3 5h18l-7 9v6l-4-2v-4L3 5Z"/></Icon>,
  Kanban:    (p) => <Icon {...p}><rect x="3" y="4" width="5" height="16" rx="1"/><rect x="10" y="4" width="5" height="10" rx="1"/><rect x="17" y="4" width="5" height="13" rx="1"/></Icon>,
  Flag:      (p) => <Icon {...p}><path d="M4 21V4M4 5h13l-2 4 2 4H4"/></Icon>,
  Sparkle:   (p) => <Icon {...p}><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M6 18l2.5-2.5M15.5 8.5 18 6"/></Icon>,
  Dot:       (p) => <Icon {...p} fill="currentColor"><circle cx="12" cy="12" r="4"/></Icon>,
};

window.IGIcons = I;
